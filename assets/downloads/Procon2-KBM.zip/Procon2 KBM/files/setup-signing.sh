#!/bin/zsh
# One-time: make rebuilds stop resetting your permissions.
#
# macOS ties an Accessibility grant to the exact binary it was given to. Every
# rebuild produces a different binary, so the grant is withdrawn and has to be
# flipped off and on again. Signing with a certificate that stays the same
# across builds ties the grant to the certificate instead, and it sticks.
#
# This makes a certificate that never leaves your Mac. It signs nothing but
# this tool and proves nothing to anyone else — it exists only so macOS sees
# one consistent program instead of a new one each time.

set -u
NAME="procon2-kbm-signing"
KEYCHAIN="$HOME/Library/Keychains/login.keychain-db"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

if security find-certificate -c "$NAME" >/dev/null 2>&1; then
  print "You already have the '$NAME' certificate."
  print "Rebuilds should already be keeping your permissions."
  exit 0
fi

print "Creating a code-signing certificate called '$NAME'..."
cat > "$WORK/cert.conf" <<CONF
[ req ]
distinguished_name = dn
x509_extensions = v3
prompt = no
[ dn ]
CN = $NAME
[ v3 ]
basicConstraints = critical,CA:false
keyUsage = critical,digitalSignature
extendedKeyUsage = critical,codeSigning
CONF

openssl req -x509 -newkey rsa:2048 -sha256 -days 3650 -nodes \
  -keyout "$WORK/key.pem" -out "$WORK/cert.pem" -config "$WORK/cert.conf" 2>/dev/null \
  || { print "openssl failed — skip this, the off/on toggle still works."; exit 1; }

# -legacy: OpenSSL 3+ encrypts PKCS#12 with AES/PBKDF2 by default, which the
# macOS keychain can't read — the import fails with "MAC verification failed".
# An empty password fails the same way, so use a throwaway one.
openssl pkcs12 -export -legacy -inkey "$WORK/key.pem" -in "$WORK/cert.pem" \
  -out "$WORK/cert.p12" -passout pass:x 2>/dev/null \
  || { print "packaging failed — skip this."; exit 1; }

IMPORTED=0
for target in "$KEYCHAIN" "$(security default-keychain | tr -d ' \"')" ""; do
  if [ -n "$target" ]; then
    security import "$WORK/cert.p12" -k "$target" -P x -T /usr/bin/codesign >/dev/null 2>&1 && { IMPORTED=1; KEYCHAIN="$target"; break; }
  else
    security import "$WORK/cert.p12" -P x -T /usr/bin/codesign >/dev/null 2>&1 && { IMPORTED=1; KEYCHAIN="$(security default-keychain | tr -d ' \"')"; break; }
  fi
done
if [ "$IMPORTED" != "1" ]; then
  print "Couldn't add it to your keychain. Skip this — it only ever saved you"
  print "two clicks per rebuild, and the off/on toggle works fine."
  exit 1
fi

print ""
print "macOS will now ask for your password to trust the certificate."
print "This is expected — it's trusting a certificate you just made, on your"
print "own machine, for signing one program."
print ""
security add-trusted-cert -r trustRoot -p codeSign -k "$KEYCHAIN" "$WORK/cert.pem" 2>/dev/null \
  || print "(trust step didn't take — the build will fall back to the old way)"

if security find-identity -p codesigning 2>/dev/null | grep -q "$NAME"; then
  print ""
  print "Done. Run ./build.sh and switch Accessibility on one last time."
  print "The first build will ask once whether codesign may use the key —"
  print "choose Always Allow. After that, rebuilds leave your permissions alone."
else
  print ""
  print "The certificate isn't usable for signing. No harm done — builds carry"
  print "on as before and you keep flipping the toggle. Not worth more effort."
fi
