#!/bin/zsh
# procon2-kbm — build and install.
#
# No password needed: everything goes in your own home folder.
# After this it runs in the background and starts itself when you log in, so
# there's no terminal window to keep open.
#
# If the build fails, the errors are left in build.log next to this script.

set -u
cd "${0:A:h}"

LOG="build.log"
BIN_DIR="$PWD/bin"
BIN="$BIN_DIR/procon2-kbm"
LABEL="com.procon2.kbm"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"

print "procon2-kbm — building in $PWD"
{
  print "procon2-kbm build — $(date)"
  print "swift: $(swift --version 2>&1 | head -2 | tr '\n' ' ')"
  print "---"
} > "$LOG"

print "· compiling (the first build with new files takes a minute)"
if ! swift build -c release >> "$LOG" 2>&1; then
  print ""
  print "BUILD FAILED — the errors are in:"
  print "  $PWD/$LOG"
  print ""
  grep -E "error:" "$LOG" | head -20
  print ""
  print "Nothing was replaced; whatever was running before is still running."
  print "Claude can read build.log directly — you don't need to copy anything."
  exit 1
fi
print "· compiled"

# Stop the running copy only now, after the compile, so a build costs a few
# seconds of controller instead of the whole compile — and a failed build
# costs nothing.
print "· stopping the running copy"
launchctl unload -w "$PLIST" 2>/dev/null
pkill -CONT -x procon2-kbm 2>/dev/null
pkill -x procon2-kbm 2>/dev/null
sleep 0.5

mkdir -p "$BIN_DIR" "$PWD/log"
rm -f "$BIN"
cp .build/release/procon2-kbm "$BIN"
chmod +x "$BIN"
# If a stable certificate exists, sign with it: macOS then ties the
# Accessibility grant to the certificate rather than to this exact binary, so
# rebuilding stops withdrawing it. Falls back to ad-hoc signing otherwise.
SIGN_AS="procon2-kbm-signing"
# No -v: the certificate is self-made and deliberately not marked trusted
# (that needs a password prompt). codesign signs with it regardless, and the
# Accessibility grant follows the designated requirement — identifier plus
# certificate — which is the same for every build. Without --identifier the
# identifier would carry a hash of the binary and change each time.
if security find-identity -p codesigning 2>/dev/null | grep -q "$SIGN_AS"; then
  if codesign --force --sign "$SIGN_AS" --identifier "$LABEL" "$BIN" 2>>"$LOG"; then
    print "· signed with your certificate — permissions should survive this"
  else
    codesign --force --sign - "$BIN" 2>/dev/null
    print "· signing with the certificate failed; used ad-hoc (see $LOG)"
  fi
else
  codesign --force --sign - "$BIN" 2>/dev/null
fi

# A link on PATH, so typing procon2-kbm in a terminal still finds it.
mkdir -p "$HOME/.local/bin"
ln -sf "$BIN" "$HOME/.local/bin/procon2-kbm"
if [ -w /usr/local/bin ] && [ -e /usr/local/bin/procon2-kbm ]; then
  # Replace an older copy so it can't be started alongside this one.
  cp "$BIN" /usr/local/bin/procon2-kbm 2>/dev/null && print "· replaced the old copy in /usr/local/bin"
fi
print "· installed to $BIN"

mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<PLISTEOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array>
    <string>$BIN</string>
    <string>--no-console</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key>
  <dict><key>SuccessfulExit</key><false/></dict>
  <key>ThrottleInterval</key><integer>5</integer>
  <key>ProcessType</key><string>Interactive</string>
  <key>StandardOutPath</key><string>$PWD/log/out.log</string>
  <key>StandardErrorPath</key><string>$PWD/log/err.log</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key><string>$HOME/.local/bin:/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
</dict>
</plist>
PLISTEOF

: > "$PWD/log/out.log"
: > "$PWD/log/err.log"
# A build restarts the tool. Note it, so the panel's health check doesn't
# count it as the controller dropping out.
print "{\"at\":$(date +%s)}" >> "$PWD/builds.jsonl"
launchctl load -w "$PLIST" 2>/dev/null
sleep 3

print ""
if pgrep -x procon2-kbm > /dev/null; then
  print "· running in the background"
else
  print "· it did not stay running. Last lines of log/err.log:"
  tail -12 "$PWD/log/err.log" 2>/dev/null
fi

if curl -s --max-time 3 "http://127.0.0.1:7777/state" > /dev/null 2>&1; then
  print "· control panel is answering"
else
  print "· control panel is not answering yet (give it a few seconds, then reload)"
fi

print ""
print "  Control panel:  http://127.0.0.1:7777"
print ""
print "macOS needs two permissions, and it now asks for them against"
print "procon2-kbm itself rather than Terminal:"
print ""
print "  System Settings → Privacy & Security → Accessibility"
print "  System Settings → Privacy & Security → Input Monitoring"
print ""
print "If procon2-kbm isn't already listed there, press + and pick this file:"
print "  $BIN"
print "(the folder is plain ~/procon2-kbm/bin, so it's easy to find)"
print ""
print "After switching them on, restart it:"
print "  launchctl kickstart -k gui/\$UID/$LABEL"
print ""
print "Stop it for good:        zsh ~/procon2-kbm/agent-off.sh"
print "Watch it in a terminal:  zsh ~/procon2-kbm/run.sh"
