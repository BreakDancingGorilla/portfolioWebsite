#!/bin/zsh
# Run procon2-kbm in this terminal window instead of in the background —
# useful for watching what it prints. Stops the background copy first.
set -u
cd "${0:A:h}"
launchctl unload -w "$HOME/Library/LaunchAgents/com.procon2.kbm.plist" 2>/dev/null
pkill -CONT -x procon2-kbm 2>/dev/null
pkill -x procon2-kbm 2>/dev/null
sleep 0.4
exec "$PWD/bin/procon2-kbm" "$@"
