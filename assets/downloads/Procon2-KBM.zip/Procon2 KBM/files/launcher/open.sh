#!/bin/zsh
# What the desktop icon runs. Starts the tool if it isn't running (run.sh and
# agent-off.sh unload it), waits for the control panel, then opens it.
# It never runs the binary itself: launchd does, so Accessibility stays with
# the signed bin/procon2-kbm.
LABEL="com.procon2.kbm"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
PANEL="http://127.0.0.1:7777"

if ! pgrep -x procon2-kbm >/dev/null; then
  launchctl load -w "$PLIST" 2>/dev/null
  launchctl kickstart "gui/$UID/$LABEL" 2>/dev/null
fi
for i in {1..40}; do
  curl -s -m 1 -o /dev/null "$PANEL/state" && break
  sleep 0.25
done
if curl -s -m 1 -o /dev/null "$PANEL/state"; then
  open "$PANEL"
else
  osascript -e 'display alert "procon2-kbm didn’t start" message "Its log is in ~/procon2-kbm/log/err.log." as critical' >/dev/null
fi
