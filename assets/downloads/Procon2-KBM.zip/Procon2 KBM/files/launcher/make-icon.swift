// Draws the launcher icon: the panel's dark background, a controller in the
// panel's green, and a crosshair. Writes a 1024 px PNG; make-launcher.sh turns
// it into an .icns.
import AppKit

let out = CommandLine.arguments[1]
let size: CGFloat = 1024
let img = NSImage(size: NSSize(width: size, height: size))
img.lockFocus()
let ctx = NSGraphicsContext.current!.cgContext

// macOS icon grid: an 824 px rounded square centred in 1024.
let tile = NSRect(x: 100, y: 100, width: 824, height: 824)
let path = NSBezierPath(roundedRect: tile, xRadius: 185, yRadius: 185)
NSGradient(colors: [NSColor(srgbRed: 0.10, green: 0.11, blue: 0.15, alpha: 1),
                    NSColor(srgbRed: 0.05, green: 0.06, blue: 0.08, alpha: 1)])!.draw(in: path, angle: -90)
NSColor(srgbRed: 0.15, green: 0.17, blue: 0.22, alpha: 1).setStroke()
path.lineWidth = 6
path.stroke()

let green = NSColor(srgbRed: 0.37, green: 0.89, blue: 0.63, alpha: 1)
let config = NSImage.SymbolConfiguration(pointSize: 330, weight: .regular)
    .applying(NSImage.SymbolConfiguration(paletteColors: [green]))
if let pad = NSImage(systemSymbolName: "gamecontroller.fill", accessibilityDescription: nil)?
    .withSymbolConfiguration(config) {
    let s = pad.size
    pad.draw(in: NSRect(x: (size - s.width) / 2, y: 300 - s.height / 2, width: s.width, height: s.height))
}

// crosshair above the controller
ctx.setStrokeColor(NSColor(srgbRed: 0.93, green: 0.94, blue: 0.96, alpha: 1).cgColor)
ctx.setLineWidth(20)
ctx.setLineCap(.round)
let c = CGPoint(x: 512, y: 660), r: CGFloat = 92
ctx.strokeEllipse(in: CGRect(x: c.x - r, y: c.y - r, width: 2 * r, height: 2 * r))
for (dx, dy) in [(1, 0), (-1, 0), (0, 1), (0, -1)] as [(CGFloat, CGFloat)] {
    ctx.move(to: CGPoint(x: c.x + dx * (r - 34), y: c.y + dy * (r - 34)))
    ctx.addLine(to: CGPoint(x: c.x + dx * (r + 34), y: c.y + dy * (r + 34)))
}
ctx.strokePath()
ctx.setFillColor(green.cgColor)
ctx.fillEllipse(in: CGRect(x: c.x - 16, y: c.y - 16, width: 32, height: 32))
img.unlockFocus()

let rep = NSBitmapImageRep(data: img.tiffRepresentation!)!
try! rep.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: out))
