// Session recording.
//
// Recording 250 Hz continuously would be gigabytes of nothing, because almost
// all of a Rust session is running around. This keeps a rolling few seconds in
// memory and only writes when something is happening: from the moment aim or
// the trigger goes down until two seconds after it all stops. One file per
// engagement, not one per bullet.
//
// Every engagement also gets a line in index.jsonl with its numbers already
// worked out, so the shape of a session can be read without opening a single
// raw file. The one that matters most is the correction ratio: how much of the
// aiming movement was spent going back the other way. That is overshoot, and
// it is measured here directly from stick and gyro input rather than guessed
// at from a video afterwards.

import Foundation

struct Frame {
    var t = 0.0
    var lx: Float = 0, ly: Float = 0
    var rx: Float = 0, ry: Float = 0
    var gyroYaw: Float = 0, gyroPitch: Float = 0
    var dx: Int32 = 0, dy: Int32 = 0
    var buttons: UInt32 = 0
    var ads = false
    var firing = false
}

final class Recorder {
    static let root = Store.directory.appendingPathComponent("sessions", isDirectory: true)

    private var ring = [Frame](repeating: Frame(), count: 3000)   // 12 s at 250 Hz
    private var head = 0
    private var filled = 0
    private var everyOther = false
    /// Movement from the tick that isn't kept. Before 2026-10-28 19:30 it was
    /// simply dropped, so every recorded movement total was half what was
    /// really posted. Now it's added to the next kept frame.
    private var carry: (dx: Int32, dy: Int32) = (0, 0)

    /// Extra fields for the engagement's index line, read when it finishes:
    /// gyro state, the experiment arm, anything the mapper knows.
    var context: (() -> [String: Any])?
    /// Called after an engagement is measured, with its number of shots.
    var onFinish: ((Int) -> Void)?
    /// Called on each trigger press with the view's movement over the ~100 ms
    /// before it: the same number as a press's steadiness in the index.
    var onShot: ((Double) -> Void)?
    private var liveWindow: [Double] = []
    private var liveFiring = false

    private var engagement: [Frame] = []
    private var inEngagement = false
    private var lastActivity = 0.0
    private var engagementStart = 0.0
    private var engagementIndex = 0

    private(set) var engagementsThisRun = 0
    private(set) var lastSummary: [String: Any] = [:]
    private(set) var lastWriteError: String?

    // 3 s, was 1.5 (2026-10-29): the flick onto a target often starts well
    // before the trigger or aim button, and the calibrator needs all of it.
    static let preRoll = 3.0      // seconds kept from before it kicked off
    static let tailOut = 2.0      // seconds of quiet that end an engagement

    var profileName = "A"
    var settingsSummary = ""

    /// Called every tick with the current state.
    func add(_ frame: Frame, enabled: Bool) {
        guard enabled else {
            if inEngagement { finish() }
            return
        }
        // Halve the rate on the way in: 125 Hz is plenty to see overshoot and
        // it halves what gets written.
        everyOther = !everyOther
        guard everyOther else {
            carry.dx += frame.dx
            carry.dy += frame.dy
            return
        }
        var frame = frame
        frame.dx += carry.dx
        frame.dy += carry.dy
        carry = (0, 0)

        liveWindow.append((Double(frame.dx) * Double(frame.dx) + Double(frame.dy) * Double(frame.dy)).squareRoot())
        if liveWindow.count > 12 { liveWindow.removeFirst() }
        if frame.firing && !liveFiring {
            onShot?(liveWindow.reduce(0, +) / Double(liveWindow.count))
        }
        liveFiring = frame.firing

        ring[head] = frame
        head = (head + 1) % ring.count
        filled = min(filled + 1, ring.count)

        let active = frame.ads || frame.firing
        if active {
            if !inEngagement { begin(at: frame.t) }
            lastActivity = frame.t
        }
        if inEngagement {
            engagement.append(frame)
            if frame.t - lastActivity > Recorder.tailOut { finish() }
            if engagement.count > 20000 { finish() }   // 160 s, something's wrong
        }
    }

    private func begin(at t: Double) {
        inEngagement = true
        engagementStart = t
        engagement = recentFrames(seconds: Recorder.preRoll, before: t)
    }

    private func recentFrames(seconds: Double, before t: Double) -> [Frame] {
        var out: [Frame] = []
        var i = (head - 1 + ring.count) % ring.count
        for _ in 0..<filled {
            let f = ring[i]
            if f.t <= 0 || t - f.t > seconds { break }
            out.append(f)
            i = (i - 1 + ring.count) % ring.count
        }
        return out.reversed()
    }

    func finish() {
        defer {
            inEngagement = false
            engagement = []
        }
        guard inEngagement, engagement.count > 30 else { return }
        let frames = engagement
        var summary = Recorder.measure(frames, profile: profileName, settings: settingsSummary)
        summary["frameDeltas"] = "summed"
        for (k, v) in context?() ?? [:] { summary[k] = v }
        onFinish?(summary["shots"] as? Int ?? 0)
        lastSummary = summary
        engagementsThisRun += 1
        engagementIndex += 1

        // Writing happens off the game loop.
        let index = engagementIndex
        let profile = profileName
        let settings = settingsSummary
        DispatchQueue.global(qos: .utility).async { [weak self] in
            self?.write(frames: frames, summary: summary, index: index,
                        profile: profile, settings: settings)
        }
    }

    private func write(frames: [Frame], summary: [String: Any], index: Int,
                       profile: String, settings: String) {
        let fm = FileManager.default
        let now = Date()
        let day = DateFormatter()
        day.dateFormat = "yyyy-MM-dd"
        let clock = DateFormatter()
        clock.dateFormat = "HHmmss"
        let dir = Recorder.root.appendingPathComponent(day.string(from: now), isDirectory: true)
        do {
            try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        } catch {
            lastWriteError = "\(error)"
            return
        }
        let name = "\(clock.string(from: now))-\(index).csv"
        let fileURL = dir.appendingPathComponent(name)

        var text = "# procon2-kbm engagement · profile \(profile) · \(settings)\n"
        text += "t,lx,ly,rx,ry,gyroYaw,gyroPitch,dx,dy,ads,firing,buttons\n"
        let t0 = frames.first?.t ?? 0
        for f in frames {
            text += String(format: "%.4f,%.4f,%.4f,%.4f,%.4f,%.2f,%.2f,%d,%d,%d,%d,%u\n",
                           f.t - t0, f.lx, f.ly, f.rx, f.ry,
                           f.gyroYaw, f.gyroPitch, f.dx, f.dy,
                           f.ads ? 1 : 0, f.firing ? 1 : 0, f.buttons)
        }
        do {
            try text.write(to: fileURL, atomically: true, encoding: .utf8)
        } catch {
            lastWriteError = "\(error)"
            return
        }

        var line = summary
        line["file"] = "\(day.string(from: now))/\(name)"
        line["wallClock"] = ISO8601DateFormatter().string(from: now)
        // wallClock is when this was written — the end of the engagement plus
        // the tail-out, to the whole second — which is too coarse to match a
        // hit to a trigger press. These are exact, in Unix seconds, and every
        // time inside `presses` is relative to startEpoch.
        let toEpoch = now.timeIntervalSince1970 - ProcessInfo.processInfo.systemUptime
        line["startEpoch"] = ((t0 + toEpoch) * 1000).rounded() / 1000
        line["endEpoch"] = (((frames.last?.t ?? t0) + toEpoch) * 1000).rounded() / 1000
        guard let data = jsonData(line, options: [.sortedKeys]),
              var json = String(data: data, encoding: .utf8) else { return }
        json += "\n"
        let indexURL = Recorder.root.appendingPathComponent("index.jsonl")
        if let handle = try? FileHandle(forWritingTo: indexURL) {
            handle.seekToEndOfFile()
            handle.write(Data(json.utf8))
            try? handle.close()
        } else {
            try? fm.createDirectory(at: Recorder.root, withIntermediateDirectories: true)
            try? json.write(to: indexURL, atomically: true, encoding: .utf8)
        }
    }

    /// Work out the numbers for one engagement.
    static func measure(_ frames: [Frame], profile: String, settings: String) -> [String: Any] {
        guard frames.count > 1 else { return [:] }
        let duration = (frames.last!.t - frames.first!.t)

        var shots = 0
        var adsFrames = 0
        var wasFiring = false
        var travelX = 0.0, travelY = 0.0
        var backwardsX = 0.0
        var lastDirection = 0.0
        var peakRate = 0.0
        var steadinessSum = 0.0
        var steadinessCount = 0.0
        var reversals = 0

        // Movement just before each shot: a settled crosshair at the moment of
        // firing is most of what separates good aim from fast aim.
        var window: [Double] = []
        // One entry per trigger press: [down, up, steadiness, ads], times in
        // seconds from the first frame. A press on an automatic weapon is a
        // burst, so outcomes are joined per press, not per bullet.
        var presses: [[Double]] = []
        let t0 = frames.first!.t

        for f in frames {
            let dx = Double(f.dx), dy = Double(f.dy)
            travelX += abs(dx)
            travelY += abs(dy)
            let rate = (dx * dx + dy * dy).squareRoot()
            peakRate = max(peakRate, rate)
            if f.ads { adsFrames += 1 }

            // Direction reversals on the horizontal axis, ignoring tiny jitter.
            if abs(dx) > 1 {
                let dir = dx > 0 ? 1.0 : -1.0
                if lastDirection != 0 && dir != lastDirection {
                    reversals += 1
                    backwardsX += abs(dx)
                }
                lastDirection = dir
            }

            window.append(rate)
            if window.count > 12 { window.removeFirst() }   // ~100 ms at 125 Hz

            if f.firing && !wasFiring {
                shots += 1
                let steadiness = window.isEmpty ? -1 : window.reduce(0, +) / Double(window.count)
                if !window.isEmpty {
                    steadinessSum += steadiness
                    steadinessCount += 1
                }
                presses.append([f.t - t0, -1, (steadiness * 100).rounded() / 100, f.ads ? 1 : 0])
            } else if !f.firing && wasFiring, !presses.isEmpty {
                presses[presses.count - 1][1] = ((f.t - t0) * 1000).rounded() / 1000
            }
            wasFiring = f.firing
        }

        let totalTravel = travelX + travelY
        let correction = travelX > 0 ? backwardsX / travelX : 0

        return [
            "profile": profile,
            "settings": settings,
            "durationSec": round(duration * 100) / 100,
            "shots": shots,
            "adsSec": round(Double(adsFrames) / 125.0 * 100) / 100,
            "mouseTravel": Int(totalTravel),
            "correctionRatio": round(correction * 1000) / 1000,
            "reversals": reversals,
            "reversalsPerSec": duration > 0 ? round(Double(reversals) / duration * 100) / 100 : 0,
            "peakRate": Int(peakRate),
            "steadinessAtShot": steadinessCount > 0 ? round(steadinessSum / steadinessCount * 100) / 100 : 0,
            "frames": frames.count,
            "presses": presses.map { p in
                [(p[0] * 1000).rounded() / 1000, p[1] < 0 ? ((frames.last!.t - t0) * 1000).rounded() / 1000 : p[1], p[2], p[3]]
            },
        ]
    }
}
