// Working out where the gyro lives in report 0x09, by measurement.
//
// Report 0x05 — the one with the documented 6-axis IMU — isn't arriving on
// this controller. But report 0x09 definitely carries an accelerometer: three
// int16 at payload 33/37/41 reading 4096 counts per g, confirmed by the fact
// that at rest they come to 1 g. Those sit on a four-byte grid at 32/36/40,
// and there are three more slots of the same shape at 20/24/28. Three slots
// then three slots is what a 6-axis IMU looks like, so the gyro is very
// likely right there, and earlier attempts simply read it at the wrong byte
// and the wrong width.
//
// Rather than guess again, this scores every plausible layout against
// something already known to be true. Rotating the controller makes the
// measured gravity direction sweep, and that sweep IS rotation — the part of
// it across gravity, anyway. A layout that really is the gyro will track that
// sweep closely. A layout that is noise will not. Correlation tells them
// apart, and it needs nothing from the player beyond moving the controller,
// which happens by itself.
//
// The one thing this cannot see is rotation about gravity, which is exactly
// the yaw that never worked. That doesn't matter here: a layout that gets the
// other two axes right is the gyro, and yaw comes along with it.

import Foundation

struct MotionCandidate {
    enum Kind {
        /// Signed 16-bit little-endian at three payload offsets.
        case int16(Int, Int, Int)
        /// Unsigned 24-bit little-endian, differenced between frames.
        case diff24(Int, Int, Int)
    }
    let name: String
    let kind: Kind
}

final class MotionSearch {
    /// The accelerometer in report 0x09, already known good.
    static let accelOffsets = (33, 37, 41)
    static let accelCountsPerG = 4096.0

    static let candidates: [MotionCandidate] = [
        .init(name: "int16 @21/25/29", kind: .int16(21, 25, 29)),
        .init(name: "int16 @20/24/28", kind: .int16(20, 24, 28)),
        .init(name: "int16 @22/26/30", kind: .int16(22, 26, 30)),
        .init(name: "int16 @19/23/27", kind: .int16(19, 23, 27)),
        .init(name: "int16 @32/36/40", kind: .int16(32, 36, 40)),
        .init(name: "diff24 @20/24/28", kind: .diff24(20, 24, 28)),
    ]

    private struct Accumulator {
        var sxy = 0.0, sxx = 0.0, syy = 0.0, n = 0.0
        var mean = V3()
        /// How closely this layout tracks the rotation gravity can see.
        /// 1 is a perfect match, 0 is unrelated, -1 is mirrored.
        var correlation: Double {
            let d = (sxx * syy).squareRoot()
            return d > 1e-9 ? sxy / d : 0
        }
    }

    private var scores: [String: Accumulator] = [:]
    private var previous: [String: V3] = [:]
    private var up = V3(x: 0, y: 0, z: 1)
    private var prevUp: V3?
    private var lastT = 0.0
    private(set) var movingSamples = 0
    private(set) var totalSamples = 0

    static func s16(_ p: [UInt8], _ i: Int) -> Double? {
        guard i >= 0, i + 1 < p.count else { return nil }
        let v = Int(p[i]) | (Int(p[i + 1]) << 8)
        return Double(v >= 0x8000 ? v - 0x10000 : v)
    }

    static func u24(_ p: [UInt8], _ i: Int) -> Double? {
        guard i >= 0, i + 2 < p.count else { return nil }
        return Double(Int(p[i]) | (Int(p[i + 1]) << 8) | (Int(p[i + 2]) << 16))
    }

    /// Wrap-aware difference for a counter that rolls over at 24 bits.
    private static func wrapStep(_ now: Double, _ was: Double) -> Double {
        var d = now - was
        let span = 16777216.0
        if d > span / 2 { d -= span }
        if d < -span / 2 { d += span }
        return d
    }

    private func read(_ c: MotionCandidate, _ p: [UInt8], dt: Double) -> V3? {
        switch c.kind {
        case .int16(let a, let b, let cc):
            guard let x = MotionSearch.s16(p, a),
                  let y = MotionSearch.s16(p, b),
                  let z = MotionSearch.s16(p, cc) else { return nil }
            return V3(x: x, y: y, z: z)
        case .diff24(let a, let b, let cc):
            guard let x = MotionSearch.u24(p, a),
                  let y = MotionSearch.u24(p, b),
                  let z = MotionSearch.u24(p, cc) else { return nil }
            let raw = V3(x: x, y: y, z: z)
            defer { previous[c.name] = raw }
            guard let was = previous[c.name], dt > 0 else { return nil }
            return V3(x: MotionSearch.wrapStep(raw.x, was.x) / dt,
                      y: MotionSearch.wrapStep(raw.y, was.y) / dt,
                      z: MotionSearch.wrapStep(raw.z, was.z) / dt)
        }
    }

    /// Feed one report 0x09 payload (report-ID byte already stripped).
    func feed(_ payload: [UInt8], t: Double) {
        guard payload.count >= 44 else { return }
        let dt = lastT > 0 ? t - lastT : 0
        lastT = t
        guard dt > 0.0005, dt < 0.05 else { return }
        totalSamples += 1

        // Read every candidate on every frame, moving or not. The differencing
        // one needs an unbroken history, and each channel's resting level has
        // to be measured over everything rather than only over the lively bits.
        var values: [String: V3] = [:]
        for c in MotionSearch.candidates {
            guard let raw = read(c, payload, dt: dt) else { continue }
            values[c.name] = raw
            var acc = scores[c.name] ?? Accumulator()
            acc.mean = acc.mean + (raw - acc.mean) * 0.002
            scores[c.name] = acc
        }

        guard let ax = MotionSearch.s16(payload, MotionSearch.accelOffsets.0),
              let ay = MotionSearch.s16(payload, MotionSearch.accelOffsets.1),
              let az = MotionSearch.s16(payload, MotionSearch.accelOffsets.2) else { return }
        let accel = V3(x: ax, y: ay, z: az) * (1 / MotionSearch.accelCountsPerG)

        // Only trust the accelerometer as a gravity reference when it reads
        // close to 1 g; mid-shake it is measuring the hands, not the Earth.
        let off = abs(accel.length - 1)
        let newUp = off < 0.25 ? (up + (accel.unit - up) * 0.08).unit : up
        let wasUp = prevUp
        let currentUp = up
        prevUp = newUp
        up = newUp

        guard let was = wasUp else { return }

        // d(up)/dt = -w x up, so the part of the rotation across gravity is
        // recoverable from the accelerometer alone.
        let dUp = (newUp - was) * (1 / dt)
        let observed = was.cross(dUp) * -1
        guard observed.length > 0.35 else { return }   // rad/s; ignore stillness
        movingSamples += 1

        for (name, raw) in values {
            guard var acc = scores[name] else { continue }
            let centred = raw - acc.mean
            // Compare only across gravity, since that's all `observed` sees.
            let perp = centred - currentUp * centred.dot(currentUp)
            acc.sxy += perp.dot(observed)
            acc.sxx += perp.dot(perp)
            acc.syy += observed.dot(observed)
            acc.n += 1
            scores[name] = acc
        }
    }

    struct Result {
        let name: String
        let correlation: Double
        let samples: Int
        /// Raw counts to radians a second, measured rather than assumed.
        let slope: Double
        /// What one degree a second costs in raw counts. The documented IMU
        /// uses 16.384; if this comes out near that, it's the same part.
        var countsPerDPS: Double {
            abs(slope) > 1e-12 ? (Double.pi / 180) / abs(slope) : 0
        }
    }

    func results() -> [Result] {
        MotionSearch.candidates.compactMap { c in
            guard let a = scores[c.name], a.n > 0, a.sxx > 1e-9 else { return nil }
            return Result(name: c.name, correlation: a.correlation,
                          samples: Int(a.n), slope: a.sxy / a.sxx)
        }.sorted { abs($0.correlation) > abs($1.correlation) }
    }

    /// Offsets for whichever layout is in front, so the reader can decode it.
    static func offsets(named name: String) -> (Int, Int, Int)? {
        guard let c = candidates.first(where: { $0.name == name }) else { return nil }
        switch c.kind {
        case .int16(let a, let b, let cc): return (a, b, cc)
        case .diff24: return nil        // not usable as a direct rate
        }
    }

    /// Build a sample in real units from a report 0x09 payload, once the
    /// layout and its scale have been measured.
    static func sample(from payload: [UInt8], offsets o: (Int, Int, Int),
                       countsPerDPS: Double, flip: Double) -> IMUSample? {
        guard let gx = s16(payload, o.0), let gy = s16(payload, o.1), let gz = s16(payload, o.2),
              let ax = s16(payload, accelOffsets.0), let ay = s16(payload, accelOffsets.1),
              let az = s16(payload, accelOffsets.2) else { return nil }
        let scale = countsPerDPS > 0.01 ? countsPerDPS : 16.384
        return IMUSample(
            ax: ax / accelCountsPerG, ay: ay / accelCountsPerG, az: az / accelCountsPerG,
            gx: gx / scale * flip, gy: gy / scale * flip, gz: gz / scale * flip,
            clockMs: 0, tempC: 0
        )
    }

    /// The layout that matches, once there's enough movement to be sure.
    /// Anything below 0.5 is not a gyro.
    var winner: Result? {
        guard movingSamples > 400, let best = results().first,
              abs(best.correlation) > 0.5 else { return nil }
        return best
    }

    var summary: String {
        let rows = results()
        guard !rows.isEmpty else {
            return "no movement measured yet (\(totalSamples) samples seen)"
        }
        let parts = rows.map {
            String(format: "%@ r=%+.2f", $0.name, $0.correlation)
        }
        var line = "\(movingSamples) moving samples · " + parts.joined(separator: " · ")
        if let best = rows.first, abs(best.correlation) > 0.5 {
            line += String(format: "  →  %@ at %.1f counts per °/s", best.name, best.countsPerDPS)
        }
        return line
    }
}

/// Capture raw report 0x09 payloads to a file, once.
///
/// Guessing at offsets one build at a time is a poor trade when each guess
/// costs a rebuild and a minute of someone's evening. A minute of raw bytes
/// can be searched exhaustively offline instead — every offset, every width,
/// every sign — and that ends the question rather than narrowing it.
final class RawCapture {
    static let directory = Store.directory.appendingPathComponent("diag", isDirectory: true)

    private var rows: [String] = []
    private var startedAt = 0.0
    private(set) var done = false
    private(set) var moving = 0
    private(set) var writtenTo = ""
    private var lastAccel: V3?
    private var firstGravity: V3?
    /// How far the gravity direction has travelled in total, and how far it
    /// ever got from where it started. The second number is the one that
    /// matters: a controller can be shaken through hundreds of degrees of
    /// travel while never actually tilting, and a capture like that cannot
    /// answer anything, because the accelerometer is then reading the hand
    /// rather than the Earth.
    private(set) var gravityTravelDeg = 0.0
    private(set) var maxTiltDeg = 0.0
    /// Samples where the accelerometer reads close to 1 g, so gravity is
    /// actually what it is measuring.
    private(set) var calmSamples = 0

    static let maxSamples = 18000      // about 72 seconds at 250 Hz
    static let movingNeeded = 9000

    var active: Bool { !done }

    func feed(_ payload: [UInt8], t: Double) {
        guard !done else { return }
        if startedAt == 0 { startedAt = t }

        if let ax = MotionSearch.s16(payload, 33),
           let ay = MotionSearch.s16(payload, 37),
           let az = MotionSearch.s16(payload, 41) {
            let a = V3(x: ax, y: ay, z: az) * (1 / 4096.0)
            let g = a.unit
            if abs(a.length - 1) < 0.03 { calmSamples += 1 }
            if let was = lastAccel {
                if (a - was).length > 0.012 { moving += 1 }
                let step = acos(max(-1, min(1, g.dot(was.unit))))
                if step.isFinite { gravityTravelDeg += step * 180 / Double.pi }
            }
            if firstGravity == nil { firstGravity = g }
            if let first = firstGravity {
                let away = acos(max(-1, min(1, g.dot(first)))) * 180 / Double.pi
                if away.isFinite { maxTiltDeg = max(maxTiltDeg, away) }
            }
            lastAccel = a
        }

        rows.append(String(format: "%.4f,", t - startedAt)
                    + payload.map { String(format: "%02X", $0) }.joined())

        if rows.count >= RawCapture.maxSamples || moving >= RawCapture.movingNeeded {
            finish()
        }
    }

    func finish() {
        guard !done else { return }
        done = true
        let stamp = DateFormatter()
        stamp.dateFormat = "yyyyMMdd-HHmmss"
        let name = "raw09-\(stamp.string(from: Date())).csv"
        let header = "# procon2-kbm raw report 0x09 capture\n"
            + "# \(rows.count) samples, \(moving) moving, \(calmSamples) calm\n"
            + "# gravity travel \(Int(gravityTravelDeg)) deg, furthest tilt from start \(Int(maxTiltDeg)) deg\n"
            + "t,payloadHex\n"
        let text = header + rows.joined(separator: "\n") + "\n"
        rows = []
        try? FileManager.default.createDirectory(at: RawCapture.directory, withIntermediateDirectories: true)
        let url = RawCapture.directory.appendingPathComponent(name)
        try? text.write(to: url, atomically: true, encoding: .utf8)
        writtenTo = name
        log("Raw capture written: diag/\(name)")
        log("  \(verdict)")
    }

    /// Whether this capture can actually answer anything.
    var verdict: String {
        if maxTiltDeg < 30 {
            return "not usable — the controller only ever tilted \(Int(maxTiltDeg))° from where it started. "
                 + "Big slow rotations are what's needed, not shaking."
        }
        if calmSamples < 2000 {
            return "marginal — too much of it was fast movement, where the accelerometer reads your hand rather than gravity."
        }
        return "usable — tilted up to \(Int(maxTiltDeg))° with \(calmSamples) steady samples."
    }

    var status: String {
        done ? "written: \(writtenTo)"
             : "\(rows.count) samples, furthest tilt \(Int(maxTiltDeg))°"
    }
}
