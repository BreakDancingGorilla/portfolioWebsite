// The control panel, served at http://127.0.0.1:7777
//
// A copy is written to ~/procon2-kbm/panel.html on first run and that copy is
// what gets served, so the page can be changed without rebuilding the tool.
// The settings list is drawn from whatever /state reports rather than being
// written out here, which means a new setting shows up in the panel on its own.

let panelHTML = #"""
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>procon2</title>
<style>
  :root {
    --bg: #0e1014;
    --panel: #15181f;
    --panel2: #1b1f28;
    --line: #262c38;
    --ink: #e6e9ef;
    --dim: #8b93a3;
    --dimmer: #5c6474;
    --accent: #5ee2a0;
    --warn: #ffc24b;
    --bad: #ff6b6b;
    --mono: ui-monospace, "SF Mono", Menlo, monospace;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0; background: var(--bg); color: var(--ink);
    font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
    padding: 0 16px 64px;
  }
  header {
    position: sticky; top: 0; z-index: 10; background: rgba(14,16,20,.94);
    backdrop-filter: blur(12px); border-bottom: 1px solid var(--line);
    margin: 0 -16px; padding: 14px 16px 12px; display: flex; flex-wrap: wrap;
    gap: 12px 18px; align-items: baseline;
  }
  h1 {
    font-size: 15px; margin: 0; letter-spacing: .14em; text-transform: uppercase;
    color: var(--dim); font-weight: 600;
  }
  .summary { font-family: var(--mono); font-size: 12px; color: var(--dim); }
  .pills { display: flex; flex-wrap: wrap; gap: 6px; margin-left: auto; }
  .pill {
    font-family: var(--mono); font-size: 11px; padding: 3px 9px; border-radius: 999px;
    border: 1px solid var(--line); color: var(--dim); white-space: nowrap;
  }
  .pill.on { color: var(--accent); border-color: color-mix(in oklab, var(--accent) 40%, var(--line)); }
  .pill.warn { color: var(--warn); border-color: color-mix(in oklab, var(--warn) 40%, var(--line)); }
  .pill.bad { color: var(--bad); border-color: color-mix(in oklab, var(--bad) 40%, var(--line)); }

  .wrap { display: grid; grid-template-columns: minmax(0,1.05fr) minmax(0,1fr); gap: 16px; margin-top: 16px; }
  @media (max-width: 900px) { .wrap { grid-template-columns: 1fr; } }

  section {
    background: var(--panel); border: 1px solid var(--line); border-radius: 10px;
    padding: 14px 16px; margin-bottom: 16px;
  }
  section > h2 {
    font-size: 11px; letter-spacing: .14em; text-transform: uppercase;
    color: var(--dimmer); margin: 0 0 12px; font-weight: 600;
  }
  .row { display: grid; grid-template-columns: 1fr auto; gap: 4px 12px; align-items: center; padding: 7px 0; border-top: 1px solid color-mix(in oklab, var(--line) 50%, transparent); }
  .row:first-of-type { border-top: 0; }
  .row .label { font-size: 13px; }
  .row .help { grid-column: 1 / -1; font-size: 11.5px; color: var(--dimmer); margin-top: -2px; }
  .row .ctl { display: flex; align-items: center; gap: 8px; }
  input[type=range] { width: 160px; accent-color: var(--accent); }
  input[type=number], select {
    width: 78px; background: var(--panel2); color: var(--ink); border: 1px solid var(--line);
    border-radius: 6px; padding: 4px 6px; font-family: var(--mono); font-size: 12px;
  }
  select { width: auto; }
  button {
    background: var(--panel2); color: var(--ink); border: 1px solid var(--line);
    border-radius: 7px; padding: 6px 11px; font-size: 12.5px; cursor: pointer;
  }
  button:hover { border-color: var(--dimmer); }
  button.primary { border-color: color-mix(in oklab, var(--accent) 45%, var(--line)); color: var(--accent); }
  .bar { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
  .chip {
    font-family: var(--mono); font-size: 12px; padding: 5px 11px; border-radius: 7px;
    border: 1px solid var(--line); background: var(--panel2); cursor: pointer; color: var(--dim);
  }
  .chip.active { color: var(--bg); background: var(--accent); border-color: var(--accent); font-weight: 600; }

  .meter { margin: 10px 0; }
  .meter .top { display: flex; justify-content: space-between; font-family: var(--mono); font-size: 11.5px; color: var(--dim); }
  .track { position: relative; height: 8px; background: var(--panel2); border-radius: 4px; margin-top: 5px; overflow: hidden; }
  .track .mid { position: absolute; left: 50%; top: 0; bottom: 0; width: 1px; background: var(--line); }
  .track .fill { position: absolute; top: 0; bottom: 0; background: var(--accent); border-radius: 4px; transition: none; }

  table { width: 100%; border-collapse: collapse; font-family: var(--mono); font-size: 11.5px; }
  th { text-align: left; color: var(--dimmer); font-weight: 500; padding: 4px 8px 6px 0; border-bottom: 1px solid var(--line); white-space: nowrap; }
  td { padding: 4px 8px 4px 0; border-bottom: 1px solid color-mix(in oklab, var(--line) 40%, transparent); color: var(--dim); white-space: nowrap; }
  td.k { color: var(--ink); }
  .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px,1fr)); gap: 10px; }
  .stat { background: var(--panel2); border-radius: 8px; padding: 9px 11px; }
  .stat .n { font-family: var(--mono); font-size: 18px; color: var(--ink); }
  .stat .t { font-size: 10.5px; color: var(--dimmer); letter-spacing: .06em; text-transform: uppercase; margin-top: 2px; }
  pre.log {
    font-family: var(--mono); font-size: 11px; color: var(--dim); margin: 0;
    max-height: 220px; overflow: auto; white-space: pre-wrap;
  }
  .note { font-size: 12px; color: var(--dimmer); margin-top: 10px; }
  .offline { background: var(--bad); color: #140b0b; text-align: center; padding: 6px; font-size: 12.5px; margin: 0 -16px; display: none; }
  .offline.show { display: block; }
</style>
</head>
<body>
<div class="offline" id="offline">Not connected to procon2-kbm — is it running?</div>

<header>
  <h1>procon2</h1>
  <div class="summary" id="summary">connecting…</div>
  <div class="pills" id="pills"></div>
</header>

<div class="wrap">
  <div>
    <section>
      <h2>Profile &amp; presets</h2>
      <div class="bar" id="profiles"></div>
      <div class="bar" style="margin-top:10px" id="presets"></div>
      <div class="bar" style="margin-top:10px">
        <input type="text" id="presetName" placeholder="name this setup" style="flex:1;min-width:120px;background:var(--panel2);color:var(--ink);border:1px solid var(--line);border-radius:7px;padding:6px 9px;font-size:12.5px">
        <button onclick="savePreset()">Save preset</button>
        <button onclick="act('undo')">Undo last change</button>
        <button onclick="act('centre')">Re-centre sticks</button>
      </div>
      <div class="note">Home + C swaps profile on the controller. Home + − undoes the last change. Both work without leaving the game.</div>
    </section>

    <div id="groups"></div>
  </div>

  <div>
    <section>
      <h2>Gyro</h2>
      <div id="gyroStatus" class="summary" style="margin-bottom:8px">—</div>
      <div class="meter">
        <div class="top"><span>turn (yaw)</span><span id="yawN">0 °/s</span></div>
        <div class="track"><div class="mid"></div><div class="fill" id="yawBar" style="left:50%;width:0"></div></div>
      </div>
      <div class="meter">
        <div class="top"><span>tilt (pitch)</span><span id="pitchN">0 °/s</span></div>
        <div class="track"><div class="mid"></div><div class="fill" id="pitchBar" style="left:50%;width:0"></div></div>
      </div>
      <div class="bar" style="margin-top:12px">
        <button onclick="act('gyro.recalibrate')">Re-learn directions</button>
        <button onclick="act('imu.rescan')">Re-find motion data</button>
      </div>
      <div class="note" id="gyroNote"></div>
    </section>

    <section>
      <h2>Last engagement</h2>
      <div class="stats" id="engStats"></div>
      <div class="note">An engagement is from the moment you aim or shoot until two seconds after you stop. <b>Correction</b> is the share of aiming movement spent going back the other way — that's overshoot, and lower is better. <b>Steady</b> is how much the view was moving at the instant you fired; lower means you shot from a settled crosshair.</div>
    </section>

    <section>
      <h2>Sessions</h2>
      <table id="sessions"><tbody></tbody></table>
    </section>

    <section>
      <h2>Combat log</h2>
      <div class="stats" id="combatStats"></div>
      <div class="note" id="combatNote"></div>
    </section>

    <section>
      <h2>Recent changes</h2>
      <table id="history"><tbody></tbody></table>
    </section>

    <section>
      <h2>Machine</h2>
      <table id="health"><tbody></tbody></table>
    </section>

    <section>
      <h2>Log</h2>
      <pre class="log" id="log"></pre>
    </section>
  </div>
</div>

<script>
let state = null;
let editing = null;          // don't redraw a control while it's being dragged
let pending = {};
let flushTimer = null;

function post(path, body) {
  return fetch(path, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(body)
  }).then(r => r.json()).catch(() => null);
}

function act(action, name) {
  post('/do', {action, name: name || ''}).then(() => refresh());
}

function queue(name, value) {
  pending[name] = value;
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(() => {
    const body = pending; pending = {}; flushTimer = null;
    post('/set', body).then(r => {
      if (r && r.summary && state) setSummary(state.profile + ' · ' + r.summary);
    });
  }, 90);
}

function setSummary(s) { document.getElementById('summary').textContent = s; }

function pill(text, cls) { return `<span class="pill ${cls||''}">${text}</span>`; }

function renderPills(s) {
  const l = s.live || {}, h = s.health || {};
  const out = [];
  out.push(pill(l.controllerConnected ? 'controller' : 'no controller', l.controllerConnected ? 'on' : 'bad'));
  out.push(pill(l.active ? (l.focusedApp || 'game') + ' focused' : 'paused', l.active ? 'on' : ''));
  if (l.imuReportSeen) out.push(pill(l.gyroReady ? 'gyro ready' : 'gyro learning', l.gyroReady ? 'on' : 'warn'));
  else out.push(pill('no motion report', 'warn'));
  out.push(pill(`${h.reportRateHz||0}→${h.tickRateHz||0} Hz`, (h.reportRateHz>200 && h.tickRateHz>200) ? 'on' : 'warn'));
  const mem = h.memPressure || 'ok';
  out.push(pill(`swap ${h.swapUsedGB!=null?h.swapUsedGB:'?'} GB`, mem==='ok'?'':(mem==='tight'?'warn':'bad')));
  if (!s.accessibility) out.push(pill('needs Accessibility', 'bad'));
  if (l.inputMonitoring === false) out.push(pill('needs Input Monitoring', 'bad'));
  out.push(pill('profile ' + s.profile, 'on'));
  document.getElementById('pills').innerHTML = out.join('');
}

function renderProfiles(s) {
  document.getElementById('profiles').innerHTML =
    (s.profiles||[]).map(p =>
      `<span class="chip ${p===s.profile?'active':''}" onclick="act('profile','${p}')">profile ${p}</span>`
    ).join('');
  const ps = s.presets || [];
  document.getElementById('presets').innerHTML = ps.length
    ? ps.map(p => `<span class="chip" onclick="act('preset.load','${p}')">${p}</span>`).join('')
    : '<span class="note">no presets saved yet</span>';
}

function savePreset() {
  const el = document.getElementById('presetName');
  const name = el.value.trim();
  if (!name) return;
  el.value = '';
  act('preset.save', name);
}

function renderGroups(s) {
  const groups = {};
  for (const f of s.settings) (groups[f.group] = groups[f.group] || []).push(f);
  const host = document.getElementById('groups');
  const order = Object.keys(groups);
  let html = '';
  for (const g of order) {
    html += `<section><h2>${g}</h2>`;
    for (const f of groups[g]) html += renderField(f);
    html += `</section>`;
  }
  // Only rebuild when the shape changed, so dragging a slider isn't interrupted.
  const signature = s.settings.map(f => f.name).join(',');
  if (host.dataset.sig !== signature) {
    host.innerHTML = html;
    host.dataset.sig = signature;
  } else {
    for (const f of s.settings) updateField(f);
  }
}

function renderField(f) {
  const id = 'f_' + f.name;
  let ctl = '';
  if (f.kind === 'number') {
    ctl = `<input type="range" id="${id}_r" min="${f.min}" max="${f.max}" step="${f.step}" value="${f.value}"
             oninput="onNum('${f.name}', this.value)" onpointerdown="editing='${f.name}'" onpointerup="editing=null">
           <input type="number" id="${id}_n" min="${f.min}" max="${f.max}" step="${f.step}" value="${f.value}"
             onchange="onNum('${f.name}', this.value)" onfocus="editing='${f.name}'" onblur="editing=null">`;
  } else if (f.kind === 'toggle') {
    ctl = `<button id="${id}_b" class="${f.value==='on'?'primary':''}" onclick="onToggle('${f.name}')">${f.value}</button>`;
  } else {
    ctl = `<select id="${id}_s" onchange="queue('${f.name}', this.value)">` +
          f.options.map(o => `<option value="${o}" ${o===f.value?'selected':''}>${o}</option>`).join('') +
          `</select>`;
  }
  return `<div class="row"><span class="label">${f.label}</span><span class="ctl">${ctl}</span>` +
         (f.help ? `<span class="help">${f.help}</span>` : '') + `</div>`;
}

function updateField(f) {
  if (editing === f.name) return;
  const r = document.getElementById('f_' + f.name + '_r');
  const n = document.getElementById('f_' + f.name + '_n');
  const b = document.getElementById('f_' + f.name + '_b');
  const sel = document.getElementById('f_' + f.name + '_s');
  if (r) r.value = f.value;
  if (n) n.value = f.value;
  if (b) { b.textContent = f.value; b.className = f.value === 'on' ? 'primary' : ''; }
  if (sel) sel.value = f.value;
}

function onNum(name, value) {
  const r = document.getElementById('f_' + name + '_r');
  const n = document.getElementById('f_' + name + '_n');
  if (r) r.value = value;
  if (n) n.value = value;
  queue(name, value);
}

function onToggle(name) {
  const b = document.getElementById('f_' + name + '_b');
  const next = b && b.textContent.trim() === 'on' ? 'off' : 'on';
  if (b) { b.textContent = next; b.className = next === 'on' ? 'primary' : ''; }
  queue(name, next);
}

function renderGyro(s) {
  const l = s.live || {};
  document.getElementById('gyroStatus').textContent = l.gyroStatus || '—';
  const span = 180;
  for (const [key, bar, num] of [['gyroYawRate','yawBar','yawN'], ['gyroPitchRate','pitchBar','pitchN']]) {
    const v = Math.max(-span, Math.min(span, l[key] || 0));
    const pct = Math.abs(v) / span * 50;
    const el = document.getElementById(bar);
    el.style.width = pct + '%';
    el.style.left = (v >= 0 ? 50 : 50 - pct) + '%';
    document.getElementById(num).textContent = (l[key] || 0).toFixed(1) + ' °/s';
  }
  const bits = [];
  if (l.imuAlignment) bits.push('motion data at ' + l.imuAlignment);
  if (l.gyroDriftDPS != null) bits.push('resting drift ' + l.gyroDriftDPS + ' °/s');
  if (!l.imuReportSeen) bits.push('The controller is not sending report 0x05 on this connection, so gyro is unavailable.');
  if (l.hidError) bits.push(l.hidError);
  document.getElementById('gyroNote').textContent = bits.join(' · ');
}

function stat(n, t) { return `<div class="stat"><div class="n">${n}</div><div class="t">${t}</div></div>`; }

function renderEngagement(s) {
  const e = (s.live || {}).lastEngagement || {};
  const host = document.getElementById('engStats');
  if (!e.durationSec) {
    host.innerHTML = '<div class="note">Nothing recorded yet — aim or fire in game and it shows up here.</div>';
    return;
  }
  host.innerHTML =
    stat(e.shots ?? 0, 'shots') +
    stat((e.durationSec ?? 0) + 's', 'length') +
    stat(Math.round((e.correctionRatio ?? 0) * 100) + '%', 'correction') +
    stat(Number(e.steadinessAtShot ?? 0).toFixed(1), 'steady at shot') +
    stat(Number(e.reversalsPerSec ?? 0).toFixed(1), 'reversals/s') +
    stat(e.peakRate ?? 0, 'peak');
}

function renderSessions(s) {
  fetch('/sessions').then(r => r.json()).then(d => {
    const rows = (d.engagements || []).slice(0, 12);
    const body = document.querySelector('#sessions tbody');
    if (!rows.length) { body.innerHTML = '<tr><td class="note">no engagements recorded yet</td></tr>'; return; }
    body.innerHTML = '<tr><th>time</th><th>shots</th><th>corr</th><th>steady</th><th>prof</th></tr>' +
      rows.map(r => {
        const t = (r.wallClock || '').slice(11, 16);
        return `<tr><td class="k">${t}</td><td>${r.shots ?? 0}</td>` +
               `<td>${Math.round((r.correctionRatio ?? 0) * 100)}%</td>` +
               `<td>${Number(r.steadinessAtShot ?? 0).toFixed(1)}</td><td>${r.profile || ''}</td></tr>`;
      }).join('');
  }).catch(() => {});
}

function renderCombat(s) {
  const c = s.combat || {};
  const host = document.getElementById('combatStats');
  if (!c.rows) {
    host.innerHTML = '';
    document.getElementById('combatNote').textContent =
      (c.note || '') + (c.log && c.log !== 'none' ? ' · ' + c.log : '');
    return;
  }
  host.innerHTML =
    stat(c.hitsLanded ?? 0, 'hits landed') +
    stat((c.headshotPct ?? 0) + '%', 'headshots') +
    stat(c.damageDealt ?? 0, 'damage out') +
    stat(c.damageTaken ?? 0, 'damage in') +
    stat((c.medianDistanceM ?? 0) + 'm', 'median range') +
    stat(c.topWeapon || '—', 'most used');
  document.getElementById('combatNote').textContent = c.note || '';
}

function renderHistory(s) {
  const rows = s.history || [];
  const body = document.querySelector('#history tbody');
  if (!rows.length) { body.innerHTML = '<tr><td class="note">no changes yet</td></tr>'; return; }
  body.innerHTML = rows.slice(0, 14).map(h => {
    const t = new Date(h.at * 1000).toTimeString().slice(0, 5);
    return `<tr><td>${t}</td><td class="k">${h.field}</td><td>${h.from} → ${h.to}</td><td>${h.by}</td></tr>`;
  }).join('');
}

function renderHealth(s) {
  const h = s.health || {};
  const pairs = [
    ['reports in', (h.reportRateHz||0) + ' Hz, worst gap ' + (h.reportWorstGapMs||0) + ' ms'],
    ['mouse out', (h.tickRateHz||0) + ' Hz, worst ' + (h.tickWorstMs||0) + ' ms'],
    ['memory free', (h.memFreeGB||0) + ' of ' + (h.memTotalGB||0) + ' GB'],
    ['swap in use', (h.swapUsedGB||0) + ' GB (' + (h.memPressure||'?') + ')'],
    ['compressed', (h.compressedGB||0) + ' GB'],
  ];
  document.querySelector('#health tbody').innerHTML =
    pairs.map(([k, v]) => `<tr><td class="k">${k}</td><td>${v}</td></tr>`).join('');
}

function render(s) {
  state = s;
  setSummary(s.profile + ' · ' + s.summary);
  renderPills(s);
  renderProfiles(s);
  renderGroups(s);
  renderGyro(s);
  renderEngagement(s);
  renderCombat(s);
  renderHistory(s);
  renderHealth(s);
  document.getElementById('log').textContent = (s.log || []).join('\n');
  document.getElementById('offline').classList.remove('show');
}

function refresh() {
  return fetch('/state').then(r => r.json()).then(render).catch(() => {
    document.getElementById('offline').classList.add('show');
  });
}

// Live updates get pushed; polling is only a fallback if the stream drops.
let stream = null;
function connect() {
  try {
    stream = new EventSource('/events');
    stream.addEventListener('state', e => { try { render(JSON.parse(e.data)); } catch (_) {} });
    stream.onerror = () => { try { stream.close(); } catch (_) {} stream = null; setTimeout(connect, 2000); };
  } catch (_) { setTimeout(connect, 2000); }
}

refresh();
connect();
setInterval(() => { if (!stream) refresh(); }, 1500);
setInterval(renderSessions, 10000);
renderSessions();
</script>
</body>
</html>
"""#
