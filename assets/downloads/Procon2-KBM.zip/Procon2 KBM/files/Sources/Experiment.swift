// A/B experiments that run themselves.
//
// One setting, two values, switched in blocks of engagements so there's time
// to adapt to each — switching every fight would measure the cost of switching
// as much as either setting. Only ever between engagements, never during one.
// Every engagement is tagged with the value it was played on, and the first one
// after each switch is marked so the report can leave it out while he adjusts.
//
// The verdict comes from analysis/report.py, which refuses to give one until
// both values have enough known outcomes. This only does the switching.

import Foundation

final class Experiment {
    struct State: Codable {
        var field: String
        var values: [String]
        var block: Int              // engagements with shots per block
        var arm: Int                // index into values
        var inBlock: Int            // engagements with shots so far in this block
        var blockNumber: Int
        var original: String        // what the setting was before, restored on stop
        var startedAt: Double
        var blockStartedAt: Double?  // optional so experiment.json from older builds still loads
        var minSeconds: Double?      // per-test minimum block length (stick tests: 10 min)
        var activeSeconds: Double?   // playing time in this block (gaps over a minute don't count)
        var lastEngagementAt: Double?
    }

    /// A block also has to last this long. An "engagement" is one aim-down,
    /// about 5 s, so 8 of them flipped the setting every minute or two
    /// (2026-10-28 23:19-23:22: three switches in 3 minutes) — too fast to adapt.
    static let minBlockSeconds = 300.0

    static let url = Store.directory.appendingPathComponent("experiment.json")
    private(set) var state: State?
    private let store: Store

    init(store: Store) {
        self.store = store
        if let data = try? Data(contentsOf: Experiment.url),
           let s = try? JSONDecoder().decode(State.self, from: data) {
            state = s
        }
    }

    /// The fields an experiment can run on, and the two values to compare.
    /// Anything else can be started over HTTP with explicit values.
    static let presets: [String: [String]] = [
        "evenReach": ["off", "on"],
        "gyroSens": ["53", "70"],
        "gyroTighten": ["1.5", "0.5"],
    ]

    func start(field: String, values: [String]?, block: Int, minSeconds: Double? = nil) -> String {
        guard let f = Settings.field(field) else { return "no setting called \(field)" }
        let vals = values ?? Experiment.presets[f.name] ?? []
        guard vals.count == 2, vals[0] != vals[1] else { return "an experiment needs two different values for \(f.name)" }
        if state != nil { _ = stop() }
        let original = store.settings.value(f)
        // Random first arm, so a session that gets better as it warms up
        // doesn't always favour the second value.
        let arm = Int.random(in: 0...1)
        state = State(field: f.name, values: vals, block: max(2, block), arm: arm, inBlock: 0,
                      blockNumber: 1, original: original, startedAt: Date().timeIntervalSince1970,
                      blockStartedAt: Date().timeIntervalSince1970, minSeconds: minSeconds)
        store.apply(f.name, vals[arm], by: "experiment")
        save()
        return "experiment on \(f.label): \(vals[0]) vs \(vals[1]), switching every \(max(2, block)) fights — starting with \(vals[arm])"
    }

    /// Stop, putting the setting back as it was — or on `keep`, when the
    /// auto-tuner has decided which value won.
    func stop(keep: String? = nil, by: String = "experiment") -> String {
        guard let s = state else { return "no experiment running" }
        state = nil
        try? FileManager.default.removeItem(at: Experiment.url)
        let value = keep ?? s.original
        store.apply(s.field, value, by: by)
        return "experiment stopped; \(s.field) \(keep == nil ? "back to" : "kept at") \(value)"
    }

    /// The tag for the engagement that just finished, read before it counts.
    var tag: [String: Any]? {
        guard let s = state else { return nil }
        return ["field": s.field, "value": s.values[s.arm], "block": s.blockNumber, "first": s.inBlock == 0]
    }

    /// Called after each engagement. Only engagements with a trigger press count
    /// towards a block: walking around aiming isn't a fight.
    func engagementFinished(shots: Int) {
        guard var s = state, shots > 0 else { return }
        // The setting could have been changed by hand mid-experiment, which
        // would mix the two arms. Put it back and say so.
        if let f = Settings.field(s.field), store.settings.value(f) != Experiment.normalised(s.values[s.arm], f) {
            store.apply(s.field, s.values[s.arm], by: "experiment")
            log("⚗︎ experiment: \(f.label) was changed by hand — set back to \(s.values[s.arm]). Stop the experiment to change it.")
        }
        s.inBlock += 1
        let now = Date().timeIntervalSince1970
        // Count playing time, not wall-clock: a block shouldn't run out in a
        // menu (00:10, Oct 29: 37 shots on one value against 371 on the other).
        if let last = s.lastEngagementAt { s.activeSeconds = (s.activeSeconds ?? 0) + min(now - last, 60) }
        s.lastEngagementAt = now
        if s.blockStartedAt == nil { s.blockStartedAt = now }
        if s.inBlock >= s.block && (s.activeSeconds ?? 0) >= (s.minSeconds ?? Experiment.minBlockSeconds) {
            s.arm = 1 - s.arm
            s.inBlock = 0
            s.blockNumber += 1
            s.blockStartedAt = now
            s.activeSeconds = 0
            state = s
            if let label = store.apply(s.field, s.values[s.arm], by: "experiment") {
                log("⚗︎ experiment: block \(s.blockNumber) — \(label)")
            }
        } else {
            state = s
        }
        save()
    }

    /// The value as the store would print it, so "53" matches "53".
    private static func normalised(_ raw: String, _ f: Settings.Field) -> String {
        var s = Settings()
        return s.set(f, to: raw) ?? raw
    }

    var snapshot: [String: Any]? {
        guard let s = state else { return nil }
        return ["field": s.field, "values": s.values, "current": s.values[s.arm], "block": s.blockNumber,
                "inBlock": s.inBlock, "blockSize": s.block, "startedAt": s.startedAt,
                "blockMinutesLeft": max(0, Int(((s.minSeconds ?? Experiment.minBlockSeconds)
                    - (s.activeSeconds ?? 0)) / 60 + 0.99))]
    }

    private func save() {
        guard let s = state, let data = try? JSONEncoder().encode(s) else { return }
        try? data.write(to: Experiment.url, options: .atomic)
    }
}
