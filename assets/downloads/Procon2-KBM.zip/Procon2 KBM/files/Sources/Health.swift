// Machine and timing health.
//
// Two things have bitten this setup before. Memory: Rust wanting more than the
// machine has turns into swap, and swap turns into stutter that feels exactly
// like bad aim. Timing: if reports stop arriving evenly, or the 250 Hz tick
// slips, the mouse moves in lumps. Both are measured here and shown in the
// panel, so "it feels off tonight" has a number next to it instead of a guess.

import Foundation
import Darwin

final class Health {
    private(set) var reportIntervals = Jitter(capacity: 500)
    private(set) var tickIntervals = Jitter(capacity: 500)
    private var lastReport = 0.0
    private var lastTick = 0.0

    struct Jitter {
        private var samples: [Double]
        private var head = 0
        private var filled = 0
        let capacity: Int

        init(capacity: Int) {
            self.capacity = capacity
            samples = [Double](repeating: 0, count: capacity)
        }
        mutating func add(_ v: Double) {
            samples[head] = v
            head = (head + 1) % capacity
            filled = min(filled + 1, capacity)
        }
        var values: [Double] { filled == 0 ? [] : Array(samples[0..<filled]).sorted() }
        var median: Double { let v = values; return v.isEmpty ? 0 : v[v.count / 2] }
        var p99: Double { let v = values; return v.isEmpty ? 0 : v[min(v.count - 1, Int(Double(v.count) * 0.99))] }
        var worst: Double { values.last ?? 0 }
        var rate: Double { median > 0 ? 1 / median : 0 }
    }

    func sawReport(at t: Double) {
        if lastReport > 0, t > lastReport, t - lastReport < 1 { reportIntervals.add(t - lastReport) }
        lastReport = t
    }

    func sawTick(at t: Double) {
        if lastTick > 0, t > lastTick, t - lastTick < 1 { tickIntervals.add(t - lastTick) }
        lastTick = t
    }

    // Memory ------------------------------------------------------------------

    struct Memory {
        var totalGB = 0.0
        var freeGB = 0.0
        var swapUsedGB = 0.0
        var compressedGB = 0.0
        var pressure = "ok"
    }

    static func memory() -> Memory {
        var m = Memory()
        var size = UInt64(0)
        var len = MemoryLayout<UInt64>.size
        if sysctlbyname("hw.memsize", &size, &len, nil, 0) == 0 {
            m.totalGB = Double(size) / 1_073_741_824
        }

        var stats = vm_statistics64()
        var count = mach_msg_type_number_t(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
        let host = mach_host_self()
        let result = withUnsafeMutablePointer(to: &stats) { pointer -> kern_return_t in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(host, HOST_VM_INFO64, $0, &count)
            }
        }
        if result == KERN_SUCCESS {
            let page = Double(vm_kernel_page_size)
            let gb = 1_073_741_824.0
            m.freeGB = (Double(stats.free_count) + Double(stats.inactive_count)) * page / gb
            m.compressedGB = Double(stats.compressor_page_count) * page / gb
        }

        var swap = xsw_usage()
        var swapLen = MemoryLayout<xsw_usage>.size
        if sysctlbyname("vm.swapusage", &swap, &swapLen, nil, 0) == 0 {
            m.swapUsedGB = Double(swap.xsu_used) / 1_073_741_824
        }

        // Swap in use while gaming is the thing that causes the stutter, so
        // that is what decides the wording.
        if m.swapUsedGB > 4 || m.freeGB < 0.5 { m.pressure = "bad" }
        else if m.swapUsedGB > 1.5 || m.freeGB < 1.5 { m.pressure = "tight" }
        else { m.pressure = "ok" }
        return m
    }

    func snapshot() -> [String: Any] {
        let m = Health.memory()
        return [
            "reportRateHz": Int(reportIntervals.rate.rounded()),
            "reportWorstGapMs": round(reportIntervals.worst * 10000) / 10,
            "reportP99Ms": round(reportIntervals.p99 * 10000) / 10,
            "tickRateHz": Int(tickIntervals.rate.rounded()),
            "tickP99Ms": round(tickIntervals.p99 * 10000) / 10,
            "tickWorstMs": round(tickIntervals.worst * 10000) / 10,
            "memTotalGB": round(m.totalGB * 10) / 10,
            "memFreeGB": round(m.freeGB * 10) / 10,
            "swapUsedGB": round(m.swapUsedGB * 100) / 100,
            "compressedGB": round(m.compressedGB * 10) / 10,
            "memPressure": m.pressure,
        ]
    }
}
