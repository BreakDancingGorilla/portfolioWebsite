// procon2-kbm — Switch 2 Pro Controller → keyboard + mouse, for games with no
// controller support. Reads the controller over USB HID, re-centres each stick
// from where it actually rests, and posts keyboard and mouse events.
//
// v5 changes what it is: a service with an HTTP API and a control panel in the
// browser, instead of a program you drive from a terminal window. It also
// finally has real gyro, because report 0x05 turned out to carry a proper
// 6-axis IMU — every earlier attempt was trying to derive rotation from the
// accelerometer alone, which cannot see turning about gravity at all.
//
// Needs: the controller enabled over USB (`procon2 enable`, run automatically
// when a silent controller is plugged in), Accessibility permission to post
// input, and Input Monitoring to read the controller.

import Foundation
import AppKit
import IOKit.hid
import CoreGraphics
import ApplicationServices
import Darwin

setvbuf(stdout, nil, _IOLBF, 0)

let version = "5.0"

func log(_ message: String) {
    let stamp = DateFormatter()
    stamp.dateFormat = "HH:mm:ss"
    print("\(stamp.string(from: Date()))  \(message)")
    Logbook.shared.add(message)
}

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data(("error: " + message + "\n").utf8))
    exit(1)
}

/// The last few hundred log lines, so the panel can show what happened without
/// anyone needing a terminal open.
final class Logbook {
    static let shared = Logbook()
    private let lock = NSLock()
    private var lines: [String] = []

    func add(_ message: String) {
        let stamp = DateFormatter()
        stamp.dateFormat = "HH:mm:ss"
        lock.lock()
        lines.append("\(stamp.string(from: Date())) \(message)")
        if lines.count > 400 { lines.removeFirst(lines.count - 400) }
        lock.unlock()
    }

    func recent(_ n: Int = 60) -> [String] {
        lock.lock(); defer { lock.unlock() }
        return Array(lines.suffix(n).reversed())
    }
}

// MARK: - HID reader

final class Reader {
    private let manager = IOHIDManagerCreate(kCFAllocatorDefault, IOOptionBits(kIOHIDOptionsTypeNone))
    private let buffer = UnsafeMutablePointer<UInt8>.allocate(capacity: 512)
    let mapper: Mapper
    let imu = IMUDecoder()
    private(set) var reportCounts: [Int: Int] = [:]

    init(mapper: Mapper) { self.mapper = mapper }

    var sawIMUReport: Bool { (reportCounts[0x05] ?? 0) > 0 }

    func noteReport(_ id: Int) {
        reportCounts[id, default: 0] += 1
    }

    /// Only one of 0x09 and 0x05 streams at a time — selecting one stops the
    /// other within a few milliseconds — so buttons and sticks are taken from
    /// whichever is arriving.
    func handleReport05Input(_ buf: [UInt8]) {
        guard let parsed = Report05.parse(buf) else { return }
        let buttons = resolveAliases(parsed.buttons)
        usingReport05ForInput = true
        mapper.handle(InputReport(buttons: buttons, leftStick: parsed.leftStick, rightStick: parsed.rightStick))
        chooseReport(buttons)
    }

    /// The last buttons report 0x09 gave, the only report that can tell the
    /// paddles from the triggers.
    var basicButtons: SW2Buttons = []
    /// Trigger and paddle bits held since the switch to 0x05, carried over
    /// from 0x09 so the switch itself doesn't let go of them.
    private var carried: SW2Buttons = []
    /// ZL's bit came on while in 0x05: it may be GL. Held back until 0x09
    /// says which.
    /// Cleared by the next 0x09 report, which settles it. (Until 2026-10-29
    /// 19:50 it was only cleared inside 0x05, which a pending probe never
    /// switches back to: one probe latched the gyro off until a restart.)
    var zlProbe = false

    /// In 0x05, GL sets ZL's bit and GR sets ZR's. Switching in used to
    /// release a held paddle (head look let go, or a short hold turned into a
    /// flashlight/inventory tap) and press aim/fire in its place. Anything
    /// held at the switch keeps its 0x09 identity until its bit goes off. A
    /// new ZL-bit press is held back and settled in 0x09 (~10 ms); a new
    /// ZR-bit press is taken as fire straight away, since first-shot delay
    /// costs more than the rare GR press while aiming.
    private func resolveAliases(_ raw: SW2Buttons) -> SW2Buttons {
        if !usingReport05ForInput {
            carried = basicButtons.intersection([.zl, .gl, .zr, .gr])
            zlProbe = false
        }
        var b = raw.subtracting([.zl, .zr])
        for (trigger, paddle) in [(SW2Buttons.zl, SW2Buttons.gl), (SW2Buttons.zr, SW2Buttons.gr)] {
            let pair = trigger.union(paddle)
            if !raw.contains(trigger) {
                carried.subtract(pair)
                if trigger == .zl { zlProbe = false }
            } else if !carried.intersection(pair).isEmpty {
                b.formUnion(carried.intersection(pair))
            } else if trigger == .zr {
                b.insert(.zr)
            } else {
                zlProbe = true
            }
        }
        return b
    }

    /// Report 0x05 has the gyro but can't tell the back paddles apart from
    /// ZR/ZL; report 0x09 has the paddles but no gyro. So sit in 0x09 and
    /// switch to 0x05 only while the gyro is engaged — it takes ~5 ms either
    /// way. A held paddle keeps it in 0x09; see resolveAliases.
    ///
    /// Right after init it stays in 0x05 for a few seconds so the gyro can
    /// learn its resting drift while the controller is most likely still.
    /// With gyroWhen "firing" the gyro is only for recoil, so 0x05 follows the
    /// trigger (ZR), hip-fire included, instead of the aim button.
    func chooseReport(_ buttons: SW2Buttons) {
        guard initDone else { return }
        let s = mapper.settings
        let zlHeld = buttons.contains(.zl), zrHeld = buttons.contains(.zr)
        let want: UInt8
        if forceBasic || !s.gyro {
            want = 0x09
        } else if zlProbe || buttons.contains(.gl) || buttons.contains(.gr) {
            // A paddle needs 0x09 to work: no gyro while head-looking or
            // hover-looting.
            want = 0x09
        } else if s.gyroWhen == "always" || ProcessInfo.processInfo.systemUptime < warmupUntil {
            want = 0x05
        } else {
            let held: Bool
            switch s.gyroWhen {
            case "firing": held = zrHeld
            case "aimfire": held = zlHeld && zrHeld
            default: held = zlHeld
            }
            want = held ? 0x05 : 0x09
        }
        guard want != selectedReport else { return }
        let t = ProcessInfo.processInfo.systemUptime
        guard t >= nextSwitchAt else { return }
        selectedReport = want
        usbQueue.async {
            do {
                if self.pipe == nil { self.pipe = try VendorPipe() }
                _ = try self.pipe!.send(0x03, 0x0A, [want, 0, 0, 0])
                DispatchQueue.main.async {
                    if self.switchFailures > 0 {
                        log("Report switching works again after \(self.switchFailures) failed attempts.")
                    }
                    self.switchFailures = 0
                    self.switchProblem = nil
                }
            } catch {
                self.pipe = nil
                DispatchQueue.main.async { self.switchFailed(want: want, error: error) }
            }
        }
    }

    /// Failing to switch usually means something else has the controller's
    /// command interface open — Steam, `procon2 daemon`, or a second copy of
    /// this. Retrying on every report (hundreds a second) flooded the terminal
    /// and fixed nothing, so back off: 0.5 s, doubling, capped at 30 s, and
    /// say so once rather than every time. Input keeps flowing from whichever
    /// report is streaming; only the gyro/paddle switch is lost meanwhile.
    private func switchFailed(want: UInt8, error: Error) {
        switchFailures += 1
        let delay = min(30, 0.5 * pow(2, Double(min(switchFailures, 7) - 1)))
        nextSwitchAt = ProcessInfo.processInfo.systemUptime + delay
        selectedReport = 0   // so the next report after the wait tries again
        switchProblem = "can't switch reports (\(error.localizedDescription)) — something else may have the controller open; retrying every \(Int(delay.rounded()))s"
        if switchFailures == 1 || switchFailures == 6 {
            log("Couldn't switch to report 0x\(String(format: "%02X", want)): \(error.localizedDescription)")
            log(switchFailures == 1
                ? "  Retrying with a growing wait. Usually Steam, `procon2 daemon` or a second copy has the controller."
                : "  Still failing — retrying every 30s from now on, quietly.")
        }
    }

    /// Write down everything the controller says about itself, including the
    /// raw HID report descriptor. That lists the report IDs it declares, which
    /// settles whether report 0x05 exists on this interface at all.
    private func describe(_ device: IOHIDDevice) {
        func prop(_ key: String) -> String {
            guard let v = IOHIDDeviceGetProperty(device, key as CFString) else { return "-" }
            return String(describing: v)
        }
        var text = "\n=== interface seen at \(Date()) ===\n"
        for key in ["VendorID", "ProductID", "Product", "Manufacturer", "Transport",
                    "PrimaryUsagePage", "PrimaryUsage", "LocationID", "SerialNumber",
                    "MaxInputReportSize", "MaxOutputReportSize", "MaxFeatureReportSize"] {
            text += "  \(key) = \(prop(key))\n"
        }
        if let data = IOHIDDeviceGetProperty(device, "ReportDescriptor" as CFString) as? Data {
            let bytes = [UInt8](data)
            text += "  declared input report IDs: \(Reader.reportIDs(in: bytes))\n"
            text += "  report descriptor (\(bytes.count) bytes):\n    "
            text += bytes.map { String(format: "%02X", $0) }.joined(separator: " ")
            text += "\n"
        } else {
            text += "  report descriptor: not available\n"
        }
        let dir = Store.directory.appendingPathComponent("diag", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("devices.txt")
        if let h = try? FileHandle(forWritingTo: url) {
            h.seekToEndOfFile()
            h.write(Data(text.utf8))
            try? h.close()
        } else {
            try? text.write(to: url, atomically: true, encoding: .utf8)
        }
    }

    /// Run the controller's init sequence over the USB command pipe (see
    /// VendorPipe). Unplugging resets the controller, so this runs on every
    /// attach. After it, chooseReport flips between 0x09 and 0x05 as needed.
    /// `report: 0x09` pins it to the basic report — no gyro, paddles always
    /// work — until the next plain enableIMU().
    func enableIMU(report: UInt8 = 0x05) {
        initDone = false
        usbQueue.async {
            self.pipe = nil   // initialise opens the interface itself
            let lines = VendorPipe.initialise(report: report)
            DispatchQueue.main.async {
                self.selectedReport = report
                self.switchFailures = 0
                self.nextSwitchAt = 0
                self.switchProblem = nil
                self.forceBasic = report == 0x09
                self.warmupUntil = ProcessInfo.processInfo.systemUptime + 3
                self.initDone = true
                self.commandResults = lines
                let ok = lines.filter { $0.hasSuffix("accepted") }.count
                log("Controller init over USB (report 0x\(String(format: "%02X", report))): \(ok)/\(lines.count) accepted")
                for line in lines where !line.hasSuffix("accepted") { log("  \(line)") }
            }
        }
    }

    /// Walk a HID report descriptor and pull out every Report ID it declares.
    static func reportIDs(in bytes: [UInt8]) -> [String] {
        var ids: [String] = []
        var i = 0
        while i < bytes.count {
            let prefix = bytes[i]
            if prefix == 0xFE {                       // long item
                guard i + 1 < bytes.count else { break }
                i += 3 + Int(bytes[i + 1])
                continue
            }
            let sizeCode = Int(prefix & 0x03)
            let size = sizeCode == 3 ? 4 : sizeCode
            if prefix & 0xFC == 0x84, size >= 1, i + 1 < bytes.count {
                ids.append(String(format: "0x%02X", bytes[i + 1]))
            }
            i += 1 + size
        }
        return ids
    }

    private(set) var hidOpen = false
    private(set) var hidError: String?
    /// Report 0x05 isn't arriving on this controller, so look for the gyro in
    /// report 0x09 instead, scoring layouts against rotation the
    /// accelerometer can see on its own.
    let motionSearch = MotionSearch()
    let rawCapture = RawCapture()
    private var devices: [IOHIDDevice] = []
    var usingReport05ForInput = false
    private let usbQueue = DispatchQueue(label: "procon2.usb", qos: .userInteractive)
    private var pipe: VendorPipe?          // touched only on usbQueue
    private(set) var selectedReport: UInt8 = 0
    private(set) var forceBasic = false
    private var switchFailures = 0
    private var nextSwitchAt = 0.0
    private(set) var switchProblem: String?
    private var initDone = false
    private var warmupUntil = 0.0
    private(set) var commandResults: [String] = []
    private(set) var lockedLayout: (offsets: (Int, Int, Int), countsPerDPS: Double, flip: Double)?
    private(set) var lockedName: String?

    /// Feed one 0x09 payload: either to the search, or to the gyro once the
    /// search has settled.
    func feedMotion(_ payload: [UInt8]) {
        // The 0x09 search is the fallback for a controller whose report 0x05
        // never arrives. When 0x05 works it must stay out of the way: it feeds
        // the same gyro engine, and on locking it set the handedness to +1,
        // overriding the -1 learned and saved from 0x05 (2026-10-28 22:16).
        if sawIMUReport && imu.accelOffset != nil { return }
        if let locked = lockedLayout {
            if let sample = MotionSearch.sample(from: payload, offsets: locked.offsets,
                                                countsPerDPS: locked.countsPerDPS,
                                                flip: locked.flip) {
                mapper.handleIMU(sample)
            }
            return
        }
        motionSearch.feed(payload, t: ProcessInfo.processInfo.systemUptime)
        guard let best = motionSearch.winner,
              let offsets = MotionSearch.offsets(named: best.name) else { return }
        lockedLayout = (offsets, best.countsPerDPS, best.slope >= 0 ? 1 : -1)
        lockedName = best.name
        // The search already measured the sign against real rotation, so hand
        // it over rather than having the gyro work it out again from scratch.
        if mapper.gyro.hand == 0 { mapper.gyro.assumeHand(1) }
        log(String(format: "✓ Found the gyro in report 0x09: %@ (match %+.2f, %.1f counts per °/s). Gyro is available.",
                   best.name, best.correlation, best.countsPerDPS))
        log("  Turn it on in the panel, or Home + \u{002B} on the controller.")
    }

    func start() {
        let matching: [[String: Int]] = [[kIOHIDVendorIDKey: 0x057E, kIOHIDProductIDKey: 0x2069]]
        IOHIDManagerSetDeviceMatchingMultiple(manager, matching as CFArray)

        let context = Unmanaged.passUnretained(self).toOpaque()
        IOHIDManagerRegisterDeviceMatchingCallback(manager, { context, _, _, device in
            Unmanaged<Reader>.fromOpaque(context!).takeUnretainedValue().attach(device)
        }, context)
        IOHIDManagerRegisterDeviceRemovalCallback(manager, { context, _, _, _ in
            Unmanaged<Reader>.fromOpaque(context!).takeUnretainedValue().mapper.controllerRemoved()
        }, context)
        IOHIDManagerScheduleWithRunLoop(manager, CFRunLoopGetCurrent(), CFRunLoopMode.defaultMode.rawValue)

        let result = IOHIDManagerOpen(manager, IOOptionBits(kIOHIDOptionsTypeNone))
        if result == kIOReturnSuccess {
            hidOpen = true
            hidError = nil
            return
        }
        // Running in the background, exiting here would just mean being
        // restarted every few seconds. Stay up, say what's wrong in the panel,
        // and keep trying — the moment the permission is granted it connects.
        hidOpen = false
        hidError = "needs Input Monitoring permission (System Settings → Privacy & Security → Input Monitoring → procon2-kbm)"
        log("⚠️  Can't read the controller yet — \(hidError!)")
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
            guard let self, !self.hidOpen else { return }
            self.start()
        }
    }

    private func attach(_ device: IOHIDDevice) {
        describe(device)
        devices.append(device)
        mapper.controllerAppeared()
        // Give the USB side a moment to settle, then switch on report 0x05.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.enableIMU()
        }
        let context = Unmanaged.passUnretained(self).toOpaque()
        IOHIDDeviceRegisterInputReportCallback(device, buffer, 512, { context, _, _, _, reportID, report, length in
            let reader = Unmanaged<Reader>.fromOpaque(context!).takeUnretainedValue()
            guard length > 0 else { return }
            let bytes = Array(UnsafeBufferPointer(start: report, count: length))
            let id = Int(reportID)
            reader.noteReport(id)
            switch id {
            case 0x09:
                // Buttons and sticks. Untouched since it was first measured.
                let payload = Array(bytes.dropFirst())
                if let parsed = InputReport.parse(payload: payload) {
                    reader.basicButtons = parsed.buttons
                    reader.zlProbe = false
                    reader.usingReport05ForInput = false
                    reader.mapper.handle(parsed)
                    reader.chooseReport(parsed.buttons)
                }
                reader.feedMotion(payload)
                reader.rawCapture.feed(payload, t: ProcessInfo.processInfo.systemUptime)
            case 0x05:
                // The 6-axis IMU. Alignment is worked out from the data itself.
                if let sample = reader.imu.decode(bytes) {
                    reader.mapper.handleIMU(sample)
                }
                reader.handleReport05Input(bytes)
            default:
                break
            }
        }, context)
    }
}

// MARK: - Startup

let arguments = Array(CommandLine.arguments.dropFirst())

if arguments.contains("--help") || arguments.contains("-h") {
    print("""
    procon2-kbm v\(version) — Switch 2 Pro Controller → keyboard + mouse

    USAGE: procon2-kbm [options]
      --port N       control panel / API port (default 7777)
      --no-server    don't start the HTTP server
      --no-console   don't read typed commands
      --any-app      send input regardless of which app is focused
      --game NAME    only send input while this app is focused (default Rust)
      --reset        start from default settings

    Everything else is set from the control panel at http://127.0.0.1:7777
    or by typing commands into this window. Settings live in
    ~/procon2-kbm/config.json.
    """)
    exit(0)
}

func flagValue(_ name: String) -> String? {
    guard let i = arguments.firstIndex(of: name), i + 1 < arguments.count else { return nil }
    return arguments[i + 1]
}

// One copy at a time. Two copies both post mouse movement, which silently
// doubles the look speed — it once ran that way for 35 minutes, caught only
// because recorded recoil pull halved — and both write the session index, which
// tore lines in it. A lock rather than the port, so --no-server can't slip past.
// The kernel drops the lock when the process dies, however it dies.
try? FileManager.default.createDirectory(at: Store.directory, withIntermediateDirectories: true)
let instanceLock = open(Store.directory.appendingPathComponent(".running.lock").path, O_CREAT | O_RDWR, 0o644)
if instanceLock < 0 || flock(instanceLock, LOCK_EX | LOCK_NB) != 0 {
    log("Another copy of procon2-kbm is already running — exiting, so the two don't both move the mouse.")
    log("  To run it in this window instead: zsh ~/procon2-kbm/run.sh (it stops the background copy first).")
    // 0, so launchd doesn't keep restarting this one alongside the other.
    exit(0)
}

let store = Store()
if arguments.contains("--reset") {
    store.settings = Settings()
    store.save()
}
if let game = flagValue("--game") {
    store.settings.game = game
    store.save()
}
if arguments.contains("--any-app") {
    store.apply("anyApp", "on", by: "flag")
}

log("procon2-kbm v\(version) starting")
log("  \(store.settings.summary)")

if !AXIsProcessTrustedWithOptions(["AXTrustedCheckOptionPrompt": true] as CFDictionary) {
    log("""
    ⚠️  This program needs Accessibility permission to send keyboard/mouse input.
        System Settings → Privacy & Security → Accessibility → turn on procon2-kbm.
        It also needs Input Monitoring in the same place.
    """)
}

let mapper = Mapper(store: store)
let experiment = Experiment(store: store)
mapper.experiment = experiment
let reports = ReportRunner()
let tuner = Tuner(experiment: experiment, store: store, reports: reports)
mapper.afterEngagement = { tuner.engagementFinished(shots: $0) }
if tuner.state.enabled {
    log("⚙︎ auto-tune is on (\(tuner.state.history.count) decisions so far) — it only changes settings between fights")
    tuner.check()
}
// One line per start, so the report can tell when the tool restarted mid-session.
let startsURL = Store.directory.appendingPathComponent("starts.jsonl")
if let line = jsonData(["at": Date().timeIntervalSince1970, "version": version]).flatMap({ String(data: $0, encoding: .utf8) }) {
    let before = (try? String(contentsOf: startsURL, encoding: .utf8)) ?? ""
    try? (before + line + "\n").write(to: startsURL, atomically: true, encoding: .utf8)
}
// Drills (IMPROVEMENTS item 5): started and stopped by a button, never
// guessed from the firing pattern. drill.json holds the running one, so a
// restart mid-drill doesn't lose it; drills.jsonl one line per finished run.
// analysis/report.py scores them.
enum Drill {
    static let kinds = ["single", "spray", "flick"]
    static let activeURL = Store.directory.appendingPathComponent("drill.json")
    static let logURL = Store.directory.appendingPathComponent("drills.jsonl")

    static var active: [String: Any]? = {
        guard let data = try? Data(contentsOf: activeURL) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }()

    /// IMPROVEMENTS item 9: a quiet sound right after each shot, one for a
    /// still view and another for a moving one. Only inside a drill whose
    /// Start asked for it, so it can never play in a real fight.
    static let settledSound: NSSound? = { let s = NSSound(named: "Tink"); s?.volume = 0.25; return s }()
    static let movingSound: NSSound? = { let s = NSSound(named: "Bottle"); s?.volume = 0.25; return s }()

    static func shot(steadiness: Double) {
        guard let limit = active?["tick"] as? Double, limit > 0 else { return }
        let sound = steadiness <= limit ? settledSound : movingSound
        sound?.stop()
        sound?.play()
    }

    static func start(_ kind: String, tick: Double?) -> String {
        guard kinds.contains(kind) else { return "no drill called \(kind)" }
        let note = active != nil ? stop() + "; " : ""
        var run: [String: Any] = ["kind": kind, "start": Date().timeIntervalSince1970]
        if let tick = tick, tick > 0 { run["tick"] = tick }
        guard let data = jsonData(run) else { return "couldn't start" }
        try? data.write(to: activeURL, options: .atomic)
        active = run
        return note + "\(kind) drill started" + (run["tick"] != nil ? String(format: ", with a sound after each shot (still below %.2f)", tick!) : "")
    }

    static func stop() -> String {
        guard var run = active, let kind = run["kind"] as? String else { return "no drill running" }
        run["end"] = Date().timeIntervalSince1970
        if let line = jsonData(run).flatMap({ String(data: $0, encoding: .utf8) }) {
            let before = (try? String(contentsOf: logURL, encoding: .utf8)) ?? ""
            try? (before + line + "\n").write(to: logURL, atomically: true, encoding: .utf8)
        }
        try? FileManager.default.removeItem(at: activeURL)
        active = nil
        return "\(kind) drill stopped. Its score is in Aim report → Drills"
    }
}

mapper.recorder.onShot = { steadiness in
    DispatchQueue.main.async { Drill.shot(steadiness: steadiness) }
}

if let running = experiment.snapshot {
    log("⚗︎ experiment still running: \(running["field"] ?? "?") — currently \(running["current"] ?? "?")")
}
let reader = Reader(mapper: mapper)
let combat = CombatLogTail()
combat.start()
// Say at startup whether Rust's log was found, so the combat-log side either
// works or says why not, rather than sitting silently empty.
DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
    let stats = combat.stats()
    log("combat log: \(stats["note"] as? String ?? "?")")
}

// MARK: - API and control panel

let port: UInt16 = flagValue("--port").flatMap { UInt16($0) } ?? 7777
let server = HTTPServer(port: port)
var serverRunning = false

func settingsPayload() -> [[String: Any]] {
    let s = store.settings
    return Settings.fields.map { f -> [String: Any] in
        var entry: [String: Any] = [
            "name": f.name, "group": f.group, "label": f.label,
            "help": f.help, "value": s.value(f),
        ]
        switch f.kind {
        case .number(_, let lo, let hi, let step, _):
            entry["kind"] = "number"
            entry["min"] = lo
            entry["max"] = hi
            entry["step"] = step
        case .toggle:
            entry["kind"] = "toggle"
        case .choice(_, let options):
            entry["kind"] = "choice"
            entry["options"] = options
        }
        return entry
    }
}

func statePayload() -> [String: Any] {
    var live = Live.shared.snapshot()
    live["reports"] = reader.reportCounts.map { ["id": String(format: "0x%02X", $0.key), "count": $0.value] }
    live["imuReportSeen"] = reader.sawIMUReport
    live["gyroSource"] = reader.lockedName.map { "report 0x09, \($0)" }
        ?? (reader.sawIMUReport ? "report 0x05" : "looking for it")
    live["gyroSearch"] = reader.motionSearch.summary
    live["gyroSearchLocked"] = reader.lockedLayout != nil
    live["inputFromReport05"] = reader.usingReport05ForInput
    live["reportMode"] = reader.forceBasic ? "basic only (paddles, no gyro)"
        : reader.selectedReport == 0x05 ? "0x05 (gyro)" : "0x09 (paddles) — 0x05 while gyro is engaged"
    live["rawCapture"] = reader.rawCapture.status
    if let d = Drill.active { live["drill"] = d }
    live["rawCaptureVerdict"] = reader.rawCapture.verdict
    live["imuCommands"] = reader.commandResults
    if let problem = reader.switchProblem { live["reportSwitchProblem"] = problem }
    live["inputMonitoring"] = reader.hidOpen
    if let problem = reader.hidError { live["hidError"] = problem }
    live["imuAlignment"] = reader.imu.accelOffset.map { String(format: "0x%02X", $0) } ?? "not found yet"
    return [
        "version": version,
        "profile": store.activeProfile,
        "profiles": store.profileNames,
        "presets": store.presetNames,
        "settings": settingsPayload(),
        "summary": store.settings.summary,
        "live": live,
        "health": mapper.health.snapshot(),
        "combat": combat.stats(),
        "experiment": experiment.snapshot ?? NSNull(),
        "tuner": tuner.snapshot,
        "experimentPresets": Experiment.presets,
        // What each button does, straight from the table the mapper uses, so
        // the panel can't drift from the real bindings. The paddles are
        // handled outside the table (tap vs hold), so they're added by hand.
        "layout": layout.map { ["button": String(describing: $0.button.rawValue), "label": $0.label] }
            + [["button": "gr", "label": "GR paddle → tap: inventory (Tab), hold: hover loot (H)"],
               ["button": "gl", "label": "GL paddle → tap: flashlight (F), hold: head look (Alt)"]],
        "history": store.recentChanges.map {
            ["at": $0.at, "field": $0.field, "from": $0.from, "to": $0.to,
             "by": $0.by, "profile": $0.profile]
        },
        "log": Logbook.shared.recent(40),
        "accessibility": AXIsProcessTrusted(),
    ]
}

let panelURL = Store.directory.appendingPathComponent("panel.html")

server.route("GET", "/") { _ in
    // Read from disk when it's there, so the panel can be changed without
    // rebuilding anything.
    if let html = try? String(contentsOf: panelURL, encoding: .utf8), !html.isEmpty {
        return .html(html)
    }
    return .html(panelHTML)
}
server.route("GET", "/state") { _ in
    guard let payload = HTTPServer.onMain({ statePayload() }) else {
        return .json(["error": "busy"])
    }
    return .json(payload)
}
/// The Aim report comes from analysis/report.py, run on request and kept for a
/// minute. It's a script rather than Swift so the analysis can change without a
/// rebuild. If it fails, the error is shown in the panel rather than hidden.
final class ReportRunner {
    private let lock = NSLock()
    private var cached: (at: Double, body: Data)?

    func response(refresh: Bool) -> HTTPResponse {
        lock.lock()
        defer { lock.unlock() }
        let now = Date().timeIntervalSince1970
        if !refresh, let c = cached, now - c.at < 60 {
            return HTTPResponse(body: c.body)
        }
        let script = Store.directory.appendingPathComponent("analysis/report.py").path
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        process.arguments = ["-I", script, "--json", "--root", Store.directory.path]
        let out = Pipe(), err = Pipe()
        process.standardOutput = out
        process.standardError = err
        do { try process.run() } catch {
            return .json(["error": "couldn't run the report: \(error.localizedDescription)"])
        }
        DispatchQueue.global().asyncAfter(deadline: .now() + 30) {
            if process.isRunning { process.terminate() }
        }
        // Read both pipes before waiting, or a full pipe stalls both sides.
        // stderr is drained on another thread: read after stdout, a long
        // traceback filling it first would have hung the report for 30 s.
        var problem = Data()
        let drained = DispatchGroup()
        drained.enter()
        DispatchQueue.global().async {
            problem = err.fileHandleForReading.readDataToEndOfFile()
            drained.leave()
        }
        let body = out.fileHandleForReading.readDataToEndOfFile()
        drained.wait()
        process.waitUntilExit()
        guard process.terminationStatus == 0, !body.isEmpty else {
            let text = String(data: problem, encoding: .utf8) ?? ""
            return .json(["error": "the report script failed", "detail": String(text.suffix(1500))])
        }
        cached = (now, body)
        return HTTPResponse(body: body)
    }
}
server.route("GET", "/report") { request in
    reports.response(refresh: request.query["refresh"] != nil)
}

server.route("GET", "/combat") { _ in
    .json(["rows": combat.recentRows().map { $0.dictionary }, "stats": combat.stats()])
}
server.route("GET", "/sessions") { _ in
    let indexURL = Recorder.root.appendingPathComponent("index.jsonl")
    let text = (try? String(contentsOf: indexURL, encoding: .utf8)) ?? ""
    let lines = text.split(separator: "\n").suffix(60).reversed().compactMap { line -> [String: Any]? in
        guard let data = line.data(using: .utf8) else { return nil }
        return (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
    }
    return .json(["engagements": Array(lines)])
}

server.route("POST", "/set") { request in
    let body = request.json
    var results: [String: String] = [:]
    var failed: [String] = []
    let outcome = HTTPServer.onMain {
        for (key, raw) in body {
            let value: String
            if let s = raw as? String { value = s }
            else if let n = raw as? NSNumber { value = n.stringValue }
            else if let b = raw as? Bool { value = b ? "on" : "off" }
            else { failed.append(key); continue }
            if let applied = store.apply(key, value, by: "panel") {
                results[key] = applied
            } else {
                failed.append(key)
            }
        }
        return store.settings.summary
    }
    guard let summary = outcome else { return .json(["ok": false, "error": "busy"]) }
    return .json(["ok": failed.isEmpty, "applied": results, "rejected": failed,
                  "summary": summary])
}

server.route("POST", "/do") { request in
    guard let action = request.string("action") else {
        return .json(["ok": false, "error": "no action"])
    }
    let name = request.string("name") ?? ""
    let result = HTTPServer.onMain { () -> String in
        switch action {
        case "centre", "center":
            mapper.recentreNow()
            return "re-centring the sticks"
        case "undo":
            return store.revertLast() ?? "nothing to undo"
        case "profile":
            if !name.isEmpty, store.switchProfile(to: name) { return "profile \(name)" }
            return "profile \(store.nextProfile())"
        case "preset.save":
            guard !name.isEmpty else { return "a preset needs a name" }
            store.savePreset(name)
            return "saved preset \(name)"
        case "preset.load":
            return store.loadPreset(name) ? "loaded preset \(name)" : "no preset called \(name)"
        case "preset.delete":
            store.deletePreset(name)
            return "deleted preset \(name)"
        case "gyro.recalibrate":
            mapper.relearnGyro()
            return "gyro re-learning — tilt the controller a little"
        case "imu.enable":
            reader.enableIMU()
            return "asked the controller to switch its motion sensor on"
        case "imu.report09":
            reader.enableIMU(report: 0x09)
            return "switched the controller back to report 0x09 (no gyro)"
        case "imu.rescan":
            mapper.relearnGyro()
            reader.imu.reset()
            return "looking for the motion data again"
        case "experiment.start":
            let block = Int(request.string("block") ?? "") ?? 8
            let values = request.string("values").map { $0.split(separator: ",").map(String.init) }
            return experiment.start(field: name, values: values, block: block)
        case "experiment.stop":
            return experiment.stop()
        case "drill.start":
            return Drill.start(name, tick: request.string("tick").flatMap(Double.init))
        case "drill.stop":
            return Drill.stop()
        case "tuner.on":
            return tuner.setEnabled(true)
        case "tuner.off":
            return tuner.setEnabled(false)
        case "quit":
            mapper.releaseAll()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { exit(0) }
            return "stopping"
        default:
            return "don't know how to \(action)"
        }
    }
    let message = result ?? "busy"
    log("· \(message)")
    let summary = HTTPServer.onMain({ store.settings.summary }) ?? ""
    return .json(["ok": true, "message": message, "summary": summary])
}

if !arguments.contains("--no-server") {
    // Keep a copy of the built-in panel on disk the first time, so it can be
    // edited in place afterwards.
    if !FileManager.default.fileExists(atPath: panelURL.path) {
        try? FileManager.default.createDirectory(at: Store.directory, withIntermediateDirectories: true)
        try? panelHTML.write(to: panelURL, atomically: true, encoding: .utf8)
    }
    serverRunning = server.start()
    if serverRunning {
        log("Control panel: http://127.0.0.1:\(port)")
    } else {
        log("⚠️  Couldn't start the control panel: \(server.lastError ?? "unknown"). Carrying on without it.")
    }
}

// Push state to any open panel a few times a second.
let pusher = DispatchSource.makeTimerSource(queue: DispatchQueue.global(qos: .utility))
pusher.schedule(deadline: .now() + 1, repeating: 0.5)
pusher.setEventHandler {
    guard server.listenerCount > 0 else { return }
    guard let payload = HTTPServer.onMain(timeout: 1.0, { statePayload() }),
          let data = jsonData(payload),
          let json = String(data: data, encoding: .utf8) else { return }
    server.broadcast(event: "state", data: json)
}
pusher.resume()

// MARK: - Typed commands (when there's a terminal)

func runCommand(_ raw: String) {
    let parts = raw.split(separator: " ").map(String.init)
    guard let cmd = parts.first?.lowercased() else { return }
    let rest = parts.count > 1 ? parts[1...].joined(separator: " ") : ""

    switch cmd {
    case "help", "?":
        var lines = ["", "settings (type the name and a value):"]
        var group = ""
        for f in Settings.fields {
            if f.group != group { group = f.group; lines.append("  — \(group) —") }
            let name = f.name.padding(toLength: 15, withPad: " ", startingAt: 0)
            lines.append("  \(name)\(f.label)  (now \(store.settings.value(f)))")
        }
        lines += ["", "commands:",
                  "  show            current settings",
                  "  centre          re-measure the stick centres",
                  "  undo            undo the last setting change",
                  "  profile [A|B]   switch profile",
                  "  preset save X / preset load X",
                  "  panel           print the panel address",
                  "  status          controller, gyro and timing",
                  "  gyrocal         make the gyro work out its directions again",
                  "  quit", ""]
        print(lines.joined(separator: "\n"))
    case "show":
        log("⚙︎ \(store.activeProfile): \(store.settings.summary)")
    case "panel":
        log(serverRunning ? "http://127.0.0.1:\(port)" : "the panel isn't running")
    case "status":
        let live = Live.shared.snapshot()
        let counts = reader.reportCounts.sorted { $0.key < $1.key }
            .map { String(format: "0x%02X×%d", $0.key, $0.value) }.joined(separator: " ")
        log("reports: \(counts.isEmpty ? "none yet" : counts)")
        log("IMU: \(reader.sawIMUReport ? "report 0x05 arriving" : "no 0x05 report seen") · alignment \(reader.imu.accelOffset.map { String(format: "0x%02X", $0) } ?? "unknown")")
        log("gyro: \(mapper.gyro.statusLine)")
        log("gyro source: \(reader.lockedName ?? "still looking") · \(reader.motionSearch.summary)")
        log("focus: \(live["focusedApp"] as? String ?? "?") · active \(live["active"] as? Bool ?? false)")
        let h = mapper.health.snapshot()
        log("timing: \(h["reportRateHz"] ?? 0) Hz in, \(h["tickRateHz"] ?? 0) Hz out, worst tick \(h["tickWorstMs"] ?? 0) ms")
        log("memory: \(h["memFreeGB"] ?? 0) GB free of \(h["memTotalGB"] ?? 0), swap \(h["swapUsedGB"] ?? 0) GB (\(h["memPressure"] ?? "?"))")
        log("combat log: \(combat.stats()["note"] as? String ?? "?") · \(combat.rowsParsed) rows")
    case "centre", "center":
        mapper.recentreNow()
    case "undo":
        log("↩ \(store.revertLast() ?? "nothing to undo")")
    case "profile":
        if rest.isEmpty { log("⚙︎ profile \(store.nextProfile())") }
        else if store.switchProfile(to: rest.uppercased()) { log("⚙︎ profile \(store.activeProfile)") }
        else { log("no profile called \(rest)") }
    case "preset":
        let bits = rest.split(separator: " ").map(String.init)
        guard bits.count >= 2 else { log("  preset save NAME  /  preset load NAME"); return }
        let name = bits[1...].joined(separator: " ")
        if bits[0] == "save" { store.savePreset(name); log("saved preset \(name)") }
        else if bits[0] == "load" { log(store.loadPreset(name) ? "loaded \(name)" : "no preset \(name)") }
        else { log("  preset save NAME  /  preset load NAME") }
    case "imuon":
        reader.enableIMU()
    case "report09":
        reader.enableIMU(report: 0x09)
    case "gyrocal":
        mapper.relearnGyro()
        log("gyro re-learning its directions — tilt the controller a little")
    case "quit", "exit":
        mapper.releaseAll()
        log("stopped.")
        exit(0)
    // Short forms kept from v4 so muscle memory still works.
    case "flipx": log("⚙︎ \(store.apply("gyroFlipX", "toggle", by: "console") ?? "?")")
    case "flipy": log("⚙︎ \(store.apply("gyroFlipY", "toggle", by: "console") ?? "?")")
    default:
        if let applied = store.apply(cmd, rest.isEmpty ? "toggle" : rest, by: "console") {
            log("⚙︎ \(applied) — \(store.settings.summary)")
        } else {
            log("don't know \"\(cmd)\" — type help")
        }
    }
}

if !arguments.contains("--no-console"), isatty(STDIN_FILENO) == 1 {
    let thread = Thread {
        while let line = readLine(strippingNewline: true) {
            let raw = line.trimmingCharacters(in: .whitespaces)
            guard !raw.isEmpty else { continue }
            DispatchQueue.main.async { runCommand(raw) }
        }
    }
    thread.stackSize = 1 << 19
    thread.start()
    log("Type commands here, or use the panel. `help` lists them.")
}

// MARK: - Run

mapper.out.clearModifiers()

let activity = ProcessInfo.processInfo.beginActivity(
    options: [.userInitiated, .latencyCritical], reason: "Controller input mapping")

let focus = FocusWatcher()
focus.onChange = { mapper.focusChanged(to: $0) }
focus.start()

reader.start()

let ticker = DispatchSource.makeTimerSource(flags: .strict, queue: .main)
ticker.schedule(deadline: .now(), repeating: .microseconds(4000), leeway: .microseconds(250))
ticker.setEventHandler { mapper.tick() }
ticker.resume()

// Say within a few seconds which motion source we have, if any.
DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
    if reader.sawIMUReport {
        let at = reader.imu.accelOffset.map { String(format: "0x%02X", $0) } ?? "unknown"
        log("✓ Motion report 0x05 is arriving — IMU found at \(at). Gyro is available.")
    } else if (reader.reportCounts[0x09] ?? 0) > 0 {
        log("No 0x05 motion report. Looking for the gyro inside report 0x09 instead —")
        log("  just use the controller normally; moving it is all this needs.")
    }
}

// Write out the raw capture even if it never fills up, so a short session
// still leaves something to work from.
DispatchQueue.main.asyncAfter(deadline: .now() + 100) {
    if reader.rawCapture.active {
        reader.rawCapture.finish()
        log("Raw capture: \(reader.rawCapture.status)")
        log("  \(reader.rawCapture.verdict)")
    }
}

// Report how the search is going, until it settles.
let searchLogger = DispatchSource.makeTimerSource(queue: .main)
searchLogger.schedule(deadline: .now() + 25, repeating: 25)
searchLogger.setEventHandler {
    guard reader.lockedLayout == nil, !reader.sawIMUReport,
          (reader.reportCounts[0x09] ?? 0) > 0 else { return }
    log("gyro search: \(reader.motionSearch.summary)")
}
searchLogger.resume()

let signalSources = [SIGINT, SIGTERM, SIGHUP].map { sig -> DispatchSourceSignal in
    signal(sig, SIG_IGN)
    let source = DispatchSource.makeSignalSource(signal: sig, queue: .main)
    source.setEventHandler {
        mapper.releaseAll()
        log("Stopped — all keys released.")
        exit(0)
    }
    source.resume()
    return source
}

CFRunLoopRun()
