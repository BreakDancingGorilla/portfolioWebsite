// Gyro aiming.
//
// Turning the controller moves the view. Two things make that feel right:
//
//  * Yaw is measured about real-world up, not about any axis of the
//    controller. The accelerometer says which way up is, so however the
//    controller happens to be tilted — held high, resting on a knee, rolled
//    over to one side — turning your hands left still turns the view left by
//    the same amount. This is the part that was impossible before: working out
//    rotation about gravity needs a gyroscope, and until report 0x05 there
//    wasn't one.
//
//  * Pitch is measured about the controller's own left/right axis, flattened
//    into the horizontal plane, so rolling the controller doesn't tilt aim.

import Foundation

struct V3 {
    var x = 0.0, y = 0.0, z = 0.0

    static func + (a: V3, b: V3) -> V3 { V3(x: a.x + b.x, y: a.y + b.y, z: a.z + b.z) }
    static func - (a: V3, b: V3) -> V3 { V3(x: a.x - b.x, y: a.y - b.y, z: a.z - b.z) }
    static func * (a: V3, s: Double) -> V3 { V3(x: a.x * s, y: a.y * s, z: a.z * s) }

    var length: Double { (x * x + y * y + z * z).squareRoot() }
    var unit: V3 { let l = length; return l > 1e-9 ? self * (1 / l) : V3(x: 0, y: 0, z: 1) }
    func dot(_ b: V3) -> Double { x * b.x + y * b.y + z * b.z }
    func cross(_ b: V3) -> V3 {
        V3(x: y * b.z - z * b.y, y: z * b.x - x * b.z, z: x * b.y - y * b.x)
    }
}

final class GyroEngine {
    /// Degrees per second, positive = turn right / look up.
    private(set) var yawRate = 0.0
    private(set) var pitchRate = 0.0

    /// Whether the gyro's sign convention matches the accelerometer's axes.
    /// 0 until worked out, then +1 or -1. Found by comparing the gyro against
    /// the rotation the accelerometer can see on its own, so it needs no
    /// calibration step and nothing from the player.
    private(set) var hand = 0.0
    private(set) var handConfidence = 0.0

    private(set) var bias = V3()
    private(set) var biasSamples = 0.0
    private(set) var up = V3(x: 0, y: 0, z: 1)
    private(set) var temperature = 0.0
    private(set) var still = false

    private var prevUp: V3?
    private var accelUp: V3?
    private static let handNeeded = 0.03
    private var lastT = 0.0
    private var warmup = 0.0

    private static let rad = Double.pi / 180

    /// Feed one IMU sample. `t` is seconds, monotonic.
    func update(_ s: IMUSample, t: Double) {
        let dt = lastT > 0 ? t - lastT : 0
        lastT = t
        temperature = s.tempC
        guard dt > 0.0005, dt < 0.05 else {
            win = DriftWindow()
            // A long gap is ZL let go (0x05 stops): the next aim starts a new
            // hold. A USB hiccup mid-spray (tens of ms) keeps the held tilt,
            // or the pull would cut out until the wrist was re-tilted.
            if dt >= 0.3 { resetHold() }
            return
        }
        warmup += dt

        let accel = V3(x: s.ax, y: s.ay, z: s.az)
        let rawOmega = V3(x: s.gx, y: s.gy, z: s.gz)
        let omegaDPS = rawOmega - bias

        // Resting drift. Grabbed quickly in the first 1.5 s (startup, when the
        // controller is lying still for stick centring) so it's usable straight
        // away. After that it only moves on proof that the controller really
        // wasn't turning.
        //
        // It used to keep learning from any sample under 2.5°/s. 0x05 only
        // arrives while ZL is held, so every one of those samples was mid-aim,
        // and 62% of slow ADS gyro movement is under 2.5°/s: a slow tilt down
        // against recoil was learned as drift, then subtracted when the hands
        // stopped, and the view slid back up. Simulated at 1.5-2.4°/s, 60-80%
        // of the tilt came back within 3 s (2026-10-29 01:50, user: "tilt it
        // down during a spray and hold... goes down then back up").
        let accelOff = abs(accel.length - 1)
        still = accelOff < 0.06 && omegaDPS.length < 2.5
        if warmup < 1.5 {
            if still {
                bias = bias + (rawOmega - bias) * 0.05
                biasSamples += 1
            }
        } else {
            learnDrift(raw: rawOmega, accel: accel, accelOff: accelOff, t: t)
        }

        // Keep track of which way up is. The gyro predicts where up moves to,
        // then the accelerometer pulls it back — but only as far as the
        // accelerometer looks trustworthy, which it isn't mid-flick when the
        // hands are accelerating.
        let omegaRad = omegaDPS * GyroEngine.rad
        let signedOmega = hand != 0 ? omegaRad * hand : omegaRad
        var predicted = up - signedOmega.cross(up) * dt
        let trust = max(0, 1 - accelOff * 5)
        if trust > 0 {
            predicted = predicted + (accel.unit - predicted) * (0.03 * trust)
        }
        let newUp = predicted.unit

        // Work out the gyro's handedness. Rotating the controller makes the
        // measured gravity direction sweep, and that sweep is rotation the
        // accelerometer can see by itself: d(up)/dt = -omega x up. Comparing it
        // against the gyro says whether the two agree or are mirrored.
        //
        // The "up" compared against is tracked from the accelerometer alone,
        // not the fused `up` above (integrated from the gyro with the very sign
        // being learned), and it counts slow movement from ~5°/s rather than
        // only >29°/s. The gyro only reports while ZL is held, and aiming is
        // slow: at the old threshold two whole sessions on 2026-10-28 never
        // finished learning. Simulated aiming at 6-40°/s with sensor noise:
        // 200/200 right, normal and mirrored; the old code decided nothing
        // below 40°/s in a minute of it.
        if handConfidence < 1 {
            if accelOff < 0.1 {
                let a = accel.unit
                let was = accelUp ?? a
                let next = (was + (a - was) * 0.08).unit
                if accelUp != nil {
                    let observed = was.cross((next - was) * (1 / dt)) * -1
                    if observed.length > 0.08 {
                        let perp = omegaRad - was * omegaRad.dot(was)
                        let agreement = perp.dot(observed) * dt
                        handConfidence += abs(agreement)
                        handScore += agreement
                        // Decide once the votes clearly agree (75% one way), or
                        // on the old amount of evidence whatever they say.
                        let clear = abs(handScore) >= 0.5 * handConfidence
                        if (handConfidence > GyroEngine.handNeeded && clear) || handConfidence > 0.35 {
                            hand = handScore >= 0 ? 1 : -1
                            log(String(format: "✓ Gyro: worked out which way round it is (%@, %.0f%% agreement). Gyro now moves the view.",
                                       hand > 0 ? "+1" : "-1", 50 + 50 * abs(handScore) / handConfidence))
                            handConfidence = 1
                        }
                    }
                }
                accelUp = next
            } else {
                accelUp = nil   // hands accelerating: start the track again
            }
        }
        prevUp = newUp
        up = newUp

        guard hand != 0 else {
            yawRate = 0
            pitchRate = 0
            return
        }

        let w = omegaDPS * hand

        // Yaw about real-world up. Right-hand rule about up turns you left, so
        // flip it to make positive mean right.
        yawRate = -w.dot(up)

        // Pitch about the controller's left/right axis, levelled.
        let bodyX = V3(x: 1, y: 0, z: 0)
        let flat = bodyX - up * bodyX.dot(up)
        let pitchAxis = flat.length > 0.25 ? flat.unit : bodyX
        pitchRate = w.dot(pitchAxis)

        heldYaw += yawRate * dt
        heldPitch += pitchRate * dt
    }

    // Hold mode ----------------------------------------------------------------

    /// Degrees turned since ZL went down (the reference), positive = right / up.
    private(set) var heldYaw = 0.0
    private(set) var heldPitch = 0.0
    /// What hold mode is putting out, in counts a second (before flips). The
    /// recording stores this in place of the raw rate; the report reads
    /// "gyro hold" in the settings line and takes it as counts directly.
    private(set) var outYaw = 0.0
    private(set) var outPitch = 0.0
    /// Past this the pull stops growing (and a forgotten tilt can't run away).
    static let holdMax = 25.0
    /// Degrees of down tilt over which sideways gyro fades in.
    static let sideRamp = 0.5

    func resetHold() {
        heldYaw = 0; heldPitch = 0
        outYaw = 0; outPitch = 0
    }

    private var handScore = 0.0

    /// One second of samples, judged as a whole. It counts as still only if
    /// gravity didn't move relative to the controller (the accelerometer sees
    /// any pitch or roll, however slow: 0.3° between the two half-seconds is
    /// 0.6°/s) and the gyro's average stayed within 1°/s of the drift already
    /// known. Then the drift moves 3% of the way to that average, so even a
    /// slow pure-yaw pan that passes both tests shifts it by under 0.05°/s.
    private struct DriftWindow {
        var start = 0.0
        var n = 0, nFirst = 0
        var gyro = V3()
        var accelFirst = V3(), accelSecond = V3()
        var worstAccelOff = 0.0
        var worstGyro = 0.0
    }
    private var win = DriftWindow()

    private func learnDrift(raw: V3, accel: V3, accelOff: Double, t: Double) {
        if win.n == 0 { win.start = t }
        win.n += 1
        win.gyro = win.gyro + raw
        if t - win.start < 0.5 {
            win.accelFirst = win.accelFirst + accel
            win.nFirst += 1
        } else {
            win.accelSecond = win.accelSecond + accel
        }
        win.worstAccelOff = max(win.worstAccelOff, accelOff)
        win.worstGyro = max(win.worstGyro, (raw - bias).length)
        guard t - win.start >= 1.0 else { return }
        defer { win = DriftWindow() }
        guard win.nFirst >= 20, win.n - win.nFirst >= 20 else { return }
        let a = win.accelFirst.unit, b = win.accelSecond.unit
        let turned = acos(max(-1, min(1, a.dot(b)))) / GyroEngine.rad
        let mean = win.gyro * (1 / Double(win.n))
        guard win.worstAccelOff < 0.06, win.worstGyro < 3, turned < 0.3, (mean - bias).length < 1.0 else { return }
        bias = bias + (mean - bias) * 0.03
        biasSamples += Double(win.n)
    }

    /// Tell the engine which way round the gyro is, when something else has
    /// already established it properly. The search in MotionSearch measures
    /// the sign against observed rotation, which is a stronger test than this
    /// class can do on its own, so there's no reason to work it out twice.
    func assumeHand(_ h: Double) {
        hand = h >= 0 ? 1 : -1
        handConfidence = 1
    }

    func resetCalibration() {
        hand = 0
        handScore = 0
        handConfidence = 0
        bias = V3()
        biasSamples = 0
        win = DriftWindow()
        warmup = 0
        prevUp = nil
        accelUp = nil
        up = V3(x: 0, y: 0, z: 1)
    }

    /// Mouse counts for this frame, after sensitivity, tightening and
    /// acceleration. `dt` is the time the rates covered.
    func mouseDelta(dt: Double, settings: Settings) -> (x: Double, y: Double) {
        guard hand != 0 else { return (0, 0) }
        if settings.gyroMode == "hold" {
            // The angle held sets the speed, like a stick: tilt down 5° and
            // hold, and the view keeps going down. This is how the gyro worked
            // before report 0x05 was found (very likely the 0x09 search had
            // locked on to accelerometer bytes, which read tilt rather than
            // turning), and what the user wanted it for: recoil control
            // without winding the wrist further all through a spray.
            //
            // Only the bottom half, as an arc (his design, 2026-10-29): the
            // gyro is for recoil, so tilting toward up does nothing, and
            // sideways only counts while also pulling down. It fades in over
            // the first sideRamp degrees of down tilt so there's no edge.
            // Angles are from where the controller was when the gyro engaged.
            var yaw = heldYaw, pitch = heldPitch
            if settings.gyroFlipX { yaw = -yaw }
            if settings.gyroFlipY { pitch = -pitch }
            let down = -pitch                      // degrees pulling the aim down
            let dead = max(0, settings.gyroHoldDead)
            guard down > dead else { outYaw = 0; outPitch = 0; return (0, 0) }
            let d = min(down, GyroEngine.holdMax) - dead
            let side = max(-GyroEngine.holdMax, min(GyroEngine.holdMax, yaw)) * min(1, d / GyroEngine.sideRamp)
            outYaw = (settings.gyroFlipX ? -side : side) * settings.gyroHold
            outPitch = (settings.gyroFlipY ? d : -d) * settings.gyroHold
            return (x: side * settings.gyroHold * dt, y: d * settings.gyroHold * dt)
        }
        var yaw = yawRate
        var pitch = pitchRate

        // Tightening: scale down very slow movement so resting hands don't
        // creep, without putting a hard edge in the middle of the range.
        let speed = (yaw * yaw + pitch * pitch).squareRoot()
        let floorDPS = max(0, settings.gyroTighten)
        if floorDPS > 0 && speed < floorDPS {
            let k = speed / floorDPS
            yaw *= k
            pitch *= k
        }

        // Acceleration: fast turns get more sensitivity than slow ones, so
        // fine aim stays fine while a spin stays quick.
        var sens = settings.gyroSens
        if settings.gyroAccelOn && settings.gyroAccel > 1 {
            let lo = settings.gyroAccelLow
            let hi = max(lo + 1, settings.gyroAccelHigh)
            let k = min(1, max(0, (speed - lo) / (hi - lo)))
            sens *= 1 + (settings.gyroAccel - 1) * k
        }

        if settings.gyroFlipX { yaw = -yaw }
        if settings.gyroFlipY { pitch = -pitch }
        // Mouse y grows downward, so looking up is a negative delta.
        return (x: yaw * sens * dt, y: -pitch * sens * dt)
    }

    var statusLine: String {
        guard hand != 0 else {
            return String(format: "working out which way round the gyro is (%.0f%%) — hold ZL and tilt the controller a little",
                          min(99, handConfidence / GyroEngine.handNeeded * 100))
        }
        let drift = String(format: "ready · drift %+.2f/%+.2f/%+.2f °/s", bias.x, bias.y, bias.z)
        return temperature > 0 ? drift + String(format: " · %.0f°C", temperature) : drift
    }
}
