// A small HTTP server on 127.0.0.1 so settings can be changed from a browser
// window instead of a terminal.
//
// On latency: this never touches the input path. Reports come in on the HID
// callback and the 250 Hz timer posts mouse movement, both on the main queue.
// The server runs on its own thread and only ever hands work to the main queue
// in short closures — and only when a button is actually pressed, which is
// never during a fight. Reading /state takes a snapshot under a lock and
// copies it; nothing in the game loop waits on a socket.

import Foundation

/// JSONSerialization raises an Objective-C exception, which `try?` can't catch,
/// on infinite or NaN numbers, and that kills the whole tool (2026-10-28 20:43:
/// a fuel tank's HP is "Infinity" in Rust's combat log). Every JSON write goes
/// through here instead.
func jsonData(_ object: Any, options: JSONSerialization.WritingOptions = []) -> Data? {
    guard JSONSerialization.isValidJSONObject(object) else {
        log("⚠︎ skipped writing JSON with an invalid value (infinite or NaN)")
        return nil
    }
    return try? JSONSerialization.data(withJSONObject: object, options: options)
}
import Darwin

struct HTTPRequest {
    let method: String
    let path: String
    let query: [String: String]
    let body: Data
    var headers: [String: String] = [:]     // lower-cased names

    var json: [String: Any] {
        (try? JSONSerialization.jsonObject(with: body)) as? [String: Any] ?? [:]
    }

    /// Form or JSON value, whichever the caller sent.
    func string(_ key: String) -> String? {
        if let v = json[key] {
            if let s = v as? String { return s }
            if let n = v as? NSNumber { return n.stringValue }
            if let b = v as? Bool { return b ? "on" : "off" }
        }
        return query[key]
    }
}

struct HTTPResponse {
    var status = 200
    var contentType = "application/json; charset=utf-8"
    var body = Data()
    var extraHeaders: [String: String] = [:]

    static func json(_ object: Any) -> HTTPResponse {
        let data = jsonData(object, options: [.prettyPrinted, .sortedKeys]) ?? Data("{}".utf8)
        return HTTPResponse(body: data)
    }
    static func text(_ s: String, status: Int = 200) -> HTTPResponse {
        HTTPResponse(status: status, contentType: "text/plain; charset=utf-8", body: Data(s.utf8))
    }
    static func html(_ s: String) -> HTTPResponse {
        HTTPResponse(contentType: "text/html; charset=utf-8", body: Data(s.utf8))
    }
}

final class HTTPServer {
    let port: UInt16
    private var listenFD: Int32 = -1
    private var handlers: [(method: String, path: String, handler: (HTTPRequest) -> HTTPResponse)] = []
    private let eventLock = NSLock()
    private var eventClients: [Int32] = []
    private(set) var requestsServed = 0
    private(set) var lastError: String?

    init(port: UInt16 = 7777) { self.port = port }

    func route(_ method: String, _ path: String, _ handler: @escaping (HTTPRequest) -> HTTPResponse) {
        handlers.append((method, path, handler))
    }

    /// Run `work` on the main queue and wait for its answer. The timeout means
    /// a browser request can never wedge if the main queue is busy.
    static func onMain<T>(timeout: Double = 2.0, _ work: @escaping () -> T) -> T? {
        if Thread.isMainThread { return work() }
        var result: T?
        let done = DispatchSemaphore(value: 0)
        DispatchQueue.main.async {
            result = work()
            done.signal()
        }
        return done.wait(timeout: .now() + timeout) == .success ? result : nil
    }

    @discardableResult
    func start() -> Bool {
        listenFD = socket(AF_INET, SOCK_STREAM, 0)
        guard listenFD >= 0 else { lastError = "socket() failed"; return false }
        var yes: Int32 = 1
        setsockopt(listenFD, SOL_SOCKET, SO_REUSEADDR, &yes, socklen_t(MemoryLayout<Int32>.size))
        setsockopt(listenFD, SOL_SOCKET, SO_NOSIGPIPE, &yes, socklen_t(MemoryLayout<Int32>.size))

        var addr = sockaddr_in()
        addr.sin_family = sa_family_t(AF_INET)
        addr.sin_port = port.bigEndian
        addr.sin_addr.s_addr = inet_addr("127.0.0.1")   // localhost only, never the network
        let bound = withUnsafePointer(to: &addr) { p -> Int32 in
            p.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                bind(listenFD, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard bound == 0 else {
            lastError = "port \(port) is already in use"
            close(listenFD)
            listenFD = -1
            return false
        }
        guard listen(listenFD, 16) == 0 else {
            lastError = "listen() failed"
            close(listenFD)
            listenFD = -1
            return false
        }

        let thread = Thread { [weak self] in self?.acceptLoop() }
        thread.name = "procon2-http"
        thread.stackSize = 1 << 20
        thread.start()
        return true
    }

    private func acceptLoop() {
        while listenFD >= 0 {
            let fd = accept(listenFD, nil, nil)
            guard fd >= 0 else {
                if errno == EINTR { continue }
                usleep(50_000)
                continue
            }
            var yes: Int32 = 1
            setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &yes, socklen_t(MemoryLayout<Int32>.size))
            // A client that connects and never finishes its request used to
            // hold a thread forever; one that stops reading /events blocked
            // every push to every panel. Both give up after a few seconds now.
            var wait = timeval(tv_sec: 5, tv_usec: 0)
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &wait, socklen_t(MemoryLayout<timeval>.size))
            var sendWait = timeval(tv_sec: 2, tv_usec: 0)
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &sendWait, socklen_t(MemoryLayout<timeval>.size))
            let worker = Thread { [weak self] in self?.serve(fd) }
            worker.stackSize = 1 << 20
            worker.start()
        }
    }

    private func readRequest(_ fd: Int32) -> HTTPRequest? {
        var buffer = Data()
        var chunk = [UInt8](repeating: 0, count: 4096)
        var headerEnd: Int?

        while headerEnd == nil {
            let n = recv(fd, &chunk, chunk.count, 0)
            guard n > 0 else { return nil }
            buffer.append(contentsOf: chunk[0..<n])
            headerEnd = HTTPServer.find(Data("\r\n\r\n".utf8), in: buffer)
            if buffer.count > 1 << 20 { return nil }
        }
        guard let end = headerEnd,
              let head = String(data: buffer[0..<end], encoding: .utf8) else { return nil }

        let lines = head.components(separatedBy: "\r\n")
        guard let requestLine = lines.first else { return nil }
        let parts = requestLine.split(separator: " ").map(String.init)
        guard parts.count >= 2 else { return nil }
        let method = parts[0].uppercased()
        let target = parts[1]

        var path = target
        var query: [String: String] = [:]
        if let q = target.firstIndex(of: "?") {
            path = String(target[target.startIndex..<q])
            for pair in target[target.index(after: q)...].split(separator: "&") {
                let kv = pair.split(separator: "=", maxSplits: 1).map(String.init)
                guard let k = kv.first else { continue }
                let v = kv.count > 1 ? kv[1] : ""
                query[HTTPServer.unescape(k)] = HTTPServer.unescape(v)
            }
        }

        var contentLength = 0
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            let kv = line.split(separator: ":", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
            guard kv.count == 2 else { continue }
            headers[kv[0].lowercased()] = kv[1]
            if kv[0].lowercased() == "content-length" { contentLength = min(Int(kv[1]) ?? 0, 1 << 20) }
        }

        var body = buffer.count > end + 4 ? buffer[(end + 4)...] : Data()
        while body.count < contentLength {
            let n = recv(fd, &chunk, chunk.count, 0)
            guard n > 0 else { break }
            body.append(contentsOf: chunk[0..<n])
        }
        return HTTPRequest(method: method, path: path, query: query, body: Data(body), headers: headers)
    }

    private func serve(_ fd: Int32) {
        guard let request = readRequest(fd) else { close(fd); return }
        requestsServed += 1

        // Only this machine's own panel may talk to it. Listening on
        // 127.0.0.1 keeps the network out, but not web pages: any site open in
        // the browser could POST to 127.0.0.1:7777/set (a "simple" request
        // needs no permission) and change settings mid-game, or read /state
        // by pointing its own domain at 127.0.0.1 (DNS rebinding). The Host
        // check stops the second; an Origin from anywhere else stops the first.
        if let refusal = HTTPServer.refuse(request) {
            let text = "HTTP/1.1 403 Forbidden\r\nContent-Type: text/plain\r\nContent-Length: \(refusal.utf8.count)\r\nConnection: close\r\n\r\n\(refusal)"
            _ = send(fd, Array(text.utf8), text.utf8.count, 0)
            close(fd)
            return
        }

        // Server-sent events: the panel keeps this open and gets pushed the
        // state as it changes, instead of asking for it over and over.
        if request.path == "/events" {
            let head = """
            HTTP/1.1 200 OK\r
            Content-Type: text/event-stream\r
            Cache-Control: no-cache\r
            Connection: keep-alive\r
            \r\n
            """
            _ = send(fd, Array(head.utf8), head.utf8.count, 0)
            eventLock.lock()
            eventClients.append(fd)
            eventLock.unlock()
            return   // left open; closed by broadcast when it fails
        }

        let response = handlers.first { $0.method == request.method && $0.path == request.path }?
            .handler(request)
            ?? HTTPResponse.text("not found: \(request.path)", status: 404)

        var head = "HTTP/1.1 \(response.status) \(HTTPServer.reason(response.status))\r\n"
        head += "Content-Type: \(response.contentType)\r\n"
        head += "Content-Length: \(response.body.count)\r\n"
        head += "Cache-Control: no-store\r\n"
        for (k, v) in response.extraHeaders { head += "\(k): \(v)\r\n" }
        head += "Connection: close\r\n\r\n"

        var out = Data(head.utf8)
        out.append(response.body)
        out.withUnsafeBytes { raw in
            var sent = 0
            while sent < raw.count {
                let n = send(fd, raw.baseAddress!.advanced(by: sent), raw.count - sent, 0)
                if n <= 0 { break }
                sent += n
            }
        }
        close(fd)
    }

    /// Push a line to every open /events connection.
    func broadcast(event: String, data: String) {
        let payload = "event: \(event)\ndata: \(data)\n\n"
        let bytes = Array(payload.utf8)
        eventLock.lock()
        var alive: [Int32] = []
        for fd in eventClients {
            let n = send(fd, bytes, bytes.count, 0)
            if n > 0 { alive.append(fd) } else { close(fd) }
        }
        eventClients = alive
        eventLock.unlock()
    }

    var listenerCount: Int {
        eventLock.lock(); defer { eventLock.unlock() }
        return eventClients.count
    }

    // Helpers -----------------------------------------------------------------

    private static func refuse(_ r: HTTPRequest) -> String? {
        let host = (r.headers["host"] ?? "").lowercased()
        let name = host.split(separator: ":").first.map(String.init) ?? ""
        guard ["127.0.0.1", "localhost"].contains(name) else { return "not from this machine's panel" }
        if let origin = r.headers["origin"]?.lowercased(),
           !(origin.hasPrefix("http://127.0.0.1:") || origin.hasPrefix("http://localhost:")) {
            return "requests from other web pages aren't allowed"
        }
        return nil
    }

    private static func find(_ needle: Data, in haystack: Data) -> Int? {
        guard haystack.count >= needle.count else { return nil }
        let bytes = [UInt8](haystack)
        let pattern = [UInt8](needle)
        if bytes.count < pattern.count { return nil }
        for i in 0...(bytes.count - pattern.count) {
            var match = true
            for j in 0..<pattern.count where bytes[i + j] != pattern[j] { match = false; break }
            if match { return i }
        }
        return nil
    }

    private static func unescape(_ s: String) -> String {
        s.replacingOccurrences(of: "+", with: " ").removingPercentEncoding ?? s
    }

    private static func reason(_ status: Int) -> String {
        switch status {
        case 200: return "OK"
        case 400: return "Bad Request"
        case 404: return "Not Found"
        case 500: return "Internal Server Error"
        default: return "OK"
        }
    }
}
