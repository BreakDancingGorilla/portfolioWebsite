// Controller to keyboard and mouse.

import Foundation
import CoreGraphics

let layout: [(button: SW2Buttons, action: Action, label: String)] = [
    (.zr, .mouseLeft, "ZR → attack (left click)"),
    (.zl, .mouseRight, "ZL → aim (right click)"),
    (.b, .key(Key.space), "B (bottom) → jump"),
    (.a, .key(Key.control), "A (right) → crouch"),
    (.home, .key(Key.g), "Home (hold) → map (G) — also the tuning button"),
    (.y, .key(Key.r), "Y (left) → reload"),
    (.x, .key(Key.e), "X (top) → use (E)"),
    (.rStick, .key(Key.b), "R-stick click (hold) → emote wheel (B)"),
    (.lStick, .key(Key.p), "L-stick click → P"),
    (.r, .wheelDown, "R → next hotbar item (scroll)"),
    (.l, .wheelUp, "L → previous hotbar item (scroll)"),
    (.dpadUp, .key(Key.n1), "D-pad ↑ → key 1 (hotbar slot 1 — food)"),
    (.dpadDown, .key(Key.n9), "D-pad ↓ → key 9 (bind to craft bandages)"),
    (.dpadLeft, .key(Key.n0), "D-pad ← → key 0 (bind to swapseats)"),
    (.dpadRight, .key(Key.n8), "D-pad → → combat log on screen (key 8)"),
    (.plus, .key(Key.escape), "+ → menu (Esc)"),
    (.minus, .key(Key.q), "− → crafting (Q)"),
    (.c, .key(Key.v), "C → voice chat (V)"),
    (.capture, .key(Key.n7), "Capture → silent combat log (key 7)"),
]

/// While Home is held, these buttons change settings instead of doing their
/// normal job. Every one of them goes through the store, so it lands in the
/// change log and can be undone.
let tuneButtons: [UInt32: String] = [
    SW2Buttons.dpadUp.rawValue: "speed+",
    SW2Buttons.dpadDown.rawValue: "speed-",
    SW2Buttons.dpadRight.rawValue: "ads+",
    SW2Buttons.dpadLeft.rawValue: "ads-",
    SW2Buttons.r.rawValue: "deadzone+",
    SW2Buttons.l.rawValue: "deadzone-",
    SW2Buttons.zr.rawValue: "curve+",
    SW2Buttons.zl.rawValue: "curve-",
    SW2Buttons.x.rawValue: "boost+",
    SW2Buttons.y.rawValue: "boost-",
    SW2Buttons.c.rawValue: "profile",
    SW2Buttons.minus.rawValue: "undo",
    SW2Buttons.plus.rawValue: "gyro",
    SW2Buttons.b.rawValue: "gyroaccel",
    SW2Buttons.capture.rawValue: "centre",
]

struct MoveKeys {
    var up = false, down = false, left = false, right = false
}

final class Mapper {
    let store: Store
    let out = Output()
    let gyro = GyroEngine()
    let recorder = Recorder()
    let health = Health()
    var settings: Settings

    private var center = (lx: 2048.0, ly: 2048.0, rx: 2048.0, ry: 2048.0)
    private var calibrated = false
    private var calibrationStartsAt = 0.0
    private var samples: [InputReport] = []

    private var latest: InputReport?
    private var lastReportAt = 0.0
    private var prevButtons: SW2Buttons = []
    private var holds: [String: (count: Int, action: Action)] = [:]
    private var moveKeys = MoveKeys()
    private var sprinting = false
    private var sprintLatched = false
    private var walking = false
    private var walkHeld: CGKeyCode?
    private var fracX = 0.0, fracY = 0.0
    private var lastTick = ProcessInfo.processInfo.systemUptime
    private var lastCursorCheck = 0.0
    private var cursorShown = false
    private var lastPublish = 0.0
    private var lastCombatLogAt = 0.0
    private var gyroPend = (x: 0.0, y: 0.0)
    private var gyroLastAt = 0.0
    private var gyroWasAiming = false
    private(set) var imuSamples = 0
    private(set) var lastIMUAt = 0.0

    private var edgeSince: Double?
    /// How far the right stick has actually gone in each direction since the
    /// last re-centre, in raw counts from the centre. A value only counts once
    /// it has been held for three reports in a row, so a single glitch can't
    /// set it. This is what showed the right side stopping at ~0.88.
    private var reach = (right: 0.0, left: 0.0, up: 0.0, down: 0.0)
    private var reachRecent: [(Double, Double)] = []
    private(set) var active = false

    // GL paddle: tap = flashlight (F), hold = head look (Alt).
    private var glDownAt: Double?
    private var headLooking = false
    // GR paddle: tap = inventory (Tab), hold = hover loot (H).
    private var grDownAt: Double?
    private var grLooting = false
    static let holdDelay = 0.2

    init(store: Store) {
        self.store = store
        self.settings = store.settings
        store.onChange = { [weak self] in
            guard let self else { return }
            self.settings = self.store.settings
            self.recorder.profileName = self.store.activeProfile
            self.recorder.settingsSummary = self.store.settings.summary
        }
        recorder.profileName = store.activeProfile
        recorder.settingsSummary = store.settings.summary
        recorder.context = { [weak self] in
            guard let self else { return [:] }
            var extra: [String: Any] = ["gyroReady": self.settings.gyro && self.gyro.hand != 0, "gyroAsApplied": true]
            if let tag = self.experiment?.tag { extra["experiment"] = tag }
            return extra
        }
        recorder.onFinish = { [weak self] shots in
            self?.experiment?.engagementFinished(shots: shots)
            self?.afterEngagement?(shots)
        }
        if let saved = try? String(contentsOf: Mapper.handURL, encoding: .utf8),
           let h = Double(saved.trimmingCharacters(in: .whitespacesAndNewlines)), h != 0 {
            gyro.assumeHand(h)
            handSaved = true
        }
    }

    var experiment: Experiment?
    /// Runs after the experiment has counted the engagement (the auto-tuner).
    var afterEngagement: ((Int) -> Void)?

    /// Forget the saved gyro handedness as well as the live calibration, so a
    /// re-learn really starts over.
    func relearnGyro() {
        gyro.resetCalibration()
        try? FileManager.default.removeItem(at: Mapper.handURL)
        handSaved = false
    }

    /// Which way round the gyro is depends on the controller, not the session,
    /// but it used to be relearned on every start — and until it was, the gyro
    /// did nothing at all, silently, for the first aims of every session. Kept
    /// here once learned. "Re-learn gyro" in the panel clears it.
    static let handURL = Store.directory.appendingPathComponent("gyro-hand.txt")
    private var handSaved = false

    private var now: Double { ProcessInfo.processInfo.systemUptime }

    // Controller events -------------------------------------------------------

    func controllerAppeared() {
        let appearedAt = now
        startCalibration(quiet: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            guard let self, self.lastReportAt < appearedAt else { return }
            log("Controller connected but not sending input — running `procon2 enable`...")
            let process = Process()
            process.executableURL = URL(fileURLWithPath: "/bin/zsh")
            process.arguments = ["-lc", "procon2 enable"]
            do { try process.run() } catch { log("Couldn't run procon2 enable: \(error)") }
        }
    }

    func controllerRemoved() {
        releaseAll()
        latest = nil
        log("Controller disconnected — plug it back in; it'll be re-enabled automatically.")
    }

    func handle(_ report: InputReport) {
        latest = report
        let t = now
        lastReportAt = t
        health.sawReport(at: t)

        if !calibrated {
            collectCalibration(report)
            prevButtons = report.buttons
            return
        }
        let buttons = report.buttons
        if active {
            processButtons(buttons)
        } else if buttons.contains(.home) && buttons.contains(.capture)
                    && !(prevButtons.contains(.home) && prevButtons.contains(.capture)) {
            // Home + Capture re-centres even while paused (another app in
            // front). It sends no keys, and re-centring is most often needed
            // just after alt-tabbing back from the panel.
            recentreNow()
        }
        prevButtons = buttons
    }

    /// One IMU sample from report 0x05.
    func handleIMU(_ sample: IMUSample) {
        let t = now
        imuSamples += 1
        lastIMUAt = t
        gyro.update(sample, t: t)

        // Advance the clock on every sample, not just the ones that move the
        // view. Otherwise stopping aiming for a while leaves a stale timestamp
        // behind, and the first frame after aiming again covers that whole gap
        // in one step — a small jerk exactly when the shot is being lined up.
        // A gap means the controller was in report 0x09 (not aiming); start
        // the next stretch from zero rather than integrating across it.
        let gap = t - gyroLastAt
        let dt = gyroLastAt > 0 && gap < 0.05 ? gap : 0
        gyroLastAt = t

        let s = settings
        // Hold mode measures from where the controller was when the gyro
        // engaged: the trigger press ("firing") or ZL ("ads").
        let engaged = gyroEngaged(s)
        if engaged != gyroWasAiming {
            gyroWasAiming = engaged
            gyro.resetHold()
        }
        guard s.gyro, gyro.hand != 0, active, dt > 0 else { return }
        guard s.gyroWhen == "always" || engaged else { return }
        // Hold needs a reference point; with "always", outside it, it turns.
        var gs = s
        if !engaged { gs.gyroMode = "turn" }
        let d = gyro.mouseDelta(dt: dt, settings: gs)
        gyroPend.x += d.x
        gyroPend.y += d.y
    }

    private func gyroEngaged(_ s: Settings) -> Bool {
        switch s.gyroWhen {
        case "firing": return out.leftDown
        case "aimfire": return out.leftDown && out.rightDown
        default: return out.rightDown
        }
    }

    // Calibration ------------------------------------------------------------

    func recentreNow() { startCalibration(quiet: false) }

    /// Normal resting offsets on this controller are -7..+215 counts.
    static let maxRestOffset = 600.0
    private var farCentreTries = 0

    private func startCalibration(quiet: Bool) {
        farCentreTries = 0
        releaseAll()
        calibrated = false
        samples = []
        calibrationStartsAt = now + 0.5
        log(quiet ? "Measuring stick centres — keep your thumbs off the sticks..."
                  : "Re-centring — take your thumbs off the sticks...")
    }

    private func collectCalibration(_ report: InputReport) {
        guard now >= calibrationStartsAt else { return }
        samples.append(report)
        guard samples.count >= 45 else { return }

        var sum = (lx: 0.0, ly: 0.0, rx: 0.0, ry: 0.0)
        for s in samples {
            sum.lx += Double(s.leftStick.x); sum.ly += Double(s.leftStick.y)
            sum.rx += Double(s.rightStick.x); sum.ry += Double(s.rightStick.y)
        }
        let n = Double(samples.count)
        let c = (lx: sum.lx / n, ly: sum.ly / n, rx: sum.rx / n, ry: sum.ry / n)
        var spread = 0.0
        for s in samples {
            spread = max(spread, abs(Double(s.leftStick.x) - c.lx))
            spread = max(spread, abs(Double(s.leftStick.y) - c.ly))
            spread = max(spread, abs(Double(s.rightStick.x) - c.rx))
            spread = max(spread, abs(Double(s.rightStick.y) - c.ry))
        }
        if spread > 150 {
            log("A stick moved while measuring — trying again...")
            samples = []
            calibrationStartsAt = now + 0.5
            return
        }
        // "A stick moved" only catches movement. A thumb resting on a stick is
        // steady pressure, and was accepted as centre on 2026-10-28 23:56:
        // left (+1032, -1149), right (+1160) against a normal -7..+215. Retry
        // anything that far out; after ~10 s accept it, in case a stick really
        // has drifted that much, but say so.
        let worst = [c.lx, c.ly, c.rx, c.ry].map { abs($0 - 2048) }.max() ?? 0
        if worst > Mapper.maxRestOffset && farCentreTries < 20 {
            if farCentreTries % 6 == 0 {
                log(String(format: "A stick reads %.0f counts off centre — thumbs on the sticks? Let go, measuring again...", worst))
            }
            farCentreTries += 1
            samples = []
            calibrationStartsAt = now + 0.5
            return
        }
        if worst > Mapper.maxRestOffset {
            log(String(format: "⚠︎ A stick still rests %.0f counts off centre after 10 s. Accepting it; if the view drifts, press Capture with your thumbs off the sticks.", worst))
        }
        farCentreTries = 0
        center = c
        calibrated = true
        reach = (0, 0, 0, 0)
        reachRecent = []
        log(String(format: "✓ Centred. Resting offset: left (%+.0f, %+.0f), right (%+.0f, %+.0f) counts — cancelled out.",
                   c.lx - 2048, c.ly - 2048, c.rx - 2048, c.ry - 2048))
    }

    // Buttons ----------------------------------------------------------------

    private func processButtons(_ buttons: SW2Buttons) {
        let homeHeld = buttons.contains(.home)

        if buttons.contains(.gr) && !prevButtons.contains(.gr) {
            grDownAt = now
        } else if !buttons.contains(.gr) && prevButtons.contains(.gr) {
            if grLooting {
                grLooting = false
                hold(.key(Key.h), false)
            } else if grDownAt != nil {
                tap(Key.tab)
            }
            grDownAt = nil
        }

        if buttons.contains(.gl) && !prevButtons.contains(.gl) {
            glDownAt = now
        } else if !buttons.contains(.gl) && prevButtons.contains(.gl) {
            if headLooking {
                headLooking = false
                hold(.key(Key.option), false)
            } else if glDownAt != nil {
                tap(Key.f)
            }
            glDownAt = nil
        }

        for entry in layout {
            let isDown = buttons.contains(entry.button)
            let wasDown = prevButtons.contains(entry.button)
            if isDown == wasDown { continue }

            if homeHeld, let name = tuneButtons[entry.button.rawValue] {
                if isDown { tune(name); continue }
                if (holds[entry.action.id]?.count ?? 0) == 0 { continue }
            }

            if case .sprint = entry.action {
                if isDown && !sprintLatched {
                    sprintLatched = true
                    if !sprinting { sprinting = true; hold(.key(Key.shift), true) }
                }
                continue
            }
            hold(entry.action, isDown)
        }
    }

    private func hold(_ action: Action, _ on: Bool) {
        let id = action.id
        let n = holds[id]?.count ?? 0
        let m = on ? n + 1 : max(0, n - 1)
        holds[id] = (m, action)
        if n == 0 && m > 0 { perform(action, true) }
        else if n > 0 && m == 0 { perform(action, false) }
    }

    private func tap(_ code: CGKeyCode) {
        hold(.key(code), true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
            self?.hold(.key(code), false)
        }
    }

    private func perform(_ action: Action, _ down: Bool) {
        switch action {
        case .key(let code): out.key(code, down)
        case .mouseLeft: out.button(left: true, down)
        case .mouseRight: out.button(left: false, down)
        case .mouseMiddle: out.middleButton(down)
        case .wheelUp: if down { out.wheel(1) }
        case .wheelDown: if down { out.wheel(-1) }
        case .sprint: out.key(Key.shift, down)
        }
    }

    func releaseAll() {
        for (_, entry) in holds where entry.count > 0 { perform(entry.action, false) }
        holds = [:]
        out.clearModifiers()
        moveKeys = MoveKeys()
        sprinting = false
        sprintLatched = false
        walking = false
        walkHeld = nil
        glDownAt = nil
        headLooking = false
        grDownAt = nil
        grLooting = false
        gyroPend = (0, 0)
        fracX = 0
        fracY = 0
        recorder.finish()
    }

    /// Home + button. Each one is a normal setting change, logged like any other.
    private func tune(_ name: String) {
        switch name {
        case "speed+": store.apply("speed", "x1.1", by: "controller")
        case "speed-": store.apply("speed", "x0.909", by: "controller")
        case "ads+": store.apply("ads", "+0.05", by: "controller")
        case "ads-": store.apply("ads", "+-0.05", by: "controller")
        case "deadzone+": store.apply("deadzone", "+0.005", by: "controller")
        case "deadzone-": store.apply("deadzone", "+-0.005", by: "controller")
        // In hold mode gyroSens does nothing, so the gyro strength buttons
        // change hold strength instead.
        case "curve+":
            if settings.gyro { store.apply(settings.gyroMode == "hold" ? "gyroHold" : "gyroSens", "x1.2", by: "controller") }
            else { store.apply("curve", "+0.05", by: "controller") }
        case "curve-":
            if settings.gyro { store.apply(settings.gyroMode == "hold" ? "gyroHold" : "gyroSens", "x0.833", by: "controller") }
            else { store.apply("curve", "+-0.05", by: "controller") }
        case "boost+": store.apply("boost", "+0.25", by: "controller")
        case "boost-": store.apply("boost", "+-0.25", by: "controller")
        case "profile":
            let name = store.nextProfile()
            log("⚙︎ profile \(name) — \(settings.summary)")
            return
        case "undo":
            if let what = store.revertLast() { log("↩ \(what)") } else { log("↩ nothing to undo") }
            return
        case "gyro":
            store.apply("gyro", "toggle", by: "controller")
        case "gyroaccel":
            store.apply("gyroAccelOn", "toggle", by: "controller")
        case "centre":
            recentreNow()
            return
        default: return
        }
        log("⚙︎ \(settings.summary)")
    }

    // Focus and the tick ------------------------------------------------------

    func focusChanged(to appName: String) {
        let focused = settings.anyApp || appName.localizedCaseInsensitiveContains(settings.game)
        guard focused != active else { return }
        active = focused
        if !active { releaseAll() }
        let shown = appName.isEmpty ? "another app" : appName
        log(active ? "▶︎ \(shown) focused — controller active"
                   : "⏸ \(shown) focused — controller paused")
        Live.shared.set(["focusedApp": shown, "active": active])
    }

    func tick() {
        let t = now
        let dt = min(0.05, max(0, t - lastTick))
        lastTick = t
        health.sawTick(at: t)
        if t - lastPublish > 0.1 { lastPublish = t; publish(t) }

        // Dump the combat log every so often, on the silent key. This is the
        // only input the tool sends that wasn't asked for by a button press,
        // and all it does is make the game write its own log to disk — it
        // touches nothing in the world and nothing about aiming.
        // Not while a cursor is showing: that's the console, chat, inventory or
        // a menu, where the key would be typed as a "7" instead of dumping.
        if settings.autoCombatLog, active, calibrated, !cursorShown,
           t - lastCombatLogAt > max(5, settings.combatLogEvery) {
            lastCombatLogAt = t
            tap(Key.n7)
        }

        guard calibrated, active, let report = latest else { return }
        if t - lastReportAt > 0.5 {
            if holds.values.contains(where: { $0.count > 0 }) { releaseAll() }
            return
        }
        let s = settings

        if let at = glDownAt, !headLooking, t - at >= Mapper.holdDelay {
            headLooking = true
            hold(.key(Key.option), true)
        }
        if let at = grDownAt, !grLooting, t - at >= Mapper.holdDelay {
            grLooting = true
            hold(.key(Key.h), true)
        }

        let (lx, ly) = normalized(report.leftStick, cx: center.lx, cy: center.ly, range: s.range)
        noteReach(report.rightStick)
        let (rx, ry) = s.evenReach
            ? normalizedEven(report.rightStick, cx: center.rx, cy: center.ry, range: s.range)
            : normalized(report.rightStick, cx: center.rx, cy: center.ry, range: s.range)

        // Left stick → movement.
        setMove(\.up, key: Key.w, amount: ly, s)
        setMove(\.down, key: Key.s, amount: -ly, s)
        setMove(\.left, key: Key.a, amount: -lx, s)
        setMove(\.right, key: Key.d, amount: lx, s)

        let push = (lx * lx + ly * ly).squareRoot()
        if sprintLatched {
            if push < 0.3 {
                sprintLatched = false
                if sprinting { sprinting = false; hold(.key(Key.shift), false) }
            }
        } else if s.analogMove {
            // A small push walks, a full push sprints. This is the thing a
            // stick can do that a keyboard can't: footstep noise and recoil
            // both depend on how fast you're going, and a key is all or nothing.
            //
            // Which end of the stick holds the key depends on the game. Some
            // already run by default and use the modifier to slow you down, in
            // which case holding it at full tilt does the opposite of what you
            // want — gentle pushes sprint and hard pushes crawl.
            if s.shiftIsWalk {
                if !sprinting && push > 0.08 && push < s.sprintOff {
                    sprinting = true
                    hold(.key(Key.shift), true)
                } else if sprinting && (push >= s.sprintAt || push <= 0.05) {
                    sprinting = false
                    hold(.key(Key.shift), false)
                }
            } else {
                if !sprinting && push >= s.sprintAt {
                    sprinting = true
                    hold(.key(Key.shift), true)
                } else if sprinting && push < s.sprintOff {
                    sprinting = false
                    hold(.key(Key.shift), false)
                }
            }
        } else if sprinting && push < 0.3 {
            sprinting = false
            hold(.key(Key.shift), false)
        }

        // Optional third speed, for anyone who's bound Walk in the game.
        // The key is remembered while held: turning analog move off, or
        // changing the walk key, mid-walk used to leave the old key held down.
        let walkKey = s.analogMove ? Key.byName[s.walkKey] : nil
        if let held = walkHeld, walkKey != held {
            hold(.key(held), false)
            walkHeld = nil
            walking = false
        }
        if let walkKey {
            let want = push > 0.08 && push < s.walkAt
            if want != walking {
                walking = want
                hold(.key(walkKey), want)
                walkHeld = want ? walkKey : nil
            }
        }

        // Right stick → mouse.
        let magnitude = (rx * rx + ry * ry).squareRoot()
        if magnitude > s.deadzone {
            let tilt = min(1, (magnitude - s.deadzone) / (1 - s.deadzone))
            let aiming = out.rightDown
            let aim = aiming ? s.ads : 1

            var yawBoost = 1.0
            if !aiming && tilt >= s.boostEdge && s.boost > 1 {
                let since = edgeSince ?? t
                edgeSince = since
                let held = t - since - s.boostDelay
                if held > 0 {
                    yawBoost = 1 + (s.boost - 1) * min(1, held / max(0.01, s.boostRamp))
                }
            } else {
                edgeSince = nil
            }
            let distance = s.speed * pow(tilt, s.curve) * aim * dt
            // Per-direction gain from the calibrator; ry > 0 is up.
            let gx = rx >= 0 ? (aiming ? s.adsGainRight : s.gainRight) : (aiming ? s.adsGainLeft : s.gainLeft)
            let gy = ry >= 0 ? (aiming ? s.adsGainUp : s.gainUp) : (aiming ? s.adsGainDown : s.gainDown)
            fracX += rx / magnitude * distance * yawBoost * gx
            fracY += -ry / magnitude * distance * gy
        } else {
            edgeSince = nil
        }

        fracX += gyroPend.x
        fracY += gyroPend.y
        gyroPend = (0, 0)

        let dx = Int(fracX.rounded(.towardZero))
        let dy = Int(fracY.rounded(.towardZero))
        fracX -= Double(dx)
        fracY -= Double(dy)
        if t - lastCursorCheck > 0.1 {
            lastCursorCheck = t
            cursorShown = cursorIsVisible()
        }
        if dx != 0 || dy != 0 { out.move(dx: dx, dy: dy, moveCursor: cursorShown) }

        // Recorded as it moved the view: after the "reverse" settings. Before
        // 2026-10-29 02:50 it was recorded before them, and with both reversed
        // (on since 23:21 Oct 28) every gyro direction in the report was
        // backwards (index lines without "gyroAsApplied"; the report corrects
        // those from the settings history).
        let holdOn = s.gyroMode == "hold" && gyroEngaged(s)
        let fx: Float = s.gyroFlipX ? -1 : 1, fy: Float = s.gyroFlipY ? -1 : 1
        recorder.add(Frame(
            t: t,
            lx: Float(lx), ly: Float(ly), rx: Float(rx), ry: Float(ry),
            gyroYaw: fx * Float(holdOn ? gyro.outYaw : gyro.yawRate),
            gyroPitch: fy * Float(holdOn ? gyro.outPitch : gyro.pitchRate),
            dx: Int32(dx), dy: Int32(dy),
            buttons: report.buttons.rawValue,
            ads: out.rightDown, firing: out.leftDown
        ), enabled: s.record)
    }

    private func normalized(_ stick: (x: Int, y: Int), cx: Double, cy: Double, range: Double) -> (Double, Double) {
        var x = (Double(stick.x) - cx) / range
        var y = (Double(stick.y) - cy) / range
        let magnitude = (x * x + y * y).squareRoot()
        if magnitude > 1 { x /= magnitude; y /= magnitude }
        return (x, y)
    }

    /// The stick's gate is roughly centred on the nominal 2048, but it rests
    /// off to one side, and everything is measured from where it rests. So
    /// the side it rests towards runs out early. Scale that side by the
    /// shorter distance; leave the other side alone, so nothing gets slower.
    private func normalizedEven(_ stick: (x: Int, y: Int), cx: Double, cy: Double, range: Double) -> (Double, Double) {
        let ox = cx - 2048, oy = cy - 2048
        let dx = Double(stick.x) - cx, dy = Double(stick.y) - cy
        let rangeX = (dx > 0) == (ox > 0) ? max(range * 0.5, range - abs(ox)) : range
        let rangeY = (dy > 0) == (oy > 0) ? max(range * 0.5, range - abs(oy)) : range
        var x = dx / rangeX
        var y = dy / rangeY
        let magnitude = (x * x + y * y).squareRoot()
        if magnitude > 1 { x /= magnitude; y /= magnitude }
        return (x, y)
    }

    private func noteReach(_ stick: (x: Int, y: Int)) {
        reachRecent.append((Double(stick.x) - center.rx, Double(stick.y) - center.ry))
        if reachRecent.count > 3 { reachRecent.removeFirst() }
        guard reachRecent.count == 3 else { return }
        let xs = reachRecent.map { $0.0 }, ys = reachRecent.map { $0.1 }
        reach.right = max(reach.right, xs.min()!)
        reach.left = max(reach.left, -xs.max()!)
        reach.up = max(reach.up, ys.min()!)
        reach.down = max(reach.down, -ys.max()!)
    }

    private func setMove(_ path: WritableKeyPath<MoveKeys, Bool>, key: CGKeyCode,
                         amount: Double, _ s: Settings) {
        let isOn = moveKeys[keyPath: path]
        let shouldBeOn = isOn ? amount > s.moveOff : amount > s.moveOn
        if shouldBeOn != isOn {
            moveKeys[keyPath: path] = shouldBeOn
            hold(.key(key), shouldBeOn)
        }
    }

    // What the panel sees -----------------------------------------------------

    private func publish(_ t: Double) {
        if gyro.hand == 0 {
            handSaved = false
        } else if !handSaved {
            handSaved = true
            try? "\(gyro.hand)\n".write(to: Mapper.handURL, atomically: true, encoding: .utf8)
        }
        Live.shared.set([
            "active": active,
            "calibrated": calibrated,
            "controllerConnected": t - lastReportAt < 1.0,
            "secondsSinceReport": round((t - lastReportAt) * 10) / 10,
            "imuAvailable": imuSamples > 0 && t - lastIMUAt < 1.0,
            "imuSamples": imuSamples,
            "gyroReady": gyro.hand != 0,
            "gyroStatus": gyro.statusLine,
            "gyroYawRate": round(gyro.yawRate * 10) / 10,
            "gyroPitchRate": round(gyro.pitchRate * 10) / 10,
            "gyroHeldYaw": round(gyro.heldYaw * 100) / 100,
            "gyroHeldPitch": round(gyro.heldPitch * 100) / 100,
            "gyroDriftDPS": round(gyro.bias.length * 100) / 100,
            "gyroStill": gyro.still,
            "aiming": out.rightDown,
            "firing": out.leftDown,
            "sprinting": sprinting,
            "walking": walking,
            "engagements": recorder.engagementsThisRun,
            // Fractions of `range`, measured from the re-centred rest point.
            // Anything at 1.0 or above is clipped: there is travel left over.
            "rightStickReach": [
                "right": round(reach.right / settings.range * 1000) / 1000,
                "left": round(reach.left / settings.range * 1000) / 1000,
                "up": round(reach.up / settings.range * 1000) / 1000,
                "down": round(reach.down / settings.range * 1000) / 1000,
                "restOffsetCounts": [Int(center.rx - 2048), Int(center.ry - 2048)],
            ],
            "lastEngagement": recorder.lastSummary,
            "profile": store.activeProfile,
            "summary": settings.summary,
        ])
    }
}
