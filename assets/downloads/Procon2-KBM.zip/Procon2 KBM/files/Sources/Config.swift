// Settings, profiles, presets and the record of every change.
//
// Everything tunable is declared once, in `Settings.fields`. The HTTP API, the
// control panel, the typed console and the Home-button shortcuts all read that
// one table, so adding a setting means adding a line here and nothing else.
//
// Settings live in ~/procon2-kbm/config.json. That matters for two reasons: it
// survives rebuilds, and it's a plain file in a folder that can be read from
// outside, so the exact numbers behind a good or bad session can be looked at
// afterwards instead of guessed at.

import Foundation

struct Settings: Codable, Equatable {
    // Look --------------------------------------------------------------------
    var speed = 2049.0        // mouse counts per second at full right-stick tilt
    var ads = 0.85            // look-speed multiplier while aiming
    var deadzone = 0.01       // fraction of full tilt ignored after re-centring
    var curve = 1.50          // 1 = linear; >1 = finer near centre
    var range = 1650.0        // raw counts from centre that count as full tilt
    var boost = 1.75          // turn boost at the edge of the stick (1 = off)
    var boostEdge = 0.90      // tilt that counts as "all the way out"
    var boostDelay = 0.10     // seconds at the edge before the boost starts
    var boostRamp = 0.30      // seconds to reach the full boost
    /// Measured on his controller: the right stick rests ~174 counts right of
    /// the middle of its gate, so measured from the rest point it only reaches
    /// ~0.88 of `range` turning right but clips past 1.0 turning left. With
    /// this on, the short side of each right-stick axis is scaled by its own
    /// shorter range; the long side is left exactly as it was. Off by default
    /// because it changes how fast rightward turns feel.
    var evenReach = false
    /// Per-direction stick speed, hip-fire and aimed apart. Set by the
    /// calibrator (analysis/report.py "calibrate"), which measures how far
    /// each flick's first movement went against where he settled, per
    /// direction: overshooting right by 6% means right is 6% too fast.
    var gainRight = 1.0, gainLeft = 1.0, gainUp = 1.0, gainDown = 1.0
    var adsGainRight = 1.0, adsGainLeft = 1.0, adsGainUp = 1.0, adsGainDown = 1.0

    // Movement ----------------------------------------------------------------
    /// Analog movement: a small push walks, a full push sprints. A keyboard
    /// can only do one speed; this is the thing a stick can do that WASD can't.
    var analogMove = true
    var sprintAt = 0.85       // deflection at or above this sprints
    var sprintOff = 0.70      // and stops sprinting below this (hysteresis)
    var moveOn = 0.50         // deflection that starts a direction key
    var moveOff = 0.35        // and releases it
    /// A third, slower speed for anyone who has bound Walk in the game.
    /// "none" leaves it alone, which is the default.
    var walkKey = "none"
    var walkAt = 0.45         // below this deflection, walk instead of run
    /// Some games run by default and use the modifier key to slow you down
    /// instead of speeding you up. With this on, the key is held for gentle
    /// pushes rather than full ones.
    var shiftIsWalk = false

    // Gyro --------------------------------------------------------------------
    var gyro = false
    // "firing" = only while the trigger is held (recoil control; the sticks
    // aim), "ads" = while aiming, "always". Hold mode measured from ZL press
    // drifted on its own for 51% of aimed time not shooting (02:05-02:13 Oct
    // 29) and the stick pushed against it 40% of the time.
    // "aimfire" (default since 03:20 Oct 29): only with ZL and ZR both held.
    // "firing" switched to report 0x05 on every trigger pull, including
    // swinging a tool, and 0x05 reads the GL paddle as ZL, so head look
    // (GL hold) stopped working while farming. Guns are aimed: hip-fire is
    // 10% of presses that hit (147/1436).
    var gyroWhen = "aimfire"
    var gyroSens = 25.0       // mouse counts per degree the controller turns
    var gyroTighten = 1.5     // °/s below which movement is scaled down
    // "hold": the angle turned since ZL went down sets a steady view speed, so
    // a held tilt keeps pulling against recoil. "turn": the view moves only
    // while the controller turns (gyroSens counts per degree).
    var gyroMode = "hold"
    // Hold mode: counts a second per degree held past the deadzone. Started at
    // 35 with a 1° deadzone (02:00 Oct 29); "I barely tilt the controller, it's
    // not picking it up like it used to" → 90 past 0.25°.
    var gyroHold = 90.0
    var gyroHoldDead = 0.25   // degrees held before hold mode moves anything
    /// Acceleration has an amount and a switch, kept apart on purpose: turning
    /// it off and back on should return to the number you had, not to 1.
    var gyroAccelOn = false
    var gyroAccel = 1.5       // how much more sensitivity a fast turn gets
    var gyroAccelLow = 15.0   // °/s where the extra sensitivity starts
    var gyroAccelHigh = 80.0  // °/s where it's fully applied
    var gyroFlipX = false
    var gyroFlipY = false

    // Session recording -------------------------------------------------------
    var record = true
    /// Press the silent combat-log key now and then, so the record of what
    /// actually landed collects itself instead of being remembered about.
    var autoCombatLog = true
    var combatLogEvery = 20.0

    // Scope -------------------------------------------------------------------
    var game = "Rust"
    var anyApp = false


    enum CodingKeys: String, CodingKey {
        case speed, ads, deadzone, curve, range, boost, boostEdge, boostDelay, boostRamp
        case evenReach
        case gainRight, gainLeft, gainUp, gainDown, adsGainRight, adsGainLeft, adsGainUp, adsGainDown
        case analogMove, sprintAt, sprintOff, moveOn, moveOff, walkKey, walkAt
        case shiftIsWalk
        case gyroAccelOn
        case gyro, gyroWhen, gyroSens, gyroTighten, gyroAccel, gyroAccelLow, gyroAccelHigh
        case gyroMode, gyroHold, gyroHoldDead
        case gyroFlipX, gyroFlipY
        case record, autoCombatLog, combatLogEvery, game, anyApp
    }

    // Field table -------------------------------------------------------------

    struct Field {
        enum Kind {
            case number(WritableKeyPath<Settings, Double>, min: Double, max: Double, step: Double, decimals: Int)
            case toggle(WritableKeyPath<Settings, Bool>)
            case choice(WritableKeyPath<Settings, String>, [String])
        }
        let name: String
        let group: String
        let label: String
        let help: String
        let kind: Kind
    }

    static let fields: [Field] = [
        .init(name: "speed", group: "Look", label: "Look speed", help: "Mouse counts a second with the stick pushed all the way.",
              kind: .number(\Settings.speed, min: 50, max: 20000, step: 25, decimals: 0)),
        .init(name: "ads", group: "Look", label: "ADS multiplier", help: "How much slower aiming is than hip-fire.",
              kind: .number(\Settings.ads, min: 0.05, max: 3, step: 0.05, decimals: 2)),
        .init(name: "curve", group: "Look", label: "Response curve", help: "Above 1 makes small movements finer. 1 is a straight line.",
              kind: .number(\Settings.curve, min: 0.5, max: 3, step: 0.05, decimals: 2)),
        .init(name: "deadzone", group: "Look", label: "Deadzone", help: "Fraction of the stick ignored around the centre.",
              kind: .number(\Settings.deadzone, min: 0, max: 0.3, step: 0.005, decimals: 3)),
        .init(name: "range", group: "Look", label: "Stick range", help: "Raw counts from centre that count as a full push. Lower = less travel needed.",
              kind: .number(\Settings.range, min: 500, max: 3000, step: 25, decimals: 0)),
        .init(name: "evenReach", group: "Look", label: "Even out stick reach", help: "Your right stick can't push as far one way as the other, because it rests off-centre in its gate. This scales the short side up so a full push is a full push both ways. The long side is unchanged.",
              kind: .toggle(\Settings.evenReach)),

        .init(name: "gainRight", group: "Direction", label: "Hip right", help: "Hip stick speed turning right, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.gainRight, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "gainLeft", group: "Direction", label: "Hip left", help: "Hip stick speed turning left, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.gainLeft, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "gainUp", group: "Direction", label: "Hip up", help: "Hip stick speed turning up, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.gainUp, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "gainDown", group: "Direction", label: "Hip down", help: "Hip stick speed turning down, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.gainDown, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "adsGainRight", group: "Direction", label: "Aimed right", help: "Aimed stick speed turning right, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.adsGainRight, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "adsGainLeft", group: "Direction", label: "Aimed left", help: "Aimed stick speed turning left, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.adsGainLeft, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "adsGainUp", group: "Direction", label: "Aimed up", help: "Aimed stick speed turning up, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.adsGainUp, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),
        .init(name: "adsGainDown", group: "Direction", label: "Aimed down", help: "Aimed stick speed turning down, as a multiplier. The calibrator sets this from how your flicks land; 1 = unchanged.",
              kind: .number(\Settings.adsGainDown, min: 0.7, max: 1.3, step: 0.01, decimals: 2)),

        .init(name: "boost", group: "Turn boost", label: "Boost", help: "Extra turn speed with the stick held at the edge. 1 turns it off.",
              kind: .number(\Settings.boost, min: 1, max: 5, step: 0.05, decimals: 2)),
        .init(name: "boostEdge", group: "Turn boost", label: "Edge", help: "How far out the stick has to be to count as held at the edge.",
              kind: .number(\Settings.boostEdge, min: 0.5, max: 1, step: 0.01, decimals: 2)),
        .init(name: "boostDelay", group: "Turn boost", label: "Delay", help: "Seconds held at the edge before it kicks in.",
              kind: .number(\Settings.boostDelay, min: 0, max: 1, step: 0.01, decimals: 2)),
        .init(name: "boostRamp", group: "Turn boost", label: "Ramp", help: "Seconds to wind up to the full boost.",
              kind: .number(\Settings.boostRamp, min: 0.05, max: 2, step: 0.05, decimals: 2)),

        .init(name: "analogMove", group: "Movement", label: "Analog movement", help: "A small push walks, a full push sprints — no need to click the stick.",
              kind: .toggle(\Settings.analogMove)),
        .init(name: "shiftIsWalk", group: "Movement", label: "Modifier means walk", help: "Turn on if your game already runs by default, so the Shift key slows you down instead of speeding you up. Flips which end of the stick holds it.",
              kind: .toggle(\Settings.shiftIsWalk)),
        .init(name: "sprintAt", group: "Movement", label: "Sprint at", help: "Push past this and you sprint.",
              kind: .number(\Settings.sprintAt, min: 0.5, max: 1, step: 0.01, decimals: 2)),
        .init(name: "sprintOff", group: "Movement", label: "Sprint off", help: "Drop below this and sprinting stops.",
              kind: .number(\Settings.sprintOff, min: 0.3, max: 1, step: 0.01, decimals: 2)),
        .init(name: "moveOn", group: "Movement", label: "Move on", help: "Deflection that starts moving.",
              kind: .number(\Settings.moveOn, min: 0.1, max: 0.9, step: 0.01, decimals: 2)),
        .init(name: "moveOff", group: "Movement", label: "Move off", help: "Deflection that stops moving.",
              kind: .number(\Settings.moveOff, min: 0.05, max: 0.9, step: 0.01, decimals: 2)),
        .init(name: "walkKey", group: "Movement", label: "Walk key", help: "If you've bound Walk in the game's controls, pick the key here for a third, quieter speed.",
              kind: .choice(\Settings.walkKey, ["none", "z", "x", "c", "v", "b", "n", "alt"])),
        .init(name: "walkAt", group: "Movement", label: "Walk below", help: "Pushes gentler than this walk instead of running.",
              kind: .number(\Settings.walkAt, min: 0.1, max: 0.8, step: 0.01, decimals: 2)),

        .init(name: "gyro", group: "Gyro", label: "Gyro aim", help: "Turning the controller moves the view.",
              kind: .toggle(\Settings.gyro)),
        .init(name: "gyroWhen", group: "Gyro", label: "Active", help: "Aimfire: only while aiming and shooting at once (ZL + ZR), measured from where the controller is when you start, so it's recoil control for guns and never touches farming, tools or head look. Firing: any trigger pull, hip-fire too (tools as well, and head look won't work while swinging). Ads: while aiming. Always: all the time.",
              kind: .choice(\Settings.gyroWhen, ["aimfire", "firing", "ads", "always"])),
        .init(name: "gyroMode", group: "Gyro", label: "Mode", help: "Hold: tilt down from where you were when ZL went down and hold it, and the view keeps pulling down (recoil control without winding your wrist). Left and right steer only while tilted down; tilting up does nothing. Turn: the view moves only while the controller turns.",
              kind: .choice(\Settings.gyroMode, ["hold", "turn"])),
        .init(name: "gyroHold", group: "Gyro", label: "Hold strength", help: "Hold mode: mouse counts a second for each degree you hold. Your sprays pull about 195 a second: about 2° held at 90.",
              kind: .number(\Settings.gyroHold, min: 2, max: 600, step: 1, decimals: 0)),
        .init(name: "gyroHoldDead", group: "Gyro", label: "Hold deadzone", help: "Hold mode: degrees you can tilt before anything moves. Lower picks up smaller tilts; too low and a shaky hand pulls.",
              kind: .number(\Settings.gyroHoldDead, min: 0, max: 5, step: 0.05, decimals: 2)),
        .init(name: "gyroSens", group: "Gyro", label: "Gyro sens", help: "Mouse counts per degree the controller turns.",
              kind: .number(\Settings.gyroSens, min: 1, max: 400, step: 1, decimals: 0)),
        .init(name: "gyroTighten", group: "Gyro", label: "Tightening", help: "Degrees a second below which movement is damped, so resting hands don't drift.",
              kind: .number(\Settings.gyroTighten, min: 0, max: 15, step: 0.25, decimals: 2)),
        .init(name: "gyroAccelOn", group: "Gyro", label: "Acceleration on", help: "Fast turns get more sensitivity than slow ones. Home + B toggles this on the controller, mid-game.",
              kind: .toggle(\Settings.gyroAccelOn)),
        .init(name: "gyroAccel", group: "Gyro", label: "Acceleration", help: "Fast turns get this much more sensitivity than slow ones. 1 is off.",
              kind: .number(\Settings.gyroAccel, min: 1, max: 5, step: 0.05, decimals: 2)),
        .init(name: "gyroAccelLow", group: "Gyro", label: "Accel from", help: "Turn speed where the extra sensitivity starts.",
              kind: .number(\Settings.gyroAccelLow, min: 1, max: 200, step: 1, decimals: 0)),
        .init(name: "gyroAccelHigh", group: "Gyro", label: "Accel to", help: "Turn speed where it's fully applied.",
              kind: .number(\Settings.gyroAccelHigh, min: 5, max: 600, step: 5, decimals: 0)),
        .init(name: "gyroFlipX", group: "Gyro", label: "Reverse left/right", help: "",
              kind: .toggle(\Settings.gyroFlipX)),
        .init(name: "gyroFlipY", group: "Gyro", label: "Reverse up/down", help: "",
              kind: .toggle(\Settings.gyroFlipY)),

        .init(name: "record", group: "Recording", label: "Record fights", help: "Keeps the few seconds around each shot so aim can be measured later.",
              kind: .toggle(\Settings.record)),
        .init(name: "autoCombatLog", group: "Recording", label: "Log fights automatically", help: "Presses the silent combat-log key (7) now and then so the hit data collects itself. Your own D-pad right still opens the log on screen.",
              kind: .toggle(\Settings.autoCombatLog)),
        .init(name: "combatLogEvery", group: "Recording", label: "How often", help: "Seconds between automatic dumps.",
              kind: .number(\Settings.combatLogEvery, min: 5, max: 120, step: 5, decimals: 0)),
        .init(name: "anyApp", group: "Recording", label: "Active in every app", help: "Off means only while the game is in front.",
              kind: .toggle(\Settings.anyApp)),
    ]

    static func field(_ name: String) -> Field? {
        fields.first { $0.name.lowercased() == name.lowercased() }
    }

    /// Current value of a field as a string, for the API and the console.
    func value(_ f: Field) -> String {
        switch f.kind {
        case .number(let path, _, _, _, let decimals):
            return String(format: "%.\(decimals)f", self[keyPath: path])
        case .toggle(let path):
            return self[keyPath: path] ? "on" : "off"
        case .choice(let path, _):
            return self[keyPath: path]
        }
    }

    /// Set a field from a string. Returns what it became, or nil if the value
    /// was no good.
    mutating func set(_ f: Field, to raw: String) -> String? {
        switch f.kind {
        case .number(let path, let lo, let hi, let step, let decimals):
            var v: Double
            let t = raw.lowercased()
            if t.hasPrefix("x"), let mult = Double(t.dropFirst()) {
                v = self[keyPath: path] * mult          // "x2", "x0.5"
            } else if t.hasPrefix("+"), let d = Double(t.dropFirst()) {
                v = self[keyPath: path] + d
            } else if let d = Double(t) {
                v = d
            } else { return nil }
            // deadzone is talked about as a percentage everywhere else
            if f.name == "deadzone", v > 1 { v /= 100 }
            v = min(hi, max(lo, v))
            if step > 0 { v = (v / step).rounded() * step }
            self[keyPath: path] = v
            return String(format: "%.\(decimals)f", v)
        case .toggle(let path):
            let t = raw.lowercased()
            let on: Bool
            if ["on", "true", "1", "yes"].contains(t) { on = true }
            else if ["off", "false", "0", "no"].contains(t) { on = false }
            else if t == "toggle" || t.isEmpty { on = !self[keyPath: path] }
            else { return nil }
            self[keyPath: path] = on
            return on ? "on" : "off"
        case .choice(let path, let options):
            let t = raw.lowercased()
            guard let pick = options.first(where: { $0 == t }) else { return nil }
            self[keyPath: path] = pick
            return pick
        }
    }

    var summary: String {
        var line = String(format: "look %.0f · ADS ×%.2f · deadzone %.1f%% · curve %.2f · range %.0f · boost ×%.2f",
                          speed, ads, deadzone * 100, curve, range, boost)
        if gyro {
            line += gyroMode == "hold" ? " · gyro hold \(Int(gyroHold)) (\(gyroWhen))"
                                       : " · gyro \(Int(gyroSens)) (\(gyroWhen))"
            if gyroAccelOn { line += String(format: " ×%.2f accel", gyroAccel) }
        }
        if evenReach { line += " · even reach" }
        let hipG = [gainRight, gainLeft, gainUp, gainDown], adsG = [adsGainRight, adsGainLeft, adsGainUp, adsGainDown]
        if hipG.contains(where: { $0 != 1 }) {
            line += String(format: " · hip gain R%.2f L%.2f U%.2f D%.2f", hipG[0], hipG[1], hipG[2], hipG[3])
        }
        if adsG.contains(where: { $0 != 1 }) {
            line += String(format: " · ads gain R%.2f L%.2f U%.2f D%.2f", adsG[0], adsG[1], adsG[2], adsG[3])
        }
        if analogMove { line += " · analog move" }
        return line
    }
}


/// Kept in an extension so the struct still gets its automatic
/// `Settings()` initialiser, which the defaults above depend on.
extension Settings {
    /// Decoding is deliberately forgiving: anything missing falls back to its
    /// default instead of throwing. Without this, adding a single setting in a
    /// later version would make every existing config file fail to decode and
    /// quietly reset numbers that took weeks to get right.
    init(from decoder: Decoder) throws {
        var s = Settings()
        guard let c = try? decoder.container(keyedBy: CodingKeys.self) else {
            self = s
            return
        }
        func num(_ key: CodingKeys, _ path: WritableKeyPath<Settings, Double>) {
            // `try?` already flattens the optional decodeIfPresent returns,
            // so this single bind covers both a missing key and a bad value.
            if let v = try? c.decodeIfPresent(Double.self, forKey: key) {
                s[keyPath: path] = v
            }
        }
        func flag(_ key: CodingKeys, _ path: WritableKeyPath<Settings, Bool>) {
            // `try?` already flattens the optional decodeIfPresent returns,
            // so this single bind covers both a missing key and a bad value.
            if let v = try? c.decodeIfPresent(Bool.self, forKey: key) {
                s[keyPath: path] = v
            }
        }
        func text(_ key: CodingKeys, _ path: WritableKeyPath<Settings, String>) {
            // `try?` already flattens the optional decodeIfPresent returns,
            // so this single bind covers both a missing key and a bad value.
            if let v = try? c.decodeIfPresent(String.self, forKey: key) {
                s[keyPath: path] = v
            }
        }
        num(.speed, \Settings.speed)
        num(.ads, \Settings.ads)
        num(.deadzone, \Settings.deadzone)
        num(.curve, \Settings.curve)
        num(.range, \Settings.range)
        num(.boost, \Settings.boost)
        num(.boostEdge, \Settings.boostEdge)
        num(.boostDelay, \Settings.boostDelay)
        num(.boostRamp, \Settings.boostRamp)
        num(.sprintAt, \Settings.sprintAt)
        num(.sprintOff, \Settings.sprintOff)
        num(.moveOn, \Settings.moveOn)
        num(.moveOff, \Settings.moveOff)
        num(.walkAt, \Settings.walkAt)
        num(.gyroSens, \Settings.gyroSens)
        num(.gyroTighten, \Settings.gyroTighten)
        num(.gyroHold, \Settings.gyroHold)
        num(.gyroHoldDead, \Settings.gyroHoldDead)
        text(.gyroMode, \Settings.gyroMode)
        num(.gyroAccel, \Settings.gyroAccel)
        num(.gyroAccelLow, \Settings.gyroAccelLow)
        num(.gyroAccelHigh, \Settings.gyroAccelHigh)
        flag(.evenReach, \Settings.evenReach)
        num(.gainRight, \Settings.gainRight)
        num(.gainLeft, \Settings.gainLeft)
        num(.gainUp, \Settings.gainUp)
        num(.gainDown, \Settings.gainDown)
        num(.adsGainRight, \Settings.adsGainRight)
        num(.adsGainLeft, \Settings.adsGainLeft)
        num(.adsGainUp, \Settings.adsGainUp)
        num(.adsGainDown, \Settings.adsGainDown)
        flag(.analogMove, \Settings.analogMove)
        flag(.shiftIsWalk, \Settings.shiftIsWalk)
        flag(.gyro, \Settings.gyro)
        flag(.gyroAccelOn, \Settings.gyroAccelOn)
        flag(.gyroFlipX, \Settings.gyroFlipX)
        flag(.gyroFlipY, \Settings.gyroFlipY)
        flag(.record, \Settings.record)
        flag(.autoCombatLog, \Settings.autoCombatLog)
        num(.combatLogEvery, \Settings.combatLogEvery)
        flag(.anyApp, \Settings.anyApp)
        text(.gyroWhen, \Settings.gyroWhen)
        text(.walkKey, \Settings.walkKey)
        text(.game, \Settings.game)
        self = s
    }
}

/// One recorded change, so anything that made things worse can be undone.
struct Change: Codable {
    var at: Double            // seconds since the epoch
    var field: String
    var from: String
    var to: String
    var by: String            // "panel", "console", "controller", "preset", "profile"
    var profile: String
}

/// Everything saved to disk.
struct ConfigFile: Codable {
    var version = 5
    var active = "A"
    var profiles: [String: Settings] = ["A": Settings(), "B": Settings()]
    var presets: [String: Settings] = [:]
    var history: [Change] = []
    var migrated = false
}

/// Reads and writes config.json and keeps the change log.
final class Store {
    static let directory: URL = {
        let home = FileManager.default.homeDirectoryForCurrentUser
        return home.appendingPathComponent("procon2-kbm", isDirectory: true)
    }()
    static let configURL = directory.appendingPathComponent("config.json")

    private(set) var file = ConfigFile()
    var onChange: (() -> Void)?

    var settings: Settings {
        get { file.profiles[file.active] ?? Settings() }
        set { file.profiles[file.active] = newValue }
    }
    var activeProfile: String { file.active }
    var profileNames: [String] { file.profiles.keys.sorted() }
    var presetNames: [String] { file.presets.keys.sorted() }

    init() {
        load()
        migrateFromUserDefaultsIfNeeded()
    }

    private func load() {
        guard let data = try? Data(contentsOf: Store.configURL),
              let decoded = try? JSONDecoder().decode(ConfigFile.self, from: data) else { return }
        file = decoded
        if file.profiles[file.active] == nil { file.active = file.profiles.keys.sorted().first ?? "A" }
        if file.profiles.isEmpty { file.profiles = ["A": Settings(), "B": Settings()] }
    }

    /// Carry over the settings earlier versions kept in macOS preferences, so
    /// the numbers that were dialled in by hand aren't lost on the way here.
    private func migrateFromUserDefaultsIfNeeded() {
        guard !file.migrated else { return }
        file.migrated = true
        guard let old = UserDefaults(suiteName: "com.procon2.kbm") else { save(); return }
        var s = settings
        var moved: [String] = []
        let map: [(String, WritableKeyPath<Settings, Double>)] = [
            ("speed", \Settings.speed), ("ads", \Settings.ads), ("deadzone", \Settings.deadzone),
            ("curve", \Settings.curve), ("range", \Settings.range), ("boost", \Settings.boost),
            ("gyroSens", \Settings.gyroSens),
        ]
        for (key, path) in map where old.object(forKey: key) != nil {
            s[keyPath: path] = old.double(forKey: key)
            moved.append(key)
        }
        if let flip = old.object(forKey: "gyroFlipY") as? Bool { s.gyroFlipY = flip }
        if let flip = old.object(forKey: "gyroFlipX") as? Bool { s.gyroFlipX = flip }
        settings = s
        // Profile B starts as a copy, so switching to it changes nothing until
        // it's deliberately changed.
        if file.profiles["B"] == Settings() { file.profiles["B"] = s }
        save()
        if !moved.isEmpty {
            log("Brought your saved settings across: \(moved.joined(separator: ", "))")
        }
    }

    func save() {
        try? FileManager.default.createDirectory(at: Store.directory, withIntermediateDirectories: true)
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        guard let data = try? encoder.encode(file) else { return }
        try? data.write(to: Store.configURL, options: .atomic)
    }

    // Changes -----------------------------------------------------------------

    /// Apply one field. Returns a short description, or nil if it didn't take.
    @discardableResult
    func apply(_ name: String, _ raw: String, by: String) -> String? {
        guard let f = Settings.field(name) else { return nil }
        var s = settings
        let before = s.value(f)
        guard let after = s.set(f, to: raw) else { return nil }
        settings = s
        if before != after {
            record(Change(at: Date().timeIntervalSince1970, field: f.name,
                          from: before, to: after, by: by, profile: file.active))
        }
        save()
        onChange?()
        return "\(f.label) \(after)"
    }

    private func record(_ c: Change) {
        file.history.append(c)
        if file.history.count > 600 { file.history.removeFirst(file.history.count - 600) }
    }

    /// Undo the most recent change. Returns what it undid.
    func revertLast() -> String? {
        guard let last = file.history.last, let f = Settings.field(last.field) else { return nil }
        var s = settings
        guard s.set(f, to: last.from) != nil else { return nil }
        settings = s
        file.history.removeLast()
        save()
        onChange?()
        return "\(f.label) back to \(last.from)"
    }

    var recentChanges: [Change] { Array(file.history.suffix(40).reversed()) }

    // Profiles and presets ----------------------------------------------------

    func switchProfile(to name: String) -> Bool {
        guard file.profiles[name] != nil else { return false }
        file.active = name
        save()
        onChange?()
        return true
    }

    /// Flip between the two profiles, for the controller shortcut.
    func nextProfile() -> String {
        let names = profileNames
        guard !names.isEmpty else { return file.active }
        let i = names.firstIndex(of: file.active) ?? 0
        file.active = names[(i + 1) % names.count]
        save()
        onChange?()
        return file.active
    }

    func savePreset(_ name: String) {
        file.presets[name] = settings
        save()
        onChange?()
    }

    func loadPreset(_ name: String) -> Bool {
        guard let p = file.presets[name] else { return false }
        let before = settings
        settings = p
        for f in Settings.fields {
            let b = before.value(f), a = p.value(f)
            if b != a {
                record(Change(at: Date().timeIntervalSince1970, field: f.name,
                              from: b, to: a, by: "preset:\(name)", profile: file.active))
            }
        }
        save()
        onChange?()
        return true
    }

    func deletePreset(_ name: String) {
        file.presets[name] = nil
        save()
        onChange?()
    }
}
