import Foundation
import IOKit
import IOUSBHost

/// The controller's command pipe: USB interface #1, vendor class, bulk
/// endpoints 0x02 out / 0x82 in. macOS leaves it unclaimed, so IOUSBHost can
/// open it without root.
///
/// Two things matter, both measured:
///  - each command goes out at its exact length (8-byte header + payload),
///    not padded to 64;
///  - the IN read has to be queued *before* the write. The reply comes back
///    within microseconds and a read issued afterwards misses it, which is
///    why every earlier attempt looked like the controller was silent.
final class VendorPipe {
    static let vendorID = 0x057E
    static let productID = 0x2069

    private let interface: IOUSBHostInterface
    private let outPipe: IOUSBHostPipe
    private let inPipe: IOUSBHostPipe

    init() throws {
        let matching = IOServiceMatching("IOUSBHostInterface") as NSMutableDictionary
        matching["IOPropertyMatch"] = [
            "idVendor": VendorPipe.vendorID,
            "idProduct": VendorPipe.productID,
            "bInterfaceNumber": 1,
        ]
        let service = IOServiceGetMatchingService(kIOMainPortDefault, matching)
        guard service != 0 else {
            throw NSError(domain: "VendorPipe", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "controller's USB command interface not found"])
        }
        defer { IOObjectRelease(service) }
        interface = try IOUSBHostInterface(__ioService: service, options: [], queue: nil, interestHandler: nil)
        do {
            outPipe = try interface.copyPipe(withAddress: 0x02)
            inPipe = try interface.copyPipe(withAddress: 0x82)
        } catch {
            interface.destroy()
            throw error
        }
    }

    deinit { interface.destroy() }

    /// Send one command and return the controller's reply, or nil if none came.
    /// Reply byte 1 is 0x01 when the command was accepted.
    func send(_ command: UInt8, _ subcommand: UInt8, _ payload: [UInt8] = []) throws -> [UInt8]? {
        let reply = NSMutableData(length: 64)!
        var replyLength = 0
        let done = DispatchSemaphore(value: 0)
        try inPipe.enqueueIORequest(with: reply, completionTimeout: 1.0) { status, transferred in
            if status == kIOReturnSuccess { replyLength = Int(transferred) }
            done.signal()
        }
        let bytes = [command, 0x91, 0x00, subcommand, 0x00, UInt8(payload.count), 0x00, 0x00] + payload
        let data = NSMutableData(bytes: bytes, length: bytes.count)
        var sent: UInt = 0
        do {
            try outPipe.__sendIORequest(with: data, bytesTransferred: &sent, completionTimeout: 1.0)
        } catch {
            try? inPipe.__abort(with: .synchronous)
            done.wait()
            throw error
        }
        _ = done.wait(timeout: .now() + 1.5)
        return replyLength > 0 ? Array(reply.prefix(replyLength)) : nil
    }

    /// The init sequence from SDL3's switch2 driver, with the IMU feature bit
    /// on. `report` picks what streams: 0x05 carries the gyro, 0x09 doesn't.
    /// The report must be selected before input is started.
    static func initialise(report: UInt8) -> [String] {
        let steps: [(String, UInt8, UInt8, [UInt8])] = [
            ("handshake", 0x07, 0x01, []),
            ("feature mask", 0x0C, 0x02, [0x27, 0, 0, 0]),
            ("firmware info", 0x11, 0x01, []),
            ("stick config", 0x0A, 0x08, [0x01] + [UInt8](repeating: 0xFF, count: 8)
                + [0x35, 0x00, 0x46, 0x00] + [UInt8](repeating: 0, count: 8)),
            ("enable features", 0x0C, 0x04, [0x27, 0, 0, 0]),
            ("01/0C", 0x01, 0x0C, []),
            ("01/01", 0x01, 0x01, []),
            (String(format: "select report 0x%02X", report), 0x03, 0x0A, [report, 0, 0, 0]),
            ("start input", 0x03, 0x0D, [0x01, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]),
            ("player LED 1", 0x09, 0x07, [0x01, 0, 0, 0, 0, 0, 0, 0]),
        ]
        let pipe: VendorPipe
        do { pipe = try VendorPipe() } catch { return ["USB command pipe: \(error.localizedDescription)"] }
        var results: [String] = []
        for (name, command, subcommand, payload) in steps {
            let label = String(format: "%02X/%02X %@", command, subcommand, name)
            do {
                if let reply = try pipe.send(command, subcommand, payload) {
                    results.append(reply.count > 1 && reply[1] == 0x01
                        ? "\(label) accepted"
                        : String(format: "%@ replied %02X", label, reply.count > 1 ? reply[1] : 0))
                } else {
                    results.append("\(label) no reply")
                }
            } catch {
                results.append("\(label) failed: \(error.localizedDescription)")
            }
            Thread.sleep(forTimeInterval: 0.02)
        }
        return results
    }
}
