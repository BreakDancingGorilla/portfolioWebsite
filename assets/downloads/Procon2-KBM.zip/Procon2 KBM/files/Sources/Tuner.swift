// Auto-tuning: one setting at a time, tested against a small change to it, and
// only kept if the measurements say it's better.
//
// The statistics live in analysis/tuner.py (the report's "tuner" section),
// which says what to do. This carries it out, and only between fights: after
// each fight it asks for a fresh report in the background, and acts on the
// answer after the *next* fight, so a setting never changes mid-fight. Every
// decision is logged, kept in tuner.json, and shown in the panel. Turning it
// off leaves whatever test is running to run (or be stopped) by hand.

import Foundation

final class Tuner {
    struct Decision: Codable {
        var at: Double
        var field: String
        var baseline: String
        var candidate: String
        var kept: String
        var result: String
        var reason: String
        /// Set by hand when a decision turns out to rest on a bug; the queue
        /// then treats the setting as untested.
        var void: Bool?
        var voidReason: String?
        var startedAt: Double?       // when the test began, for checking an adopted value afterwards
    }
    struct State: Codable {
        var enabled = true
        var history: [Decision] = []
    }

    static let url = Store.directory.appendingPathComponent("tuner.json")
    private(set) var state = State()
    private(set) var summary: String?
    private var pending: [String: Any]?
    private var checking = false
    private var lastCheck = 0.0
    private let experiment: Experiment
    private let store: Store
    private let reports: ReportRunner

    init(experiment: Experiment, store: Store, reports: ReportRunner) {
        self.experiment = experiment
        self.store = store
        self.reports = reports
        if let data = try? Data(contentsOf: Tuner.url),
           let s = try? JSONDecoder().decode(State.self, from: data) {
            state = s
        }
    }

    func setEnabled(_ on: Bool) -> String {
        state.enabled = on
        pending = nil
        save()
        if on { check() }
        return on ? "auto-tune on: it decides between fights" : "auto-tune off — settings stay as they are"
    }

    /// Called after every engagement, on the main queue.
    func engagementFinished(shots: Int) {
        guard state.enabled, shots > 0 else { return }
        if let action = pending {
            pending = nil
            apply(action)
        }
        check()
    }

    /// Run the report off the main queue and keep its action for the next fight.
    func check() {
        // A full report is a few seconds of background work; fights can come
        // seconds apart, so at most one every 20 s.
        let now = Date().timeIntervalSince1970
        guard !checking, now - lastCheck > 20 else { return }
        checking = true
        lastCheck = now
        DispatchQueue.global(qos: .utility).async {
            let response = self.reports.response(refresh: true)
            let report = (try? JSONSerialization.jsonObject(with: response.body)) as? [String: Any]
            let section = report?["tuner"] as? [String: Any]
            DispatchQueue.main.async {
                self.checking = false
                guard let section else { return }
                self.summary = section["summary"] as? String
                if self.state.enabled { self.pending = section["action"] as? [String: Any] }
            }
        }
    }

    private func apply(_ action: [String: Any]) {
        switch action["do"] as? String {
        case "decide":
            guard let field = action["field"] as? String, let kept = action["kept"] as? String,
                  let running = experiment.snapshot,
                  running["field"] as? String == field,
                  running["values"] as? [String] == action["values"] as? [String]
            else { return }     // the test changed since the report was made: ignore it
            _ = experiment.stop(keep: kept, by: "tuner")
            let d = Decision(at: Date().timeIntervalSince1970, field: field,
                             baseline: action["baseline"] as? String ?? "",
                             candidate: action["candidate"] as? String ?? "",
                             kept: kept, result: action["result"] as? String ?? "",
                             reason: action["reason"] as? String ?? "",
                             startedAt: action["startedAt"] as? Double)
            state.history.append(d)
            log("⚙︎ auto-tune: \(field) → \(kept) (\(d.result)). \(d.reason)")
            startNext(action["next"] as? [String: Any])
        case "calibrate":
            // Per-direction stick gains from analysis/report.py's calibrator.
            // Only while no test runs, and only if nothing changed since the
            // report was made ("from" must still match).
            guard experiment.snapshot == nil, let set = action["set"] as? [String: String],
                  let from = action["from"] as? [String: String] else { return }
            for (field, old) in from {
                guard let f = Settings.field(field), store.settings.value(f) == old else { return }
            }
            let reasons = action["reasons"] as? [String: String] ?? [:]
            let result = action["result"] as? String ?? "calibrated"
            for (field, value) in set.sorted(by: { $0.key < $1.key }) {
                store.apply(field, value, by: "calibrator")
                let reason = reasons[field] ?? ""
                state.history.append(Decision(at: Date().timeIntervalSince1970, field: field,
                                              baseline: from[field] ?? "", candidate: value, kept: value,
                                              result: result, reason: reason))
                log("⚙︎ calibrator: \(field) \(from[field] ?? "?") → \(value). \(reason)")
            }
        case "start":
            guard experiment.snapshot == nil else { return }
            startNext(action["next"] as? [String: Any])
        case "revert":
            // A stick value adopted after a test turned out slower once in use.
            guard experiment.snapshot == nil, let field = action["field"] as? String,
                  let value = action["value"] as? String, let from = action["from"] as? String,
                  let f = Settings.field(field), store.settings.value(f) == from else { return }
            store.apply(field, value, by: "tuner")
            let reason = action["reason"] as? String ?? ""
            state.history.append(Decision(at: Date().timeIntervalSince1970, field: field, baseline: from,
                                          candidate: value, kept: value, result: "reverted", reason: reason))
            log("⚙︎ auto-tune: \(field) back to \(value). \(reason)")
        default:
            return                      // nothing to do: don't rewrite tuner.json
        }
        save()
    }

    private func startNext(_ next: [String: Any]?) {
        guard let next, let field = next["field"] as? String,
              let values = next["values"] as? [String], values.count == 2 else { return }
        let message = experiment.start(field: field, values: values, block: next["block"] as? Int ?? 6,
                                       minSeconds: next["minSeconds"] as? Double)
        log("⚙︎ auto-tune: \(message)")
    }

    var snapshot: [String: Any] {
        ["enabled": state.enabled, "summary": summary ?? NSNull(), "checking": checking,
         "pending": pending?["do"] as? String ?? NSNull(),
         "history": state.history.suffix(12).map {
             ["at": $0.at, "field": $0.field, "baseline": $0.baseline, "candidate": $0.candidate,
              "kept": $0.kept, "result": $0.result, "reason": $0.reason,
              "void": $0.void ?? false, "voidReason": $0.voidReason ?? NSNull()]
         }]
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(state) else { return }
        try? data.write(to: Tuner.url, options: .atomic)
    }
}
