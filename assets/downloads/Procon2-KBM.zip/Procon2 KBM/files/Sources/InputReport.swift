// Switch 2 Pro Controller USB input report parsing.
//
// Two different reports carry what we need:
//
//   0x09 — buttons + sticks. This layout was measured on real hardware by
//          procon2-mac (https://github.com/caqlayan/procon2-mac, MIT) and is
//          what every version of this tool has used. Left alone.
//
//   0x05 — buttons + sticks + a real 6-axis IMU, documented by
//          PRX-24hz/switch2pro-telemetry for this exact device (057E:2069).
//          The accelerometer is three int16 at 0x31/0x33/0x35 (~4096 counts
//          per g) and the gyroscope three int16 at 0x37/0x39/0x3B at
//          16.384 counts per degree per second.
//
// We take input from 0x09 and motion from 0x05. The published 0x05 button bit
// assignments aren't known, and a wrong guess there would break every button,
// so the proven path keeps the controls and the new report only adds the gyro.

import Foundation

/// Button bits in the 0x09 report's button field (payload bytes 2–4).
struct SW2Buttons: OptionSet {
    let rawValue: UInt32

    // payload byte 2
    static let b         = SW2Buttons(rawValue: 1 << 0)
    static let a         = SW2Buttons(rawValue: 1 << 1)
    static let y         = SW2Buttons(rawValue: 1 << 2)
    static let x         = SW2Buttons(rawValue: 1 << 3)
    static let r         = SW2Buttons(rawValue: 1 << 4)
    static let zr        = SW2Buttons(rawValue: 1 << 5)
    static let plus      = SW2Buttons(rawValue: 1 << 6)
    static let rStick    = SW2Buttons(rawValue: 1 << 7)
    // payload byte 3
    static let dpadDown  = SW2Buttons(rawValue: 1 << 8)
    static let dpadRight = SW2Buttons(rawValue: 1 << 9)
    static let dpadLeft  = SW2Buttons(rawValue: 1 << 10)
    static let dpadUp    = SW2Buttons(rawValue: 1 << 11)
    static let l         = SW2Buttons(rawValue: 1 << 12)
    static let zl        = SW2Buttons(rawValue: 1 << 13)
    static let minus     = SW2Buttons(rawValue: 1 << 14)
    static let lStick    = SW2Buttons(rawValue: 1 << 15)
    // payload byte 4
    static let home      = SW2Buttons(rawValue: 1 << 16)
    static let capture   = SW2Buttons(rawValue: 1 << 17)
    static let gr        = SW2Buttons(rawValue: 1 << 18)
    static let gl        = SW2Buttons(rawValue: 1 << 19)
    static let c         = SW2Buttons(rawValue: 1 << 20)
}

/// Buttons and sticks, from report 0x09.
struct InputReport {
    let buttons: SW2Buttons
    let leftStick: (x: Int, y: Int)   // 12-bit, nominal centre 2048, up = larger y
    let rightStick: (x: Int, y: Int)

    /// Parse a 0x09 payload (report-ID byte already stripped).
    static func parse(payload: [UInt8]) -> InputReport? {
        guard payload.count >= 11 else { return nil }
        let buttonBits = UInt32(payload[2])
            | UInt32(payload[3]) << 8
            | UInt32(payload[4]) << 16
        return InputReport(
            buttons: SW2Buttons(rawValue: buttonBits),
            leftStick: unpack12BitPair(payload[5], payload[6], payload[7]),
            rightStick: unpack12BitPair(payload[8], payload[9], payload[10])
        )
    }

    static func unpack12BitPair(_ b0: UInt8, _ b1: UInt8, _ b2: UInt8) -> (x: Int, y: Int) {
        let x = Int(b0) | (Int(b1 & 0x0F) << 8)
        let y = Int(b1 >> 4) | (Int(b2) << 4)
        return (x, y)
    }
}

/// One IMU sample from report 0x05, already in physical units.
///
/// Axes, from the controller's own frame:
///   x — across the controller, left/right. Turning about it tilts your aim
///       up and down, so this is the pitch axis whatever way it's held.
///   y — along the long axis, out of the end with the USB port (reads +1 g
///       with the port pointing up).
///   z — straight out of the front face (reads +1 g lying flat, face up).
struct IMUSample {
    /// Proper acceleration in g.
    let ax: Double, ay: Double, az: Double
    /// Angular velocity in degrees per second, before bias removal.
    let gx: Double, gy: Double, gz: Double
    /// Controller clock in milliseconds. Wraps about every 1432 s.
    let clockMs: UInt32
    /// Degrees Celsius, straight off the IMU die.
    let tempC: Double

    static let accelCountsPerG = 4096.0
    static let gyroCountsPerDPS = 16.384
}

/// Pulls IMU samples out of report 0x05.
///
/// macOS hands input reports to us either with or without the leading
/// report-ID byte depending on the device's descriptor, so rather than
/// assuming, this tries both alignments and keeps whichever one reports a
/// sensible 1 g at rest. That check is unambiguous: a one-byte slip scrambles
/// every int16 and the magnitude comes out nowhere near 4096.
final class IMUDecoder {
    /// Offset of the first accelerometer byte within the buffer handed to us.
    private(set) var accelOffset: Int?
    private(set) var checkedCandidates: [(offset: Int, magnitude: Double)] = []
    private var trials: [Int: (sum: Double, n: Double)] = [:]
    private var samplesSeen = 0

    /// 0x31 with the report-ID byte present, 0x30 without it. 0x32 is included
    /// only so a wrong answer shows up as a wrong answer rather than a near miss.
    private static let candidates = [0x31, 0x30, 0x32]
    private static let samplesToDecide = 120

    private static func s16(_ buf: [UInt8], _ i: Int) -> Double? {
        guard i >= 0, i + 1 < buf.count else { return nil }
        let v = Int(buf[i]) | (Int(buf[i + 1]) << 8)
        return Double(v >= 0x8000 ? v - 0x10000 : v)
    }

    private static func u32(_ buf: [UInt8], _ i: Int) -> UInt32 {
        guard i >= 0, i + 3 < buf.count else { return 0 }
        return UInt32(buf[i]) | UInt32(buf[i + 1]) << 8
            | UInt32(buf[i + 2]) << 16 | UInt32(buf[i + 3]) << 24
    }

    /// `buf` is the report exactly as macOS delivered it.
    func decode(_ buf: [UInt8]) -> IMUSample? {
        if accelOffset == nil {
            learn(from: buf)
            if accelOffset == nil { return nil }
        }
        guard let off = accelOffset,
              let axRaw = IMUDecoder.s16(buf, off),
              let ayRaw = IMUDecoder.s16(buf, off + 2),
              let azRaw = IMUDecoder.s16(buf, off + 4),
              let gxRaw = IMUDecoder.s16(buf, off + 6),
              let gyRaw = IMUDecoder.s16(buf, off + 8),
              let gzRaw = IMUDecoder.s16(buf, off + 10) else { return nil }
        let g = IMUSample.accelCountsPerG
        let d = IMUSample.gyroCountsPerDPS
        // The temperature and clock sit just ahead of the accelerometer.
        let tempRaw = IMUDecoder.s16(buf, off - 2) ?? 0
        return IMUSample(
            ax: axRaw / g, ay: ayRaw / g, az: azRaw / g,
            gx: gxRaw / d, gy: gyRaw / d, gz: gzRaw / d,
            clockMs: IMUDecoder.u32(buf, off - 0x30),
            tempC: 25 + tempRaw / 126.9
        )
    }

    private func learn(from buf: [UInt8]) {
        samplesSeen += 1
        for off in IMUDecoder.candidates {
            guard let x = IMUDecoder.s16(buf, off),
                  let y = IMUDecoder.s16(buf, off + 2),
                  let z = IMUDecoder.s16(buf, off + 4) else { continue }
            let magnitude = (x * x + y * y + z * z).squareRoot()
            var t = trials[off] ?? (0, 0)
            t.sum += magnitude
            t.n += 1
            trials[off] = t
        }
        guard samplesSeen >= IMUDecoder.samplesToDecide else { return }

        var scored: [(offset: Int, magnitude: Double)] = []
        for off in IMUDecoder.candidates {
            guard let t = trials[off], t.n > 0 else { continue }
            scored.append((off, t.sum / t.n))
        }
        checkedCandidates = scored
        // At rest the accelerometer reads 1 g, so the right alignment averages
        // close to 4096 counts. Moving the controller only ever adds to that
        // magnitude, so allow plenty of headroom above and little below.
        let best = scored
            .filter { $0.magnitude > 3200 && $0.magnitude < 9000 }
            .min { abs($0.magnitude - 4096) < abs($1.magnitude - 4096) }
        accelOffset = best?.offset
    }

    /// Give up on the current guess and work it out again.
    func reset() {
        accelOffset = nil
        trials = [:]
        samplesSeen = 0
        checkedCandidates = []
    }
}

/// Report 0x05 — the controller's full telemetry report.
///
/// Unlike 0x09, this one has no HID structure at all: the descriptor declares
/// it as 63 opaque vendor bytes, so every offset below comes from measurement
/// by others rather than from the device describing itself.
///
/// The button bits are NOT in 0x09's order — they follow the original Switch
/// Pro Controller's layout. Measured on this controller on 2026-10-28 by
/// pressing each button in turn. GR and GL have no bits of their own here:
/// pressing them sets ZR's and ZL's, so the paddle actions can't be told
/// apart from attack/aim while this report is selected.
struct Report05 {
    static let bitMap: [(Int, SW2Buttons)] = [
        (0, .y), (1, .x), (2, .b), (3, .a),
        (6, .r), (7, .zr),
        (8, .minus), (9, .plus), (10, .rStick), (11, .lStick),
        (12, .home), (13, .capture), (14, .c),
        (16, .dpadDown), (17, .dpadUp), (18, .dpadRight), (19, .dpadLeft),
        (22, .l), (23, .zl),
    ]

    let buttons: SW2Buttons
    let leftStick: (x: Int, y: Int)
    let rightStick: (x: Int, y: Int)
    let clockMs: UInt32

    /// `buf` is the report as macOS delivered it, with the report-ID byte at 0.
    static func parse(_ buf: [UInt8]) -> Report05? {
        guard buf.count >= 0x11 else { return nil }
        let bits = UInt32(buf[0x05])
            | UInt32(buf[0x06]) << 8
            | UInt32(buf[0x07]) << 16
            | UInt32(buf[0x08]) << 24
        let clock = UInt32(buf[0x01]) | UInt32(buf[0x02]) << 8
            | UInt32(buf[0x03]) << 16 | UInt32(buf[0x04]) << 24
        var buttons: SW2Buttons = []
        for (bit, button) in Report05.bitMap where bits & (1 << bit) != 0 {
            buttons.insert(button)
        }
        return Report05(
            buttons: buttons,
            leftStick: InputReport.unpack12BitPair(buf[0x0B], buf[0x0C], buf[0x0D]),
            rightStick: InputReport.unpack12BitPair(buf[0x0E], buf[0x0F], buf[0x10]),
            clockMs: clock
        )
    }

    /// The same shape the rest of the tool already understands.
    var asInput: InputReport {
        InputReport(buttons: buttons, leftStick: leftStick, rightStick: rightStick)
    }
}
