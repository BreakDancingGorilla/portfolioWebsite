// Reading Rust's combat log.
//
// Rust's `combatlog` console command prints the last few things that hit you
// or that you hit: weapon, body area, distance, and the HP before and after.
// Console output also goes to the game's player log on disk, so it can be read
// without screen-scraping anything.
//
// Nothing here touches the game. It reads a log file the game already writes,
// after the fact. Joined against the recorded engagements on time, it answers
// the question the video analysis could only estimate: when the shot was
// steady, did it land, and where.
//
// Whether Rust's console output reaches the player log on macOS hasn't been
// confirmed on this machine yet, so this reports exactly what it found — which
// file, how big, how many rows parsed — and keeps a short sample of the lines
// it didn't understand in combat/unparsed.txt. If it turns out the format is
// different, that sample says what the format actually is.

import Foundation

struct CombatRow {
    /// The first column, exactly as printed. Whether it means "seconds ago"
    /// or "server clock" has never been checked against a real dump — see
    /// ClockCheck below, which measures it rather than assuming either.
    var gameTime: Double
    var attacker: String
    var attackerID: String
    var target: String
    var targetID: String
    var weapon: String
    var ammo: String
    var area: String
    var distance: Double
    var oldHP: Double
    var newHP: Double
    var info: String
    var seenAt: Double          // wall clock when we read it
    /// The columns after `info` in the current format: hits, integrity,
    /// travel (bullet flight time), mismatch, desync. Kept as printed.
    var extra: [String: String] = [:]
    /// When the game wrote the line, from the `-timestamps` prefix (to the
    /// millisecond). Falls back to seenAt, which can be up to a poll late.
    var loggedAt: Double = 0
    /// When the dump this row came from was printed. All rows of one dump
    /// share it.
    var dumpAt: Double = 0

    /// Measured 2026-10-28 on real rows: `old_hp` is the target's HP *before*
    /// the hit and `new_hp` reads 100 every time, so damage can't come from
    /// one row. It's the drop to the next hit on the same target (see
    /// analysis/join.py). Zero here rather than a wrong number.
    var damage: Double { 0 }
    /// A row the server threw out: no target, or a reason like
    /// `projectile_los_player`. Only "killed" or blank info is a real hit.
    var isRejected: Bool {
        target == "N/A" || !(info.isEmpty || info == "killed")
    }
    var isHeadshot: Bool { area.lowercased().contains("head") }
    /// The hit's real time, if the first column is "seconds before the dump".
    var eventAtIfAgo: Double { dumpAt - gameTime }
    /// Everything that identifies a hit except its time, which is the one
    /// field whose meaning is in question.
    var contentKey: String {
        "\(attackerID)|\(targetID)|\(weapon)|\(ammo)|\(area)|\(distance)|\(oldHP)|\(newHP)"
    }

    var dictionary: [String: Any] {
        [
            "gameTime": gameTime, "attacker": attacker, "attackerID": attackerID,
            "target": target, "targetID": targetID, "weapon": weapon, "ammo": ammo,
            "area": area, "distance": distance, "oldHP": oldHP, "newHP": newHP,
            "info": info, "damage": damage, "headshot": isHeadshot,
            "seenAt": ISO8601DateFormatter().string(from: Date(timeIntervalSince1970: seenAt)),
            "loggedAt": loggedAt, "dumpAt": dumpAt, "rejected": isRejected, "extra": extra,
            "eventAtIfAgo": (eventAtIfAgo * 1000).rounded() / 1000,
            "key": contentKey,
        ]
    }
}

final class CombatLogTail {
    static let outputDir = Store.directory.appendingPathComponent("combat", isDirectory: true)

    private(set) var logPath: String?
    private(set) var logSize: Int = 0
    private(set) var rowsParsed = 0
    private(set) var unparsedKept = 0
    private(set) var rows: [CombatRow] = []
    private(set) var lastReadAt: Double = 0
    private(set) var note: String = "not started"

    private var handle: FileHandle?
    private var offset: UInt64 = 0
    /// Rust rewrites its log on every launch. If that's a new file rather than
    /// the old one truncated, the size check alone could miss it, so the file's
    /// identity is checked too.
    private var fileNumber: UInt64 = 0
    private var partial = ""

    /// The combat log is a rolling window: every dump reprints the last ~30
    /// hits, so the same hit turns up in dump after dump. Matching those
    /// repeats is both how duplicates are dropped and how the meaning of the
    /// time column gets measured: if it's "seconds ago", a repeated hit's
    /// value grows by exactly the time between the two dumps; if it's a
    /// server clock, it doesn't change at all.
    private struct Seen {
        var key: String
        var lastValue: Double
        var lastDumpAt: Double
    }
    private var events: [Seen] = []
    private(set) var votesAgo = 0
    private(set) var votesClock = 0
    private var clockVerdictLogged = false
    private var evidenceWritten = 0

    private struct Dump {
        var at: Double
        var header: Bool
        var rows = 0
        var newRows = 0
        var oldest = 0.0
        var newest = Double.infinity
        /// "+ 24 events in the last 10 seconds": the server hides the newest
        /// hits, and they still count towards the 30-row cap.
        var hidden = 0
    }
    /// Where each column starts, from the current dump's header. The table is
    /// fixed-width with blank cells (info is usually empty), so splitting on
    /// whitespace shifts every column after a blank one.
    private var columns: [(name: String, start: Int)]?
    private var openDump: Dump?
    private(set) var dumpsSeen = 0
    private(set) var headersSeen = 0
    private(set) var lastDumpAt = 0.0
    private(set) var lastDumpRows = 0
    /// The player's own Steam ID, read from the game's session marker line,
    /// so "my hits" doesn't have to be guessed from who attacks most.
    private(set) var myID: String?
    /// The player's name, from the same marker line. Arena servers report
    /// round results as "[System] User <name> Killed <name> (...)" chat lines
    /// rather than marking rows "killed", so wins and losses come from those.
    private(set) var myName: String?
    private(set) var killLines = 0
    private var timer: DispatchSourceTimer?
    private let queue = DispatchQueue(label: "procon2.combatlog", qos: .utility)
    /// Everything the panel reads is behind this, because the tail runs on its
    /// own queue and the HTTP thread asks for it whenever the page refreshes.
    private let lock = NSLock()

    private func setNote(_ text: String) {
        lock.lock(); note = text; lock.unlock()
    }

    /// A snapshot of the most recent rows, safe to read from any thread.
    func recentRows(_ n: Int = 80) -> [CombatRow] {
        lock.lock(); defer { lock.unlock() }
        return Array(rows.suffix(n).reversed())
    }

    /// Places Unity games on macOS put their player log.
    static func candidatePaths() -> [String] {
        let home = FileManager.default.homeDirectoryForCurrentUser.path
        return [
            "\(home)/Library/Logs/Rust/Player.log",
            "\(home)/Library/Logs/Facepunch Studios LTD/Rust/Player.log",
            "\(home)/Library/Logs/Facepunch Studios LTD/Rust/Player-prev.log",
            "\(home)/Library/Logs/Unity/Player.log",
            "\(home)/Library/Application Support/Steam/steamapps/common/Rust/output_log.txt",
            "\(home)/Library/Logs/unity3d/Facepunch Studios LTD/Rust/Player.log",
        ]
    }

    static func findLog() -> String? {
        let fm = FileManager.default
        var best: (path: String, date: Date)?
        for path in candidatePaths() {
            guard fm.fileExists(atPath: path),
                  let attrs = try? fm.attributesOfItem(atPath: path),
                  let modified = attrs[.modificationDate] as? Date else { continue }
            if best == nil || modified > best!.date { best = (path, modified) }
        }
        return best?.path
    }

    func start() {
        queue.async { [weak self] in self?.open() }
        let t = DispatchSource.makeTimerSource(queue: queue)
        t.schedule(deadline: .now() + 2, repeating: 2.0)
        t.setEventHandler { [weak self] in self?.poll() }
        t.resume()
        timer = t
    }

    private func open() {
        guard let path = CombatLogTail.findLog() else {
            setNote("no Rust player log found yet — start the game once and it'll appear")
            return
        }
        lock.lock(); logPath = path; lock.unlock()
        fileNumber = (try? FileManager.default.attributesOfItem(atPath: path))?[.systemFileNumber]
            .flatMap { ($0 as? NSNumber)?.uint64Value } ?? 0
        guard let h = FileHandle(forReadingAtPath: path) else {
            setNote("found \(path) but couldn't open it")
            return
        }
        handle = h
        // Start near the end: everything before now is already history.
        let size = (try? h.seekToEnd()) ?? 0
        lock.lock(); logSize = Int(size); lock.unlock()
        offset = size > 65536 ? size - 65536 : 0
        try? h.seek(toOffset: offset)
        setNote("watching \(path)")
    }

    private func poll() {
        if handle == nil { open() }
        guard let h = handle, let path = logPath else { return }
        let fm = FileManager.default
        guard let attrs = try? fm.attributesOfItem(atPath: path),
              let size = (attrs[.size] as? NSNumber)?.uint64Value else { return }
        if let n = (attrs[.systemFileNumber] as? NSNumber)?.uint64Value, n != fileNumber {
            // A new log: read it from the start.
            try? h.close()
            handle = nil
            open()
            offset = 0
            try? handle?.seek(toOffset: 0)
            partial = ""
            return
        }
        lock.lock(); logSize = Int(size); lock.unlock()
        if size < offset {            // log rotated — start again
            offset = 0
            try? h.seek(toOffset: 0)
        }
        guard size > offset else { lastReadAt = Date().timeIntervalSince1970; return }
        try? h.seek(toOffset: offset)
        let data = h.readData(ofLength: Int(min(size - offset, 1 << 20)))
        offset += UInt64(data.count)
        lastReadAt = Date().timeIntervalSince1970
        guard let text = String(data: data, encoding: .utf8) else { return }
        ingest(text)
    }

    private func ingest(_ text: String) {
        partial += text
        var lines = partial.components(separatedBy: .newlines)
        partial = lines.popLast() ?? ""
        var fresh: [CombatRow] = []
        for line in lines {
            let stamp = CombatLogTail.logStamp(line)
            if myID == nil, let id = CombatLogTail.steamID(in: line) {
                lock.lock(); myID = id; lock.unlock()
            }
            if myName == nil, let name = CombatLogTail.userName(in: line) {
                lock.lock(); myName = name; lock.unlock()
            }
            if let kill = CombatLogTail.parseKill(line) {
                var record = kill
                record["at"] = stamp ?? Date().timeIntervalSince1970
                record["myName"] = myName ?? NSNull()
                appendJSON(record, to: "kills.jsonl")
                lock.lock(); killLines += 1; lock.unlock()
                continue
            }
            if CombatLogTail.isHeader(line) {
                closeDump()
                columns = CombatLogTail.columnStarts(CombatLogTail.stripLogPrefix(line))
                openDump = Dump(at: stamp ?? Date().timeIntervalSince1970, header: true)
                lock.lock(); headersSeen += 1; lock.unlock()
                continue
            }
            if openDump != nil, let hidden = CombatLogTail.hiddenCount(line) {
                openDump!.hidden = hidden
                closeDump()
                continue
            }
            // Rows carry no timestamp prefix of their own: they belong to the
            // header just above them, so they take its time.
            // Under a header, never fall back to the old ID-column parser: it
            // reads a weapon path with spaces as two extra ID columns and files
            // the hit as rejected (2026-10-28, semi auto pistol / high caliber revolver).
            let underHeader = stamp == nil && openDump?.header == true && columns != nil
            let tabled = underHeader ? CombatLogTail.parse(line, columns: columns!) : nil
            // Without a header (a restart re-reads from mid-dump) a current-format
            // row has no time: rows carry none of their own, and stamping it with
            // "now" invents hits (2026-10-28 20:43, 301 of them). Drop it. The old
            // ID-column format is the only one read without a header.
            let loose = underHeader || CombatLogTail.parseWide(line) != nil ? nil : CombatLogTail.parse(line)
            if var row = tabled ?? loose {
                row.loggedAt = stamp ?? openDump?.at ?? row.seenAt
                // A dump's rows are printed together. Without a header (or if
                // this row is well apart from it) treat it as a new dump.
                if openDump == nil || abs(row.loggedAt - openDump!.at) > 1.0 {
                    closeDump()
                    openDump = Dump(at: row.loggedAt, header: false)
                }
                row.dumpAt = openDump!.at
                openDump!.rows += 1
                openDump!.oldest = max(openDump!.oldest, row.gameTime)
                openDump!.newest = min(openDump!.newest, row.gameTime)
                if isNewEvent(row) {
                    openDump!.newRows += 1
                    fresh.append(row)
                }
                continue
            }
            if !line.trimmingCharacters(in: .whitespaces).isEmpty { closeDump() }
            if CombatLogTail.looksLikeCombatLog(line) {
                keepUnparsed(line)
            }
        }
        guard !fresh.isEmpty else { return }
        lock.lock()
        rowsParsed += fresh.count
        rows.append(contentsOf: fresh)
        if rows.count > 400 { rows.removeFirst(rows.count - 400) }
        lock.unlock()
        append(fresh)
    }

    /// Matches a row against hits already seen and votes on what the time
    /// column means. Returns true if this is a hit not seen before.
    private func isNewEvent(_ row: CombatRow) -> Bool {
        let key = row.contentKey
        for i in events.indices.reversed() where events[i].key == key {
            let e = events[i]
            let dd = row.dumpAt - e.lastDumpAt
            guard dd > 0.5 else { continue }          // same dump: a different hit
            let dv = row.gameTime - e.lastValue
            let sameClock = abs(dv) < 0.05
            let sameAgo = abs(dv - dd) < 0.6
            guard sameClock || sameAgo else { continue }
            // Votes only from dumps far enough apart for the two readings to
            // disagree by more than the display's 0.1 s rounding.
            if dd > 2 && sameClock != sameAgo {
                lock.lock()
                if sameAgo { votesAgo += 1 } else { votesClock += 1 }
                lock.unlock()
                writeEvidence(key: key, v1: e.lastValue, v2: row.gameTime,
                              d1: e.lastDumpAt, d2: row.dumpAt, vote: sameAgo ? "ago" : "clock")
                reportVerdictOnce()
            }
            events[i].lastValue = row.gameTime
            events[i].lastDumpAt = row.dumpAt
            return false
        }
        events.append(Seen(key: key, lastValue: row.gameTime, lastDumpAt: row.dumpAt))
        if events.count > 600 { events.removeFirst(events.count - 600) }
        return true
    }

    /// "ago", "clock", or nil while the evidence is thin or mixed.
    var clockVerdict: String? {
        lock.lock(); defer { lock.unlock() }
        if votesAgo >= 3 && votesAgo >= 4 * votesClock { return "ago" }
        if votesClock >= 3 && votesClock >= 4 * votesAgo { return "clock" }
        return nil
    }

    private func reportVerdictOnce() {
        guard !clockVerdictLogged, let verdict = clockVerdict else { return }
        clockVerdictLogged = true
        log(verdict == "ago"
            ? "combat log: the time column is seconds-before-the-dump (\(votesAgo) repeated hits agree, \(votesClock) disagree). Hit time = dump time − value."
            : "combat log: the time column is a server clock, not seconds-ago (\(votesClock) repeated hits agree, \(votesAgo) disagree). The join needs an offset; see combat/clockcheck.jsonl.")
    }

    private func closeDump() {
        guard let d = openDump else { return }
        openDump = nil
        lock.lock()
        dumpsSeen += 1
        lastDumpAt = d.at
        lastDumpRows = d.rows
        lock.unlock()
        // The server hides hits from the last 10 s ("+ N events in the last 10
        // seconds"). A dump that hides some and whose newest visible value is
        // just past 10 only makes sense if the column is seconds-ago: as a
        // server clock it would mean the server started ten seconds earlier.
        if d.hidden > 0, d.rows > 0, d.newest >= 9.9, d.newest < 15 {
            lock.lock(); votesAgo += 1; lock.unlock()
            writeEvidence(key: "hidden-window", v1: d.newest, v2: d.newest, d1: d.at, d2: d.at, vote: "ago")
            reportVerdictOnce()
        }
        let record: [String: Any] = [
            "dumpAt": d.at, "header": d.header, "rows": d.rows, "newRows": d.newRows, "hidden": d.hidden,
            "oldestValue": d.rows > 0 ? d.oldest : NSNull(),
            "newestValue": d.rows > 0 ? d.newest : NSNull(),
        ]
        appendJSON(record, to: "dumps.jsonl")
    }

    private func writeEvidence(key: String, v1: Double, v2: Double, d1: Double, d2: Double, vote: String) {
        guard evidenceWritten < 300 else { return }
        evidenceWritten += 1
        appendJSON(["key": key, "value1": v1, "value2": v2, "dump1": d1, "dump2": d2,
                    "valueGrew": ((v2 - v1) * 1000).rounded() / 1000, "dumpGap": ((d2 - d1) * 1000).rounded() / 1000,
                    "vote": vote], to: "clockcheck.jsonl")
    }

    private func appendJSON(_ object: [String: Any], to name: String) {
        guard let data = jsonData(object, options: [.sortedKeys]),
              let json = String(data: data, encoding: .utf8) else { return }
        let fm = FileManager.default
        try? fm.createDirectory(at: CombatLogTail.outputDir, withIntermediateDirectories: true)
        let url = CombatLogTail.outputDir.appendingPathComponent(name)
        let line = json + "\n"
        if let h = try? FileHandle(forWritingTo: url) {
            h.seekToEndOfFile()
            h.write(Data(line.utf8))
            try? h.close()
        } else {
            try? line.write(to: url, atomically: true, encoding: .utf8)
        }
    }

    /// The `-timestamps` prefix on a log line, as Unix seconds.
    static func logStamp(_ raw: String) -> Double? {
        let parts = raw.split(separator: "|", maxSplits: 2, omittingEmptySubsequences: false)
        guard parts.count == 3, parts[0].count < 40, parts[0].contains("T") else { return nil }
        return stampFormatter.date(from: String(parts[0]))?.timeIntervalSince1970
    }
    private static let stampFormatter: ISO8601DateFormatter = {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f
    }()

    /// The column header the game prints at the top of every dump.
    static func isHeader(_ raw: String) -> Bool {
        let l = stripLogPrefix(raw).lowercased()
        return l.count < 400 && l.contains("attacker") && l.contains("target") && l.contains("weapon")
    }

    /// `"UserName":"…"` from the game's crash-session marker line.
    static func userName(in raw: String) -> String? {
        guard let r = raw.range(of: "\"UserName\":\"") else { return nil }
        let name = raw[r.upperBound...].prefix { $0 != "\"" }
        return name.isEmpty ? nil : String(name)
    }

    /// A kill announcement, colour tags removed:
    ///   [System] User Food Stamp Champ Killed flouzyysss (M16A2 - 10.71m - Stomach)
    ///   [System] Killed Bot (28.87m - Leg)
    static func parseKill(_ raw: String) -> [String: Any]? {
        let line = stripLogPrefix(raw)
        guard line.hasPrefix("[System]"), line.contains("Killed") else { return nil }
        let plain = line.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
        let body = plain.dropFirst("[System]".count).trimmingCharacters(in: .whitespaces)
        guard let k = body.range(of: " Killed ") ?? (body.hasPrefix("Killed ") ? body.range(of: "Killed ") : nil),
              let open = body.range(of: " (", options: .backwards), body.hasSuffix(")") else { return nil }
        var killer = String(body[..<k.lowerBound]).trimmingCharacters(in: .whitespaces)
        if killer.hasPrefix("User ") { killer = String(killer.dropFirst(5)) }
        let victim = String(body[k.upperBound..<open.lowerBound]).trimmingCharacters(in: .whitespaces)
        let parts = body[open.upperBound..<body.index(before: body.endIndex)]
            .components(separatedBy: " - ").map { $0.trimmingCharacters(in: .whitespaces) }
        var record: [String: Any] = ["killer": killer.isEmpty ? "you" : killer, "victim": victim, "line": plain]
        if let d = parts.first(where: { $0.hasSuffix("m") && Double($0.dropLast()) != nil }) {
            record["distance"] = Double(d.dropLast())!
        }
        if parts.count >= 3 { record["weapon"] = parts[0] }
        if let area = parts.last, Double(area.dropLast()) == nil { record["area"] = area.lowercased() }
        return record
    }

    /// `"UserId":"7656…"` from the game's crash-session marker line.
    static func steamID(in raw: String) -> String? {
        guard let r = raw.range(of: "\"UserId\":\"") else { return nil }
        let id = raw[r.upperBound...].prefix { $0.isNumber }
        return id.count >= 15 ? String(id) : nil
    }

    /// A number from the log. "Infinity" (an invulnerable entity's HP) reads as 0:
    /// such a row is never a hit on a player, and an infinite value can't be written as JSON.
    static func finite<S: StringProtocol>(_ s: S) -> Double? {
        guard let v = Double(s) else { return nil }
        return v.isFinite ? v : 0
    }

    static func columnStarts(_ header: String) -> [(name: String, start: Int)] {
        var out: [(String, Int)] = []
        let chars = Array(header)
        var i = 0
        while i < chars.count {
            if chars[i] != " " && (i == 0 || chars[i - 1] == " ") {
                var j = i
                while j < chars.count && chars[j] != " " { j += 1 }
                out.append((String(chars[i..<j]), i))
                i = j
            } else { i += 1 }
        }
        return out
    }

    /// `+ 24 events in the last 10 seconds`
    static func hiddenCount(_ line: String) -> Int? {
        let l = stripLogPrefix(line).trimmingCharacters(in: .whitespaces)
        guard l.hasPrefix("+"), l.contains("events in the last") else { return nil }
        return Int(l.dropFirst().trimmingCharacters(in: .whitespaces).prefix { $0.isNumber })
    }

    /// A row of the current format, cut at the header's column positions:
    /// `11.84s you  player_18924 assets/…/ak47u.entity.prefab riflebullet leg  33.0m  41.0  100.0  <info>  0  1.00  0.09s  0.00m  58`
    static func parse(_ raw: String, columns: [(name: String, start: Int)]) -> CombatRow? {
        // "weapons/semi auto pistol/…" can be wider than its column, which
        // shifts everything after it. Then read the row by tokens instead.
        if let w = columns.firstIndex(where: { $0.name == "weapon" }), w + 1 < columns.count {
            let chars = Array(raw)
            let lo = min(columns[w].start, chars.count), hi = min(columns[w + 1].start, chars.count)
            let cell = String(chars[lo..<hi]).trimmingCharacters(in: .whitespaces)
            if cell != "N/A" && cell.contains("/") && !cell.hasSuffix(".prefab") { return parseWide(raw) }
        }
        let chars = Array(raw)
        var cell: [String: String] = [:]
        for (k, c) in columns.enumerated() {
            let lo = min(c.start, chars.count)
            let hi = k + 1 < columns.count ? min(columns[k + 1].start, chars.count) : chars.count
            cell[c.name] = String(chars[lo..<hi]).trimmingCharacters(in: .whitespaces)
        }
        guard let t = cell["time"], t.hasSuffix("s"), let gameTime = finite(t.dropLast()),
              let d = cell["distance"], d.hasSuffix("m"), let distance = finite(d.dropLast()),
              let oldHP = finite(cell["old_hp"] ?? ""), let newHP = finite(cell["new_hp"] ?? "")
        else { return nil }
        let attacker = cell["attacker"] ?? "", target = cell["target"] ?? ""
        var weapon = cell["weapon"] ?? ""
        // "assets/prefabs/weapons/ak47u/ak47u.entity.prefab" -> "ak47u"
        if weapon != "N/A", weapon.contains("/"), let last = weapon.split(separator: "/").last {
            weapon = last.replacingOccurrences(of: ".prefab", with: "")
                .replacingOccurrences(of: ".entity", with: "")
        }
        var row = CombatRow(
            gameTime: gameTime,
            // This format has no ID columns; the names are the identities
            // ("you" is always the player).
            attacker: attacker, attackerID: attacker, target: target, targetID: target,
            weapon: weapon, ammo: cell["ammo"] ?? "", area: cell["area"] ?? "",
            distance: distance, oldHP: oldHP, newHP: newHP,
            info: cell["info"] ?? "",
            seenAt: Date().timeIntervalSince1970
        )
        for name in ["hits", "integrity", "travel", "mismatch", "desync"] {
            if let v = cell[name] { row.extra[name] = v }
        }
        return row
    }

    /// A current-format row read by tokens: the weapon runs up to the first
    /// token ending in ".prefab", the last five tokens are hits…desync, and
    /// anything between new_hp and those is info.
    static func parseWide(_ raw: String) -> CombatRow? {
        let f = stripLogPrefix(raw).split(whereSeparator: { $0 == " " || $0 == "\t" }).map(String.init)
        // f[3] starting "assets/" tells it from the old format, whose f[3] is a name.
        guard f.count >= 9, f[0].hasSuffix("s"), let gameTime = finite(f[0].dropLast()), f[3].hasPrefix("assets/"),
              let end = f[3...].firstIndex(where: { $0.hasSuffix(".prefab") }), end + 5 < f.count,
              f[end + 3].hasSuffix("m"), let distance = finite(f[end + 3].dropLast()),
              let oldHP = finite(f[end + 4]), let newHP = finite(f[end + 5])
        else { return nil }
        let rest = Array(f[(end + 6)...])
        let tail = rest.count >= 5 ? Array(rest.suffix(5)) : []
        let weapon = (f[end].split(separator: "/").last.map(String.init) ?? f[end])
            .replacingOccurrences(of: ".prefab", with: "").replacingOccurrences(of: ".entity", with: "")
        var row = CombatRow(
            gameTime: gameTime,
            attacker: f[1], attackerID: f[1], target: f[2], targetID: f[2],
            weapon: weapon, ammo: f[end + 1], area: f[end + 2],
            distance: distance, oldHP: oldHP, newHP: newHP,
            info: (tail.isEmpty ? rest : Array(rest.dropLast(5))).joined(separator: " "),
            seenAt: Date().timeIntervalSince1970
        )
        for (name, v) in zip(["hits", "integrity", "travel", "mismatch", "desync"], tail) { row.extra[name] = v }
        return row
    }

    /// A combatlog row in the older, whitespace-separated format with ID columns: `12.3s  attacker  id  target  id  weapon  ammo  area  4.5m  100  55  info`
    static func parse(_ raw: String) -> CombatRow? {
        let line = stripLogPrefix(raw).trimmingCharacters(in: .whitespaces)
        guard !line.isEmpty else { return nil }
        let f = line.split(whereSeparator: { $0 == " " || $0 == "\t" }).map(String.init)
        guard f.count >= 11 else { return nil }
        guard f[0].hasSuffix("s"), let gameTime = finite(f[0].dropLast()) else { return nil }
        guard f[8].hasSuffix("m"), let distance = finite(f[8].dropLast()) else { return nil }
        guard let oldHP = finite(f[9]), let newHP = finite(f[10]) else { return nil }
        return CombatRow(
            gameTime: gameTime,
            attacker: f[1], attackerID: f[2], target: f[3], targetID: f[4],
            weapon: f[5], ammo: f[6], area: f[7],
            distance: distance, oldHP: oldHP, newHP: newHP,
            info: f.count > 11 ? f[11...].joined(separator: " ") : "",
            seenAt: Date().timeIntervalSince1970
        )
    }

    /// Rust's player log puts a timestamp and a thread id in front of every
    /// line, separated by pipes:
    ///
    ///     2026-10-28T10:59:40.201Z|0x1ecdc5e80|<the actual message>
    ///
    /// The combat log rows arrive wearing that prefix, which is why a parser
    /// written against the raw console format matched nothing at all.
    static func stripLogPrefix(_ raw: String) -> String {
        let parts = raw.split(separator: "|", maxSplits: 2, omittingEmptySubsequences: false)
        guard parts.count == 3, parts[0].count < 40, parts[0].contains("T") else { return raw }
        return String(parts[2])
    }

    /// Lines that mention the right sort of thing but didn't parse — kept as a
    /// small sample so a format mismatch is visible instead of silent.
    static func looksLikeCombatLog(_ line: String) -> Bool {
        let l = stripLogPrefix(line).lowercased()
        guard l.count < 400 else { return false }
        if l.contains("combatlog") { return true }
        // Weapons show up as prefab names ("ak47u.entity", "bow_hunting.entity")
        // and ammo as e.g. "riflebullet", so the dotted item names alone
        // would miss real rows.
        let markers = ["rifle.", "pistol.", "smg.", "shotgun.", "bow.", "crossbow",
                       "headshot", "556", "762", "arrow.", ".entity", "bullet"]
        let areas = ["head", "chest", "stomach", "leftarm", "rightarm", "leftleg", "rightleg"]
        return markers.contains(where: l.contains) && areas.contains(where: l.contains)
    }

    private func keepUnparsed(_ line: String) {
        lock.lock()
        let kept = unparsedKept
        if kept < 60 { unparsedKept += 1 }
        lock.unlock()
        guard kept < 60 else { return }
        let url = CombatLogTail.outputDir.appendingPathComponent("unparsed.txt")
        try? FileManager.default.createDirectory(at: CombatLogTail.outputDir, withIntermediateDirectories: true)
        let entry = line + "\n"
        if let h = try? FileHandle(forWritingTo: url) {
            h.seekToEndOfFile()
            h.write(Data(entry.utf8))
            try? h.close()
        } else {
            try? entry.write(to: url, atomically: true, encoding: .utf8)
        }
    }

    private func append(_ fresh: [CombatRow]) {
        let fm = FileManager.default
        try? fm.createDirectory(at: CombatLogTail.outputDir, withIntermediateDirectories: true)
        let day = DateFormatter()
        day.dateFormat = "yyyy-MM-dd"
        let url = CombatLogTail.outputDir.appendingPathComponent("\(day.string(from: Date())).jsonl")
        var text = ""
        for row in fresh {
            guard let data = jsonData(row.dictionary, options: [.sortedKeys]),
                  let json = String(data: data, encoding: .utf8) else { continue }
            text += json + "\n"
        }
        guard !text.isEmpty else { return }
        if let h = try? FileHandle(forWritingTo: url) {
            h.seekToEndOfFile()
            h.write(Data(text.utf8))
            try? h.close()
        } else {
            try? text.write(to: url, atomically: true, encoding: .utf8)
        }
    }

    /// Totals for the panel. `me` is worked out as whichever Steam ID appears
    /// most often as the attacker, so no name has to be configured.
    func stats() -> [String: Any] {
        lock.lock()
        let rows = self.rows
        let note = self.note
        let logPath = self.logPath
        let logSize = self.logSize
        let unparsedKept = self.unparsedKept
        let myID = self.myID
        let clock: [String: Any] = [
            "votesAgo": votesAgo, "votesClock": votesClock,
            "dumpsSeen": dumpsSeen, "headersSeen": headersSeen,
            "lastDumpAt": lastDumpAt, "lastDumpRows": lastDumpRows,
        ]
        lock.unlock()
        var base: [String: Any] = [
            "note": note, "log": logPath ?? "none", "logSize": logSize,
            "clockCheck": clock, "clockVerdict": clockVerdict ?? "not measured yet",
            "myID": myID ?? "not seen yet",
            "killLines": killLines,
        ]
        guard !rows.isEmpty else {
            base["rows"] = 0
            return base
        }
        var counts: [String: Int] = [:]
        for r in rows { counts[r.attackerID, default: 0] += 1 }
        let me = rows.contains { $0.attacker == "you" } ? "you"
            : myID ?? counts.max { $0.value < $1.value }?.key ?? ""
        let rejected = rows.filter { $0.attackerID == me && $0.isRejected }
        let mine = rows.filter { $0.attackerID == me && !$0.isRejected }
        let against = rows.filter { $0.targetID == me }
        let heads = mine.filter { $0.isHeadshot }.count
        let distances = mine.map { $0.distance }.sorted()
        let medianDistance = distances.isEmpty ? 0 : distances[distances.count / 2]
        let headshotPct: Double = mine.isEmpty ? 0 : round(Double(heads) / Double(mine.count) * 1000) / 10
        let topWeapon: String = Dictionary(grouping: mine, by: { $0.weapon })
            .max { $0.value.count < $1.value.count }?.key ?? ""
        let totals: [String: Any] = [
            "rows": rows.count,
            "rejectedByServer": rejected.count,
            "unparsedKept": unparsedKept,
            "hitsLanded": mine.count,
            "hitsTaken": against.count,
            "headshotPct": headshotPct,
            "medianDistanceM": round(medianDistance * 10) / 10,
            "topWeapon": topWeapon,
        ]
        return base.merging(totals) { a, _ in a }
    }
}
