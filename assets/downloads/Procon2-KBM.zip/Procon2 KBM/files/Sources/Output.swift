// Posting keyboard and mouse events, and knowing which app is in front.
// Unchanged behaviour from v4 — this part has never been the problem.

import Foundation
import AppKit
import CoreGraphics
import ApplicationServices
import Darwin

enum Key {
    static let a: CGKeyCode = 0x00
    static let s: CGKeyCode = 0x01
    static let d: CGKeyCode = 0x02
    static let f: CGKeyCode = 0x03
    static let h: CGKeyCode = 0x04
    static let g: CGKeyCode = 0x05
    static let z: CGKeyCode = 0x06
    static let x: CGKeyCode = 0x07
    static let c: CGKeyCode = 0x08
    static let v: CGKeyCode = 0x09
    static let b: CGKeyCode = 0x0B
    static let q: CGKeyCode = 0x0C
    static let w: CGKeyCode = 0x0D
    static let e: CGKeyCode = 0x0E
    static let r: CGKeyCode = 0x0F
    static let t: CGKeyCode = 0x11
    static let p: CGKeyCode = 0x23
    static let n1: CGKeyCode = 0x12
    static let n2: CGKeyCode = 0x13
    static let n3: CGKeyCode = 0x14
    static let n4: CGKeyCode = 0x15
    static let n6: CGKeyCode = 0x16
    static let n5: CGKeyCode = 0x17
    static let n7: CGKeyCode = 0x1A
    static let n8: CGKeyCode = 0x1C
    static let n9: CGKeyCode = 0x19
    static let n0: CGKeyCode = 0x1D
    static let n: CGKeyCode = 0x2D
    static let m: CGKeyCode = 0x2E
    static let tab: CGKeyCode = 0x30
    static let space: CGKeyCode = 0x31
    static let escape: CGKeyCode = 0x35
    static let shift: CGKeyCode = 0x38
    static let option: CGKeyCode = 0x3A
    static let control: CGKeyCode = 0x3B
    static let f8: CGKeyCode = 0x64

    static let byName: [String: CGKeyCode] = [
        "z": z, "x": x, "c": c, "v": v, "b": b, "n": n, "m": m,
        "alt": option, "f8": f8,
    ]
}

enum Action {
    case key(CGKeyCode)
    case mouseLeft, mouseRight, mouseMiddle
    case wheelUp, wheelDown
    case sprint

    var id: String {
        switch self {
        case .key(let k): return "key\(k)"
        case .mouseLeft: return "mouseL"
        case .mouseRight: return "mouseR"
        case .mouseMiddle: return "mouseM"
        case .wheelUp: return "wheelU"
        case .wheelDown: return "wheelD"
        case .sprint: return "key\(Key.shift)"
        }
    }
}

final class Output {
    private let source = CGEventSource(stateID: .hidSystemState)
    private var flags: CGEventFlags = []
    private(set) var leftDown = false
    private(set) var rightDown = false
    private(set) var middleDown = false

    private static let modifierMasks: [CGKeyCode: CGEventFlags] = [
        Key.shift: .maskShift,
        Key.control: .maskControl,
        Key.option: .maskAlternate,
    ]

    /// Only Shift rides along on other events: Control or Option combined with
    /// a key can trigger a macOS shortcut instead of reaching the game.
    private var safeFlags: CGEventFlags { flags.intersection(.maskShift) }

    func key(_ code: CGKeyCode, _ down: Bool) {
        guard let event = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: down) else { return }
        if let mask = Output.modifierMasks[code] {
            if down { flags.insert(mask) } else { flags.remove(mask) }
            event.type = .flagsChanged
            event.flags = flags
        } else {
            event.flags = safeFlags
        }
        event.post(tap: .cghidEventTap)
    }

    func clearModifiers() {
        flags = []
        for code in [Key.shift, Key.control, Key.option] {
            guard let event = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: false) else { continue }
            event.type = .flagsChanged
            event.flags = []
            event.post(tap: .cghidEventTap)
        }
    }

    func button(left: Bool, _ down: Bool) {
        if left { leftDown = down } else { rightDown = down }
        let type: CGEventType = left
            ? (down ? .leftMouseDown : .leftMouseUp)
            : (down ? .rightMouseDown : .rightMouseUp)
        guard let event = CGEvent(mouseEventSource: source, mouseType: type,
                                  mouseCursorPosition: cursor(), mouseButton: left ? .left : .right) else { return }
        event.flags = safeFlags
        event.post(tap: .cghidEventTap)
    }

    func middleButton(_ down: Bool) {
        middleDown = down
        guard let event = CGEvent(mouseEventSource: source, mouseType: down ? .otherMouseDown : .otherMouseUp,
                                  mouseCursorPosition: cursor(), mouseButton: .center) else { return }
        event.flags = safeFlags
        event.post(tap: .cghidEventTap)
    }

    func move(dx: Int, dy: Int, moveCursor: Bool) {
        let type: CGEventType = leftDown ? .leftMouseDragged
            : rightDown ? .rightMouseDragged
            : middleDown ? .otherMouseDragged
            : .mouseMoved
        let button: CGMouseButton = leftDown ? .left : rightDown ? .right : middleDown ? .center : .left
        let current = cursor()
        let position = moveCursor
            ? clampToDisplays(CGPoint(x: current.x + CGFloat(dx), y: current.y + CGFloat(dy)))
            : current
        guard let event = CGEvent(mouseEventSource: source, mouseType: type,
                                  mouseCursorPosition: position, mouseButton: button) else { return }
        event.setIntegerValueField(.mouseEventDeltaX, value: Int64(dx))
        event.setIntegerValueField(.mouseEventDeltaY, value: Int64(dy))
        event.flags = safeFlags
        event.post(tap: .cghidEventTap)
    }

    func wheel(_ lines: Int32) {
        guard let event = CGEvent(scrollWheelEvent2Source: source, units: .line,
                                  wheelCount: 1, wheel1: lines, wheel2: 0, wheel3: 0) else { return }
        event.flags = []
        event.post(tap: .cghidEventTap)
    }

    private func cursor() -> CGPoint { CGEvent(source: nil)?.location ?? .zero }

    private var displayBounds: CGRect = .null
    private var boundsCheckedAt = 0.0

    private func clampToDisplays(_ p: CGPoint) -> CGPoint {
        let now = ProcessInfo.processInfo.systemUptime
        if displayBounds.isNull || now - boundsCheckedAt > 5 {
            boundsCheckedAt = now
            var count: UInt32 = 0
            CGGetActiveDisplayList(0, nil, &count)
            var ids = [CGDirectDisplayID](repeating: 0, count: Int(count))
            CGGetActiveDisplayList(count, &ids, &count)
            displayBounds = ids.reduce(CGRect.null) { $0.union(CGDisplayBounds($1)) }
        }
        guard !displayBounds.isNull else { return p }
        return CGPoint(x: min(max(p.x, displayBounds.minX), displayBounds.maxX - 1),
                       y: min(max(p.y, displayBounds.minY), displayBounds.maxY - 1))
    }
}

let cursorIsVisible: () -> Bool = { () -> () -> Bool in
    typealias Fn = @convention(c) () -> Int32
    guard let symbol = dlsym(UnsafeMutableRawPointer(bitPattern: -2), "CGCursorIsVisible") else {
        return { false }
    }
    let fn = unsafeBitCast(symbol, to: Fn.self)
    return { fn() != 0 }
}()

final class FocusWatcher {
    var onChange: ((String) -> Void)?
    private var observer: NSObjectProtocol?

    func start() {
        observer = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didActivateApplicationNotification, object: nil, queue: .main
        ) { [weak self] note in
            let app = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication
            self?.report(app)
        }
        report(NSWorkspace.shared.frontmostApplication)
    }

    private func report(_ app: NSRunningApplication?) {
        let name = [app?.localizedName, app?.bundleIdentifier].compactMap { $0 }.joined(separator: " ")
        onChange?(name)
    }
}

/// What the panel reads. Written from the main thread about ten times a
/// second, read by the server thread, so neither waits on the other.
final class Live {
    static let shared = Live()
    private let lock = NSLock()
    private var values: [String: Any] = [:]

    func set(_ new: [String: Any]) {
        lock.lock()
        for (k, v) in new { values[k] = v }
        lock.unlock()
    }

    func snapshot() -> [String: Any] {
        lock.lock(); defer { lock.unlock() }
        return values
    }
}
