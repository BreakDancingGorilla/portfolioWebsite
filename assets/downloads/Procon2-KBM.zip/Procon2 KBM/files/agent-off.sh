#!/bin/zsh
# Stop procon2-kbm and keep it from starting itself again.
set -u
launchctl unload -w "$HOME/Library/LaunchAgents/com.procon2.kbm.plist" 2>/dev/null
pkill -CONT -x procon2-kbm 2>/dev/null
pkill -x procon2-kbm 2>/dev/null
print "stopped. ./build.sh starts it again."
