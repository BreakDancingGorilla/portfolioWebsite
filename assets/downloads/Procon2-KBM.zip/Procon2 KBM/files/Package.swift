// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "procon2-kbm",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(
            name: "procon2-kbm",
            path: "Sources",
            linkerSettings: [
                .linkedFramework("IOKit"),
                .linkedFramework("IOUSBHost"),
                .linkedFramework("CoreGraphics"),
                .linkedFramework("ApplicationServices"),
            ]
        )
    ]
)
