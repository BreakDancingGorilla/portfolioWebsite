Procon2 KBM
===========

Play PC games that only take keyboard and mouse with a Nintendo Switch 2 Pro
Controller. Procon2 KBM turns the controller's sticks and buttons into
keyboard keys and mouse movement, with a control panel in your browser for
sensitivity, dead zones, button mapping and profiles. It was built and tuned
for Rust.

Needs
  - A Mac with macOS 13 (Ventura) or newer
  - A Nintendo Switch 2 Pro Controller, plugged in with a USB-C cable
  - The procon2 tool, which switches the controller on over USB:
      https://github.com/caqlayan/procon2-mac

Install (once)
  1. Double-click Install.command.
     If macOS says it can't be opened: open System Settings > Privacy &
     Security, scroll down, and click "Open Anyway" next to Install.command.
  2. It copies the tool to ~/procon2-kbm, builds it, starts it in the
     background, and puts a "Procon2 KBM" app on your Desktop.
  3. Turn on procon2-kbm in both of these, then restart it from the panel:
       System Settings > Privacy & Security > Accessibility
       System Settings > Privacy & Security > Input Monitoring
     If it isn't listed, press + and pick ~/procon2-kbm/bin/procon2-kbm

Using it
  - Plug in the controller and click Procon2 KBM on your Desktop.
  - The control panel opens at http://127.0.0.1:7777. Change settings there;
    they save straight away to ~/procon2-kbm/config.json.

Stop it
  zsh ~/procon2-kbm/agent-off.sh     (Install.command or build.sh starts it again)

Optional
  zsh ~/procon2-kbm/setup-signing.sh
  Makes a local signing certificate so rebuilding doesn't reset the
  Accessibility permission.
