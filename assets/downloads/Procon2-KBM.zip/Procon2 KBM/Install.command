#!/bin/zsh
# Procon2 KBM installer: copies the tool to ~/procon2-kbm, builds it, and puts
# a "Procon2 KBM" app on the Desktop. Safe to run again to update; your
# settings and recordings in ~/procon2-kbm are kept.

set -u
cd "${0:A:h}" || exit 1
HERE="$PWD"
DEST="$HOME/procon2-kbm"

say()  { print "\n\033[1m$*\033[0m"; }
fail() { print "\n\033[31m$*\033[0m\n"; read -r "?Press Return to close this window." _; exit 1; }

say "Installing Procon2 KBM"

# Files downloaded from the internet are flagged by macOS.
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null

[ -d files/Sources ] || fail "Missing the files folder. Keep everything in the same folder as this installer."

# 1. macOS version
OSV="$(sw_vers -productVersion)"
[ "${OSV%%.*}" -ge 13 ] 2>/dev/null || fail "Procon2 KBM needs macOS 13 (Ventura) or newer. This Mac has macOS $OSV."

# 2. Apple's Command Line Tools (the Swift compiler)
if ! xcode-select -p >/dev/null 2>&1 || ! xcrun --find swift >/dev/null 2>&1; then
  xcode-select --install 2>/dev/null
  fail "First, Apple's Command Line Tools need to be installed. A window should have popped up:
click Install, wait for it to finish, then double-click this installer again."
fi

# 3. The procon2 tool that switches the controller on over USB
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v procon2 >/dev/null 2>&1; then
  print "\n\033[33mNote: the procon2 tool isn't installed yet.\033[0m"
  print "Procon2 KBM uses it to switch the controller on. Get it from:"
  print "  https://github.com/caqlayan/procon2-mac"
  print "The install will continue; the controller will work once procon2 is installed."
fi

# 4. Copy the source in, keeping config.json, logs and recordings
mkdir -p "$DEST" || fail "Couldn't create $DEST"
rm -rf "$DEST/Sources"
cp -R files/. "$DEST/" || fail "Couldn't copy files into $DEST"
chmod +x "$DEST"/*.sh "$DEST"/launcher/*.sh
print "Installed files: $DEST"

# 5. Build, install the background service, and make the Desktop app
say "Building (the first build takes a minute or two)..."
zsh "$DEST/build.sh" || fail "The build failed. The errors are in $DEST/build.log"
zsh "$DEST/launcher/make-launcher.sh" >/dev/null 2>&1 && print "Desktop app: ~/Desktop/Procon2 KBM.app"

say "All set!"
print "Turn on these two permissions for procon2-kbm, then click Procon2 KBM on your Desktop:"
print "  System Settings > Privacy & Security > Accessibility"
print "  System Settings > Privacy & Security > Input Monitoring"
print ""
read -r "?Press Return to close this window." _
