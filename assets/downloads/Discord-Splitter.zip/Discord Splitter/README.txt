Discord Splitter
================

Turns big videos into parts that fit under your Discord upload limit and play
right inside Discord. Queue up as many videos as you like; it works through
them in the background and tells you when each one is ready.

Needs: a Mac with macOS 13 (Ventura) or newer, and Homebrew (https://brew.sh).

Install (once)
  1. Double-click Install.command.
     If macOS says it can't be opened: open System Settings > Privacy &
     Security, scroll down, and click "Open Anyway" next to Install.command.
  2. It sets up Python and ffmpeg if needed, builds the app on your Mac, and
     opens it. Drag the app to your Dock.

Using it
  - Drop videos onto the window or the Dock icon (or click Add Videos).
  - Check the summary, then Add to Queue. You can keep adding while it works.
  - When a video is done: the folder button shows the parts, the chat button
    opens Discord. Post them in order. Discord takes 10 files per message,
    which is why parts come in "Message 1", "Message 2" folders.
  - Click "Mark Posted" once they're up. If cleanup is on, the parts move to
    the Trash a day later (next time the app is open), so they don't pile up.

Settings
  - Part size: 1 GB (Nitro), 50 MB (Nitro Basic), 20 MB (free), or custom.
  - Quality: Original splits with no re-encoding (fast, lossless). Smaller
    files tests each video on samples and picks the smallest size that stays
    within about 4% of the original's quality (measured with VMAF), for far
    fewer parts. Surround sound becomes stereo, which is all Discord plays.
    If a video is already compressed so well that shrinking wouldn't help,
    it's left as it is.
  - Fast shrink: quicker encoder settings. About 1.7x as quick, files about
    10% bigger. Every re-encode is checked against the original and redone
    once at higher quality if it falls short.
  - Overlap: each part starts a few seconds before the previous one ended.
  - My server plays H.265 & AV1: turn on after a test upload of an H.265
    video (any iPhone video) plays for your friends. Those videos are then
    split as they are (minutes, lossless) instead of converted, and
    shrinking makes AV1 (about 25% smaller than H.264). Post one shrunk
    video as a test first. Older PCs and older iPhones can't play these.
  - Quick jobs first: quick splits jump ahead of slow re-encodes.
  - Channel link: right-click your channel in Discord > Copy Link.

What happens to each video
  - MP4s Discord can play are split without re-encoding.
  - MKV and other containers are converted to MP4 without quality loss.
  - Audio Discord can't play (AC3, DTS, ...) is converted to AAC.
  - H.265 and AV1 are converted to H.264 unless you've turned on the H.265 &
    AV1 setting. Other formats Discord can't play are always converted.
  - Your Mac stays awake while the queue runs. If it restarts or crashes, the
    queue picks up again next time you open the app.

Command line (same engine)
  python3 split_video.py movie.mp4 --max-size 500M --overlap 3 --batch 10
  python3 split_video.py movie.mp4 --smaller --fast

Files: the app keeps its queue and settings in
  ~/Library/Application Support/<app name>/
