#!/bin/bash
# Discord Splitter installer: sets up ffmpeg, installs the engine and builds the Mac app.
# Safe to run again any time (updates in place; your queue and settings are kept).

APP_NAME="Discord Splitter Beta"
BUNDLE_ID="local.discordsplitter.beta"
SUPPORT_NAME="Discord Splitter Beta"
VERSION="2.2b1"
EXEC="DiscordSplitter"

cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
SUPPORT="$HOME/Library/Application Support/$SUPPORT_NAME"

say()  { printf '\n\033[1m%s\033[0m\n' "$*"; }
fail() { printf '\n\033[31m%s\033[0m\n\n' "$*"; read -r -p "Press Return to close this window." _; exit 1; }

say "Installing $APP_NAME $VERSION"

# files downloaded from the internet are flagged by macOS; this folder came from someone you trust
xattr -dr com.apple.quarantine "$HERE" 2>/dev/null

for f in split_video.py DiscordSplitter.swift; do
  [ -f "$f" ] || fail "Missing $f. Keep everything in the same folder as this installer."
done

# 1. macOS version
OSV="$(sw_vers -productVersion)"
[ "${OSV%%.*}" -ge 13 ] 2>/dev/null || fail "This app needs macOS 13 (Ventura) or newer. This Mac has macOS $OSV."

# 2. Apple's Command Line Tools (Python + the Swift compiler)
if ! xcode-select -p >/dev/null 2>&1 || ! xcrun --find swiftc >/dev/null 2>&1; then
  xcode-select --install 2>/dev/null
  fail "First, Apple's Command Line Tools need to be installed. A window should have popped up:
click Install, wait for it to finish (it can take a while), then double-click this installer again."
fi
PY=""
for c in /usr/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
  if [ -x "$c" ] && "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
[ -n "$PY" ] || fail "Couldn't find Python 3.8 or newer."
echo "Python: $PY ($("$PY" --version 2>&1))"

# 3. ffmpeg (via Homebrew)
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if command -v ffmpeg >/dev/null 2>&1 && command -v ffprobe >/dev/null 2>&1; then
  echo "ffmpeg: $(command -v ffmpeg)"
else
  command -v brew >/dev/null 2>&1 || fail "ffmpeg isn't installed, and installing it needs Homebrew.

Install Homebrew first (it asks for your Mac password) by pasting this into Terminal:

  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"

Then double-click this installer again."
  say "Installing ffmpeg with Homebrew. This can take a few minutes..."
  brew install ffmpeg || fail "Homebrew couldn't install ffmpeg. See the messages above."
fi

# 4. engine
mkdir -p "$SUPPORT" || fail "Couldn't create $SUPPORT"
cp split_video.py "$SUPPORT/split_video.py" || fail "Couldn't copy the engine."
printf '{"python": "%s"}\n' "$PY" > "$SUPPORT/config.json"
"$PY" "$SUPPORT/split_video.py" version >/dev/null 2>&1 || fail "The engine didn't start with $PY."
echo "Engine: $SUPPORT"

# 5. build the app
say "Building the app (about a minute)..."
BUILD="$(mktemp -d)"
BUNDLE="$BUILD/$APP_NAME.app"
mkdir -p "$BUNDLE/Contents/MacOS" "$BUNDLE/Contents/Resources"
cat > "$BUNDLE/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>$APP_NAME</string>
  <key>CFBundleDisplayName</key><string>$APP_NAME</string>
  <key>CFBundleIdentifier</key><string>$BUNDLE_ID</string>
  <key>CFBundleExecutable</key><string>$EXEC</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>$VERSION</string>
  <key>CFBundleVersion</key><string>$VERSION</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSPrincipalClass</key><string>NSApplication</string>
  <key>DSSupportDirName</key><string>$SUPPORT_NAME</string>
  <key>CFBundleDocumentTypes</key>
  <array>
    <dict>
      <key>CFBundleTypeName</key><string>Video</string>
      <key>CFBundleTypeRole</key><string>Viewer</string>
      <key>LSHandlerRank</key><string>Alternate</string>
      <key>LSItemContentTypes</key>
      <array>
        <string>public.movie</string>
        <string>public.audiovisual-content</string>
        <string>org.matroska.mkv</string>
        <string>public.mpeg-2-transport-stream</string>
      </array>
    </dict>
  </array>
</dict>
</plist>
PLIST

xcrun swiftc -O -swift-version 5 -parse-as-library \
  -target "$(uname -m)-apple-macos13.0" \
  -o "$BUNDLE/Contents/MacOS/$EXEC" DiscordSplitter.swift \
  || fail "Couldn't build the app (see the errors above)."

if [ -f icon.png ]; then
  ICONSET="$BUILD/AppIcon.iconset"; mkdir -p "$ICONSET"
  for s in 16 32 128 256 512; do
    sips -z $s $s icon.png --out "$ICONSET/icon_${s}x${s}.png" >/dev/null 2>&1
    sips -z $((s*2)) $((s*2)) icon.png --out "$ICONSET/icon_${s}x${s}@2x.png" >/dev/null 2>&1
  done
  iconutil -c icns -o "$BUNDLE/Contents/Resources/AppIcon.icns" "$ICONSET" 2>/dev/null || echo "(skipped the icon)"
fi
codesign --force --deep -s - "$BUNDLE" >/dev/null 2>&1

# 6. put it in Applications (replacing an older copy)
if [ -w /Applications ]; then APP_DIR="/Applications"; else APP_DIR="$HOME/Applications"; mkdir -p "$APP_DIR"; fi
APP="$APP_DIR/$APP_NAME.app"
OLD_PID="$(pgrep -f "$APP/Contents/MacOS/$EXEC")"
[ -n "$OLD_PID" ] && kill $OLD_PID 2>/dev/null && sleep 1
rm -rf "$APP"
mv "$BUNDLE" "$APP" || fail "Couldn't move the app into $APP_DIR."
rm -rf "$BUILD"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1
echo "App: $APP"

say "All set!"
echo "$APP_NAME is in $APP_DIR and is opening now."
echo "Tip: drag it to your Dock, then drop videos onto its icon."
open "$APP"
echo
read -r -p "Press Return to close this window." _
