#!/usr/bin/env python3
"""
split_video.py - the engine behind Discord Splitter.

Turns a big video into parts that each fit under an upload limit and play
inline in Discord (H.264 video, AAC/MP3 audio, MP4 files), and runs a queue
of such jobs in the background for the Mac app.

Splitting
  * Files Discord can already play are split with no re-encoding (lossless).
  * MKV/MOV/TS with H.264 inside are converted to MP4 on the fly (lossless).
  * Audio Discord can't play (AC3, DTS, FLAC, Opus...) is converted to AAC.
  * Video Discord can't play (H.265/HEVC, AV1, 10-bit...) is re-encoded.
  * "smaller" quality searches samples of each video for the strongest
    compression that stays within ~4% of the original (VMAF), and shrinks
    surround/oversized audio to stereo AAC; "fast" uses a quicker x264
    preset (about twice as quick, ~12% bigger files). If the server plays
    AV1, shrinking makes AV1 instead (about a third smaller).
  * Every re-encode is quality-checked against the original and redone once
    at higher quality if it falls short. If the samples show re-encoding
    wouldn't make the file meaningfully smaller, the original is kept.
  * Optional overlap: each part starts a few seconds before the previous
    one ended. Optional batch folders of 10 parts (one Discord message).

Direct use (one video, in a terminal)
  python3 split_video.py movie.mp4 [--max-size 500M] [--smaller] [--fast]
                                   [--overlap 3] [--batch 10]

Queue use (what the app calls)
  python3 split_video.py check   --settings JSON FILE...   -> JSON report
  python3 split_video.py enqueue --settings JSON FILE...   -> adds jobs, starts worker
  python3 split_video.py worker | kick | status
  python3 split_video.py cancel|remove|retry|posted|unposted|mark-cleaned ID
  python3 split_video.py move ID up|down
  python3 split_video.py cleanup-due                       -> JSON of parts to trash

Requires Python 3.8+ and ffmpeg/ffprobe (macOS: brew install ffmpeg).
"""

import argparse
import bisect
import fcntl
import json
import math
import os
import re
import shutil
import signal
import subprocess
import sys
import threading
import time
import traceback
import uuid

VERSION = "2.2b1"
HEADROOM = 0.97           # plan parts at 97% of the limit to leave room for container overhead
MAX_ATTEMPTS = 6          # re-plan attempts if a part comes out over the limit
COPY_AUDIO = {"aac", "mp3"}
MODERN_CODECS = {"hevc", "av1"}
MODERN_PIX_FMTS = {"yuv420p", "yuvj420p", "yuv420p10le"}
OK_PIX_FMTS = {"yuv420p", "yuvj420p"}
EXTRA_PATHS = ["/opt/homebrew/bin", "/usr/local/bin"]

# "Smaller files" searches each video for the strongest compression that stays within an
# allowed quality loss, measured on samples against the original. Losses are relative to
# what the metric gives the original compared with itself (VMAF tops out below 100 on
# detailed video), so 0.04 means "4% below a perfect copy".
TARGET_LOSS = float(os.environ.get("DS_TARGET_LOSS", 0.04))    # average across the samples
WORST_LOSS = float(os.environ.get("DS_WORST_LOSS", 0.06))      # any single sample
SSIM_LOSS_SCALE = 0.35    # SSIM moves far less than VMAF for the same visible change
VERIFY_SLACK = 0.015      # the full encode is compared less precisely than the samples
# The search: quality loss grows close to exponentially with CRF (measured on anime, a game
# recording and live action), so each trial predicts the CRF that lands just inside the
# allowed loss and tests it. Usually 2-3 trials; every chosen CRF has been tested.
X264_CRF = {"start": 26.0, "min": 14.0, "max": 34.0, "slope": 0.17, "step": 0.25, "retry": 2.0, "margin": 0.04, "pass": 0.0}
# SVT-AV1 spends fewer bits on some scenes in a full encode than in a short sample (up to
# ~2x the loss on the worst sample, measured), so its samples must pass with room to spare
# (log scale: 0.25 is ~22% inside the limit).
AV1_CRF = {"start": 44.0, "min": 20.0, "max": 58.0, "slope": 0.068, "step": 1.0, "retry": 5.0, "margin": 0.3, "pass": -0.25}
SEARCH_TRIALS = 4
# Measured on anime, a game recording and a live-action music video at 4% loss, with the
# tuning below: "medium" is a little quicker than plain "slow" was and still ~5% smaller
# ("slow" with the tuning: 4% smaller again but 30% slower); "faster" is ~1.7x as quick as
# "medium" for ~12% bigger files. The Mac's hardware encoder needed 60-350% more bits than
# x264 for the same quality, so it's no longer used.
X264_PRESET = os.environ.get("DS_X264_PRESET", "medium")   # env overrides are for tests
X264_FAST_PRESET = os.environ.get("DS_X264_FAST_PRESET", "faster")
# Animation tuning's extra reference frames, B-frames and deblocking saved 8-11% on all
# three kinds of video; psy-rd is put back to the film default so live-action grain
# and texture aren't smoothed away.
X264_TUNING = ["-tune", "animation", "-psy-rd", "1.0:0.0"]
AV1_PRESET, AV1_FAST_PRESET = "8", "9"    # ~30% smaller than x264 slow, and faster
SAMPLE_JOBS = 4                           # samples encoded and scored at the same time
KEEP_RATIO = 0.9          # keep the original if re-encoding would only save less than 10%
SMALL_AUDIO_BITRATE = 160_000             # stereo AAC when shrinking
MAX_SMALL_AUDIO = 256_000                 # AAC/MP3 above this is re-encoded when shrinking
SAMPLE_POINTS = (0.15, 0.4, 0.65, 0.88)
SAMPLE_SECONDS = 6.0
CLEANUP_AFTER = float(os.environ.get("DS_CLEANUP_AFTER", 86400))   # 1 day after "posted"

SUPPORT_DIR = os.environ.get("DS_SUPPORT_DIR") or os.path.dirname(os.path.abspath(__file__))
QUEUE_DIR = os.path.join(SUPPORT_DIR, "queue")
SETTINGS_FILE = os.path.join(SUPPORT_DIR, "settings.json")
DEFAULT_SETTINGS = {"max_size": "1G", "quality": "original", "fast": False, "modern": False, "overlap": 0,
                    "batch": 10, "quick_first": True, "cleanup": True, "channel": ""}
JOB_SETTING_KEYS = ("max_size", "quality", "fast", "modern", "overlap", "batch")

CODEC_NAMES = {
    "h264": "H.264", "hevc": "H.265 (HEVC)", "av1": "AV1", "vp9": "VP9", "vp8": "VP8",
    "mpeg4": "MPEG-4", "mpeg2video": "MPEG-2", "prores": "ProRes", "aac": "AAC",
    "mp3": "MP3", "ac3": "Dolby Digital (AC3)", "eac3": "Dolby Digital Plus",
    "dts": "DTS", "truehd": "Dolby TrueHD", "flac": "FLAC", "opus": "Opus", "vorbis": "Vorbis",
}
BATCH_DIR_RX = re.compile(r"^Message \d+ \(parts \d+-\d+\)$")
TEMP_RX = re.compile(r"^\.(splitting_\d{3}\.mp4|ovl_\d{3}\.ts|encoding(?:_retry)?\.mp4|single\.mp4|sample_\d+\.mp4|ref_\d+\.mkv)$")


class Cancelled(Exception):
    pass


class Failure(Exception):
    pass


# ------------------------------------------------------------------ small helpers

def parse_size(text):
    """'1G' -> 1_000_000_000, '500M' -> 500_000_000. Decimal units on purpose:
    they're a bit smaller than binary ones, so parts are safe either way."""
    m = re.fullmatch(r"\s*([\d.]+)\s*([KMGT]?)i?B?\s*", str(text), re.IGNORECASE)
    if not m:
        raise argparse.ArgumentTypeError(f"can't read size '{text}' (try 1G or 500M)")
    size = int(float(m.group(1)) * {"": 1, "K": 1e3, "M": 1e6, "G": 1e9, "T": 1e12}[m.group(2).upper()])
    if size < 1_000_000:
        raise argparse.ArgumentTypeError("max size must be at least 1M")
    return size


def human(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.2f} {unit}"
        n /= 1000


def hms(seconds):
    seconds = max(0, int(round(seconds)))
    h, m, s = seconds // 3600, seconds % 3600 // 60, seconds % 60
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def codec_name(name):
    return CODEC_NAMES.get(name, (name or "unknown").upper())


def clean(text):
    return re.sub(r"[\t\r\n]+", " ", str(text)).strip()


def cap(msg):
    msg = str(msg)
    return msg[:1].upper() + msg[1:]


def read_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(path, data):
    tmp = f"{path}.tmp-{os.getpid()}"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=1)
    os.replace(tmp, path)


def find_tools():
    """Make sure ffmpeg/ffprobe are reachable, adding Homebrew's folders to PATH
    (apps started from Finder don't get them by default)."""
    parts = os.environ.get("PATH", "").split(os.pathsep)
    for extra in EXTRA_PATHS:
        if extra not in parts and os.path.isdir(extra):
            parts.append(extra)
    os.environ["PATH"] = os.pathsep.join(p for p in parts if p)
    missing = [t for t in ("ffmpeg", "ffprobe") if not shutil.which(t)]
    if missing:
        raise Failure("ffmpeg isn't installed. On a Mac run: brew install ffmpeg")


def global_settings():
    s = dict(DEFAULT_SETTINGS)
    s.update(read_json(SETTINGS_FILE, {}) or {})
    return s


def job_settings(raw):
    s = {k: DEFAULT_SETTINGS[k] for k in JOB_SETTING_KEYS}
    for k in JOB_SETTING_KEYS:
        if raw and k in raw and raw[k] is not None:
            s[k] = raw[k]
    s["fast"] = bool(s["fast"])
    s["modern"] = bool(s["modern"])
    s["overlap"] = max(0.0, float(s["overlap"] or 0))
    s["batch"] = max(0, int(s["batch"] or 0))
    if s["quality"] not in ("original", "smaller"):
        s["quality"] = "original"
    parse_size(s["max_size"])   # validates
    return s


# ------------------------------------------------------------------ job state, cancel, cleanup

class Job:
    def __init__(self):
        self.procs = set()     # running ffmpeg/ffprobe processes (samples run in parallel)
        self.cancelled = False
        self.temp_files = []
        self.outdir = None
        self.created_outdir = False

    def cancel(self):
        self.cancelled = True
        for p in list(self.procs):
            if p.poll() is None:
                try:
                    p.terminate()
                except OSError:
                    pass

    def on_signal(self, signum, frame):
        self.cancel()

    def check(self):
        if self.cancelled:
            raise Cancelled()

    def cleanup(self):
        for f in self.temp_files:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except OSError:
                pass
        if self.outdir and os.path.isdir(self.outdir):
            remove_temps(self.outdir)
            if self.created_outdir:
                try:
                    os.rmdir(self.outdir)      # only succeeds if it's empty
                except OSError:
                    pass


def remove_temps(outdir, only_split=False):
    for f in os.listdir(outdir):
        if TEMP_RX.match(f) and (not only_split or f.startswith((".splitting_", ".ovl_"))):
            try:
                os.remove(os.path.join(outdir, f))
            except OSError:
                pass


JOB = Job()


# ------------------------------------------------------------------ progress reporting

class Reporter:
    def __init__(self):
        self.lo, self.hi, self.label = 0.0, 100.0, ""
        self.last = 0.0

    def stage(self, label, lo, hi):
        self.label, self.lo, self.hi = label, lo, hi
        self.progress(0.0, force=True)

    def progress(self, frac, detail="", force=False):
        self.poll()
        now = time.monotonic()
        if not force and now - self.last < 0.4:
            return
        self.last = now
        pct = self.lo + (self.hi - self.lo) * max(0.0, min(1.0, frac))
        self.emit(pct, self.label + (f" - {detail}" if detail else ""))

    def poll(self):
        """Called often; job reporters use it to notice cancel requests."""

    def emit(self, pct, text):
        pass

    def say(self, msg):
        pass


class ConsoleReporter(Reporter):
    def __init__(self):
        super().__init__()
        self.open_line = False

    def emit(self, pct, text):
        print(f"\r  [{pct:5.1f}%] {text}" + " " * 10, end="", flush=True)
        self.open_line = True

    def say(self, msg):
        if self.open_line:
            print()
            self.open_line = False
        print(msg, flush=True)


class FileReporter(Reporter):
    """Tab-separated progress lines (used by the original AppleScript app)."""

    def __init__(self, path):
        super().__init__()
        self.f = open(path, "a", buffering=1, encoding="utf-8")

    def emit(self, pct, text):
        self.f.write(f"PROGRESS\t{pct:.1f}\t{clean(text)}\n")

    def say(self, msg):
        self.f.write(f"INFO\t{clean(msg)}\n")

    def line(self, text):
        self.f.write(text + "\n")


class JobReporter(Reporter):
    """Writes progress into a queue job's state.json and watches for cancel."""

    def __init__(self, jdir, state):
        super().__init__()
        self.jdir, self.state = jdir, state
        self.started = time.time()
        self.last_write = 0.0

    def poll(self):
        if not JOB.cancelled and os.path.exists(os.path.join(self.jdir, "cancel")):
            JOB.cancel()

    def emit(self, pct, text):
        elapsed = time.time() - self.started
        self.state["progress"] = round(pct, 1)
        self.state["message"] = clean(text)
        self.state["eta"] = round(elapsed * (100 - pct) / pct) if pct >= 3 and elapsed > 20 else None
        self.write()

    def say(self, msg):
        log = self.state.setdefault("log", [])
        log.append(clean(msg))
        self.write(force=True)

    def write(self, force=False):
        now = time.monotonic()
        if force or now - self.last_write > 0.5:
            self.last_write = now
            write_json(os.path.join(self.jdir, "state.json"), self.state)


REP = Reporter()   # the active reporter (so helpers can poll for cancel)


# ------------------------------------------------------------------ probing

def capture(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True, errors="replace")
    if r.returncode != 0:
        raise Failure(f"couldn't read the file: {r.stderr.strip()[-300:]}")
    return r.stdout


def probe(path):
    try:
        data = json.loads(capture(["ffprobe", "-v", "error", "-show_format", "-show_streams",
                                   "-of", "json", path]))
    except (Failure, ValueError):
        raise Failure(f"couldn't read '{os.path.basename(path)}'. Is it a video file?")
    fmt = data.get("format", {})
    streams = data.get("streams", [])
    video = next((s for s in streams if s.get("codec_type") == "video"
                  and not s.get("disposition", {}).get("attached_pic")), None)
    audios = [s for s in streams if s.get("codec_type") == "audio"]
    audio = next((s for s in audios if s.get("disposition", {}).get("default")),
                 audios[0] if audios else None)
    duration = float(fmt.get("duration") or 0)
    if duration <= 0 and video:
        duration = float(video.get("duration") or 0)
    return {
        "path": path,
        "size": os.path.getsize(path),
        "duration": duration,
        "start": float(fmt.get("start_time") or 0),
        "format": fmt.get("format_name", ""),
        "bit_rate": float(fmt.get("bit_rate") or 0),
        "video": video,
        "audio": audio,
    }


def frame_rate(info):
    v = info["video"] or {}
    for key in ("avg_frame_rate", "r_frame_rate"):
        try:
            num, den = (v.get(key) or "0/0").split("/")
            if float(den) > 0 and float(num) > 0:
                return float(num) / float(den)
        except ValueError:
            pass
    return 30.0


def assess(info, modern=False):
    """Work out what has to change for Discord to play this inline. With
    `modern`, H.265/AV1 count as playable (newer devices handle them)."""
    v, a = info["video"], info["audio"]
    codec, pix = v["codec_name"], v.get("pix_fmt")
    if codec == "h264":
        video_ok = pix in OK_PIX_FMTS
    elif codec in MODERN_CODECS and modern:
        video_ok = pix in MODERN_PIX_FMTS
    else:
        video_ok = False
    if video_ok:
        reason = ""
    elif codec in MODERN_CODECS and not modern:
        reason = (f"its video is {codec_name(codec)}, which only plays inside Discord on newer devices "
                  "(if it plays for your server, turn on H.265 & AV1 in Settings)")
    elif codec in ("h264",) + tuple(MODERN_CODECS):
        reason = f"its video uses a color format ({pix}) that doesn't play inside Discord"
    else:
        reason = f"its video is {codec_name(codec)}, which doesn't play inside Discord"
    audio_action = None if a is None else ("copy" if a["codec_name"] in COPY_AUDIO else "aac")
    is_mp4 = info["format"].startswith("mov,mp4")
    return video_ok, audio_action, is_mp4, reason


def audio_bitrate(a):
    return 384_000 if int(a.get("channels") or 2) > 2 else 192_000


def audio_args(info, action):
    if info["audio"] is None:
        return []
    if action == "copy":
        return ["-c:a", "copy"]
    if action == "aac_small":     # shrinking: stereo, since Discord plays everything in stereo
        return ["-c:a", "aac", "-b:a", str(SMALL_AUDIO_BITRATE), "-ac", "2"]
    return ["-c:a", "aac", "-b:a", str(audio_bitrate(info["audio"]))]


def shrink_audio_action(info, action):
    """When making files smaller, also shrink surround or oversized audio."""
    a = info["audio"]
    if a is None:
        return action
    big = float(a.get("bit_rate") or 0) > MAX_SMALL_AUDIO
    return "aac_small" if action == "aac" or big or int(a.get("channels") or 2) > 2 else action


def vtag_args(info):
    return ["-tag:v", "hvc1"] if info["video"]["codec_name"] == "hevc" else []


def stream_maps(info):
    maps = ["-map", f"0:{info['video']['index']}"]
    if info["audio"] is not None:
        maps += ["-map", f"0:{info['audio']['index']}"]
    return maps


def estimate_bytes(info, audio_action):
    est = info["size"]
    a = info["audio"]
    if a is not None and audio_action == "aac" and a.get("bit_rate"):
        est += (audio_bitrate(a) - float(a["bit_rate"])) * info["duration"] / 8
    return max(est, 1)


# ------------------------------------------------------------------ running ffmpeg

def run_ffmpeg(cmd, duration, rep, detail=None, offset=0.0, cwd=None):
    """Run ffmpeg with machine-readable progress. `offset` is added to the
    reported time (for runs that start partway into the video)."""
    full = [cmd[0], "-hide_banner", "-nostdin", "-loglevel", "error",
            "-progress", "pipe:1", "-nostats"] + cmd[1:]
    proc = subprocess.Popen(full, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, errors="replace", cwd=cwd)
    JOB.procs.add(proc)
    errors = []
    reader = threading.Thread(target=lambda: errors.extend(proc.stderr), daemon=True)
    reader.start()
    for line in proc.stdout:
        key, _, value = line.strip().partition("=")
        if key in ("out_time_us", "out_time_ms") and duration > 0:   # both are microseconds
            try:
                t = int(value) / 1e6 + offset
            except ValueError:
                continue
            rep.progress(t / duration, detail(t) if detail else "")
        else:
            rep.poll()
    proc.wait()
    reader.join(2)
    JOB.procs.discard(proc)
    JOB.check()
    if proc.returncode != 0:
        raise Failure("ffmpeg failed: " + " ".join(e.strip() for e in errors[-4:]))


def run_quiet(cmd):
    """Run a command, polling for cancel; returns (returncode, stderr)."""
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                            text=True, errors="replace")
    JOB.procs.add(proc)
    errors = []
    reader = threading.Thread(target=lambda: errors.extend(proc.stderr), daemon=True)
    reader.start()
    while proc.poll() is None:
        REP.poll()
        time.sleep(0.2)
    reader.join(2)
    JOB.procs.discard(proc)
    JOB.check()
    return proc.returncode, "".join(errors)


# ------------------------------------------------------------------ scanning and planning

class Scan:
    def __init__(self, times, sums, keyframes, kf_frames):
        self.times, self.sums = times, sums
        self.keyframes = keyframes      # keyframe timestamps, sorted
        self.kf_frames = kf_frames      # each keyframe's frame number (decode order) for ffmpeg

    @property
    def total(self):
        return self.sums[-1]

    def bytes_before(self, t):
        return self.sums[bisect.bisect_left(self.times, t)]

    def kf_bytes(self):
        return [self.bytes_before(k) for k in self.keyframes] + [self.total]

    def largest_gap(self):
        marks = self.kf_bytes()
        return max(b - a for a, b in zip(marks, marks[1:]))


def scan_packets(info, rep, audio_action):
    """Read packet sizes/timestamps of the streams we keep. Audio that will be
    converted is scaled to its new bitrate so the plan stays accurate."""
    v_idx = str(info["video"]["index"])
    a_idx = str(info["audio"]["index"]) if info["audio"] is not None else None
    ratio = 1.0
    if a_idx is not None and audio_action == "aac":
        old = float(info["audio"].get("bit_rate") or 0)
        ratio = audio_bitrate(info["audio"]) / old if old > 0 else None
    cmd = ["ffprobe", "-v", "error", "-show_entries",
           "packet=stream_index,pts_time,dts_time,size,flags", "-of", "compact=p=0", info["path"]]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                            text=True, bufsize=1 << 20)
    JOB.procs.add(proc)
    video_pk, audio_pk, keyframes = [], [], []
    frame_no = -1      # video frames counted from the first keyframe, like ffmpeg's stream copy
    duration = info["duration"] or 1
    for line in proc.stdout:
        if JOB.cancelled:
            break
        fields = dict(kv.split("=", 1) for kv in line.strip().split("|") if "=" in kv)
        idx = fields.get("stream_index")
        if idx != v_idx and idx != a_idx:
            continue
        t = fields.get("pts_time")
        if t in (None, "N/A"):
            t = fields.get("dts_time")
        try:
            t, size = float(t), int(fields["size"])
        except (TypeError, ValueError, KeyError):
            continue
        if idx == v_idx:
            video_pk.append((t, size))
            is_key = "K" in fields.get("flags", "")
            if frame_no >= 0 or is_key:
                frame_no += 1
            if is_key:
                keyframes.append((t, frame_no))
        else:
            audio_pk.append((t, size))
        rep.progress((t - info["start"]) / duration, hms(t - info["start"]))
    if JOB.cancelled and proc.poll() is None:
        proc.terminate()
    proc.wait()
    JOB.procs.discard(proc)
    JOB.check()
    if not video_pk or not keyframes:
        raise Failure("couldn't find the video's keyframes, so there's nowhere safe to cut.")
    if ratio is None:
        span = max(1e-3, audio_pk[-1][0] - audio_pk[0][0]) if len(audio_pk) > 1 else duration
        measured = sum(s for _, s in audio_pk) * 8 / span
        ratio = audio_bitrate(info["audio"]) / measured if measured > 0 else 1.0
    packets = video_pk + [(t, s * ratio) for t, s in audio_pk]
    packets.sort()
    times = [t for t, _ in packets]
    sums = [0]
    for _, s in packets:
        sums.append(sums[-1] + s)
    keyframes.sort()
    return Scan(times, sums, [t for t, _ in keyframes], [n for _, n in keyframes])


def plan_parts(scan, budget, overlap=0.0):
    """Greedy plan. Returns [(start_kf, end_kf_or_None), ...] as positions in
    scan.keyframes. With overlap, each part starts at the last keyframe at
    least `overlap` seconds before the previous part's end."""
    kf, kb = scan.keyframes, scan.kf_bytes()
    parts, start = [], 0
    while True:
        if scan.total - kb[start] <= budget:
            parts.append((start, None))
            return parts
        j = start
        while j + 1 < len(kf) and kb[j + 1] - kb[start] <= budget:
            j += 1
        if j == start:                      # one stretch between keyframes is bigger than the budget
            if start + 1 >= len(kf):
                parts.append((start, None))
                return parts
            j = start + 1
        parts.append((start, j))
        nxt = j
        if overlap > 0:
            nxt = max(start + 1, bisect.bisect_right(kf, kf[j] - overlap) - 1)
            # never let the overlap eat more than half a part
            while nxt < j and kb[j] - kb[nxt] > budget * 0.5:
                nxt += 1
        start = nxt


# ------------------------------------------------------------------ encoding

class Encoder:
    """x264 (H.264, plays everywhere) or, when the server plays AV1, SVT-AV1 (about a
    third smaller at the same quality). `fast` uses quicker presets of the same encoder.
    `level` is the CRF (lower = higher quality, bigger file)."""

    def __init__(self, fast, info, rep, av1=False):
        self.fast = fast
        self.av1 = av1 and has_encoder("libsvtav1")
        self.note = "" if self.av1 or not av1 else "This ffmpeg can't make AV1, so H.264 was used."
        self.sample_size = None  # sample bytes at the chosen level
        self.level = self.scale["start"]

    def video_args(self, info, level=None):
        level = self.level if level is None else level
        gop = max(1, int(round(frame_rate(info) * 2)))
        keys = ["-force_key_frames", "expr:gte(t,n_forced*2)"]
        if self.av1:
            return ["-c:v", "libsvtav1", "-crf", str(int(round(level))),
                    "-preset", AV1_FAST_PRESET if self.fast else AV1_PRESET, "-g", str(gop),
                    "-svtav1-params", "tune=0", "-pix_fmt", "yuv420p"] + keys
        return ["-c:v", "libx264", "-crf", f"{level:g}", "-preset", X264_FAST_PRESET if self.fast else X264_PRESET,
                "-pix_fmt", "yuv420p", "-profile:v", "high"] + X264_TUNING + keys

    def describe(self):
        if self.av1:
            return f"AV1, {'fast ' if self.fast else ''}SVT-AV1, CRF {int(round(self.level))}"
        return f"H.264, {'fast ' if self.fast else ''}x264, CRF {self.level:g}"

    def encode(self, info, dst, audio_action, height, rep):
        cmd = ["ffmpeg", "-y", "-i", info["path"]] + stream_maps(info) + self.video_args(info)
        if height:
            cmd += ["-vf", f"scale=-2:'min({height},ih)'"]
        cmd += audio_args(info, audio_action) + ["-f", "mp4", dst]
        run_ffmpeg(cmd, info["duration"], rep, lambda t: f"{hms(t)} of {hms(info['duration'])}")

    @property
    def scale(self):
        return AV1_CRF if self.av1 else X264_CRF

    def try_level(self, info, samples, level, height):
        """Encode every sample at `level` (in parallel) -> (losses, total bytes)."""
        def one(k):
            tmp = os.path.join(samples.outdir, f".sample_{k}.mp4")
            JOB.temp_files.append(tmp)
            cmd = ["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y", "-i", samples.refs[k]] + \
                  self.video_args(info, level)
            if height:
                cmd += ["-vf", f"scale=-2:'min({height},ih)'"]
            rc, err = run_quiet(cmd + ["-an", "-f", "mp4", tmp])
            if rc != 0:
                raise Failure("the encoder failed on a sample: " + err.strip()[-200:])
            return samples.loss(k, tmp), os.path.getsize(tmp)
        results = in_parallel(one, range(len(samples.refs)))
        return [l for l, _ in results if l is not None], sum(b for _, b in results)

    def tune(self, info, samples, height, rep, keep_ratio=None):
        """Find the highest CRF (smallest file) whose samples stay within the allowed loss.
        `excess` is how far over the limit a trial is, on a log scale (<= 0 is within); it's
        close to linear in CRF, so two trials give a line to aim with. With `keep_ratio`,
        stop early once a trial that still needs more quality is already that big
        compared with the original (re-encoding can't win)."""
        sc = self.scale
        target, worst = limits(samples.metric, samples.strict)
        trials = []                                    # (crf, excess, sample bytes)

        def excess(losses):
            if not losses:
                return -1.0
            mean = max(sum(losses) / len(losses), 1e-4)
            return max(math.log(mean / target), math.log(max(max(losses), 1e-4) / worst))

        def snap(crf):
            return round(min(sc["max"], max(sc["min"], round(crf / sc["step"]) * sc["step"])), 2)

        crf = snap(sc["start"] - (math.log(2) / sc["slope"] if samples.strict else 0))
        for n in range(SEARCH_TRIALS):
            rep.progress(n / SEARCH_TRIALS, f"trying setting {n + 1}")
            losses, size = self.try_level(info, samples, crf, height)
            trials.append((crf, excess(losses), size))
            if keep_ratio and samples.source_bytes and trials[-1][1] > sc["pass"] and \
                    size >= keep_ratio * samples.source_bytes:
                self.level, self.sample_size = crf, size
                return
            good = [t for t in trials if t[1] <= sc["pass"]]
            bad = [t for t in trials if t[1] > sc["pass"]]
            lo = max(good, default=None)               # best passing CRF so far
            hi = min(bad, default=None)                # lowest failing CRF so far
            # Aim using the two trials nearest the answer (or the typical slope with one).
            near = sorted(trials, key=lambda t: abs(t[1]))[:2]
            slope = sc["slope"]
            if len(near) == 2 and near[0][0] != near[1][0]:
                fit = (near[1][1] - near[0][1]) / (near[1][0] - near[0][0])
                if fit > 0:
                    slope = min(max(fit, sc["slope"] / 3), sc["slope"] * 3)
            aim = near[0][0] + (-sc["margin"] - near[0][1]) / slope
            if lo:
                aim = max(aim, lo[0] + sc["step"])
            if hi:
                aim = min(aim, hi[0] - sc["step"])
            nxt = snap(aim)
            if lo and (nxt <= lo[0] or (hi and hi[0] - lo[0] <= 2 * sc["step"]) or nxt - lo[0] < sc["step"] * 2):
                break                                  # can't gain more than a step or two
            if any(t[0] == nxt for t in trials):
                break
            crf = nxt
        good = [t for t in trials if t[1] <= sc["pass"]]
        if good:
            best = max(good)
        else:                                          # nothing passed: the best we tried
            best = min(trials)
        self.level, self.sample_size = best[0], best[2]

    def predicted_ratio(self, samples):
        """Sample encodes at the chosen level vs the original's video over the same
        stretches. None if the chosen level was never tried on samples."""
        return self.sample_size / samples.source_bytes if self.sample_size and samples.source_bytes else None

    def raise_quality(self, info):
        """Lower the CRF after a failed check. Returns False at the top."""
        if self.level <= self.scale["min"]:
            return False
        self.level = max(self.scale["min"], self.level - self.scale["retry"])
        return True


def in_parallel(fn, items):
    """fn over items on up to SAMPLE_JOBS threads, results in order. Errors are re-raised."""
    from concurrent.futures import ThreadPoolExecutor
    items = list(items)
    with ThreadPoolExecutor(max_workers=max(1, min(SAMPLE_JOBS, len(items)))) as pool:
        return list(pool.map(fn, items))


_ENCODERS = None


def has_encoder(name):
    global _ENCODERS
    if _ENCODERS is None:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-encoders"], capture_output=True, text=True)
        _ENCODERS = r.stdout
    return f" {name} " in _ENCODERS


def limits(metric, strict=False):
    """(average, worst-sample) loss allowed. `strict` halves them: used when a video only
    has to be converted to play in Discord and the user didn't ask for smaller files."""
    target, worst = allowed_loss(metric)
    factor = 0.5 if strict else 1.0
    return target * factor, worst * factor


def allowed_loss(metric):
    scale = 1.0 if metric == "vmaf" else SSIM_LOSS_SCALE
    return TARGET_LOSS * scale, WORST_LOSS * scale


def passes(losses, metric, slack=0.0, strict=False):
    if not losses:
        return True
    target, worst = limits(metric, strict)
    slack *= 1.0 if metric == "vmaf" else SSIM_LOSS_SCALE
    return sum(losses) / len(losses) <= target + slack and max(losses) <= worst + slack


_HAS_VMAF = None


def has_vmaf():
    global _HAS_VMAF
    if _HAS_VMAF is None:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True)
        _HAS_VMAF = " libvmaf " in r.stdout
    return _HAS_VMAF


def sample_windows(duration):
    if duration < 3:
        return []
    secs = min(SAMPLE_SECONDS, duration / 5)
    return [(max(0.0, min(duration * p, duration - secs - 0.5)), secs) for p in SAMPLE_POINTS]


def hevc_open_gop(info):
    """H.265 files made with 'open GOPs' use keyframes (CRA) that the frames just
    after them depend on frames before them. Cutting there makes each part skip a
    split second at its start. Detect it from the first stretch of the file."""
    if info["video"]["codec_name"] != "hevc":
        return False
    rc, err = run_quiet(["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "info", "-t", "30",
                         "-i", info["path"], "-map", f"0:{info['video']['index']}", "-c", "copy",
                         "-bsf:v", "trace_headers", "-f", "null", "-"])
    types = {int(x) for x in re.findall(r"nal_unit_type\s+[01]+ = (\d+)", err)}
    return bool(types & {16, 17, 18, 21})     # BLA / CRA keyframes


def compare(dist, dist_t, ref, ref_t, secs, size, metric, shift=0):
    """Score `secs` seconds of `dist` (from dist_t) against `ref` (from ref_t):
    VMAF (0-100) or SSIM (0-1). `dist` is scaled to the reference size first.
    Frames are paired by position, not timestamp: containers round timestamps
    differently (MKV to the millisecond), which pairs the wrong frames in motion.
    `shift` skips that many frames at the start of dist (>0) or ref (<0)."""
    w, h = size
    scale = f"scale={w}:{h}:flags=bicubic," if w and h else ""
    if metric == "vmaf":
        threads = max(2, (os.cpu_count() or 4) // SAMPLE_JOBS)
        measure = f"libvmaf=n_threads={threads}:n_subsample=2"
        rx = r"VMAF score: ([\d.]+)"
    else:
        measure, rx = "ssim", r"All:([\d.]+)"
    cmd = ["ffmpeg", "-hide_banner", "-nostdin",
           "-ss", f"{dist_t:.3f}", "-i", dist, "-ss", f"{ref_t:.3f}", "-i", ref,
           "-t", f"{secs:.3f}", "-lavfi",
           f"[0:v:0]{trim(shift)}{scale}format=yuv420p,{BY_FRAME}[a];"
           f"[1:v:0]{trim(-shift)}format=yuv420p,{BY_FRAME}[b];[a][b]{measure}",
           "-f", "null", "-"]
    rc, err = run_quiet(cmd)
    m = re.findall(rx, err)
    return float(m[-1]) if rc == 0 and m else None


BY_FRAME = "settb=AVTB,setpts=N/FRAME_RATE/TB"


def trim(frames):
    return f"trim=start_frame={frames}," if frames > 0 else ""


class Samples:
    """Short stretches of the original, saved losslessly so every trial encode and the
    final check compare against exactly the same frames. Also records the score each
    sample gets against itself, which is the most any encode can reach."""

    def __init__(self, info, outdir, rep, strict=False):
        self.info, self.outdir, self.strict = info, outdir, strict
        self.metric = "vmaf" if has_vmaf() else "ssim"
        v = info["video"]
        self.size = (int(v.get("width") or 0), int(v.get("height") or 0))
        self.windows = sample_windows(info["duration"])
        self.refs, self.ceilings = [], []
        self.source_bytes = 0     # the original's video bytes inside the sample windows
        for t, secs in self.windows:
            out = capture(["ffprobe", "-v", "error", "-select_streams", f"{v['index']}", "-read_intervals",
                           f"{t:.3f}%+{secs:.3f}", "-show_entries", "packet=size", "-of", "csv=p=0", info["path"]])
            self.source_bytes += sum(int(x) for x in out.split() if x.isdigit())
        rep.progress(0.1, f"{len(self.windows)} samples")

        def cut(k):
            t, secs = self.windows[k]
            ref = os.path.join(outdir, f".ref_{k}.mkv")
            JOB.temp_files.append(ref)
            rc, err = run_quiet(["ffmpeg", "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
                                 "-ss", f"{t:.3f}", "-i", info["path"], "-t", f"{secs:.3f}",
                                 "-map", f"0:{v['index']}", "-c:v", "libx264", "-qp", "0",
                                 "-preset", "ultrafast", "-pix_fmt", "yuv420p", "-an", ref])
            if rc != 0:
                raise Failure("couldn't read a sample of the video: " + err.strip()[-200:])
            ceiling = compare(ref, 0.0, ref, 0.0, secs, self.size, self.metric) if self.metric == "vmaf" else 1.0
            return ref, ceiling or 100.0
        cuts = in_parallel(cut, range(len(self.windows)))
        self.refs = [r for r, _ in cuts]
        self.ceilings = [c for _, c in cuts]

    def loss(self, k, dist, dist_t=0.0, shift=0):
        """How far below a perfect copy `dist` is on sample k (0.04 = 4% worse)."""
        secs = self.windows[k][1]
        s = compare(dist, dist_t, self.refs[k], 0.0, secs, self.size, self.metric, shift)
        if s is None:
            return None
        return max(0.0, 1 - s / self.ceilings[k])

    def check(self, enc_path, rep, slack=VERIFY_SLACK):
        """Compare the finished encode with the samples. Returns (match, ok)."""
        _, worst = limits(self.metric, self.strict)
        rep.progress(0.1, f"{len(self.windows)} samples")

        def one(k):
            t = self.windows[k][0]
            # Seeking the full encode can land a frame away from where the sample was cut.
            found = [self.loss(k, enc_path, t)]
            if found[0] is None or found[0] > worst:
                found += [self.loss(k, enc_path, t, shift) for shift in (1, -1)]
            found = [x for x in found if x is not None]
            return min(found) if found else None
        losses = [x for x in in_parallel(one, range(len(self.windows))) if x is not None]
        if not losses:
            return None, True
        return 1 - sum(losses) / len(losses), passes(losses, self.metric, slack, self.strict)


# ------------------------------------------------------------------ writing parts

def write_single(info, dst, audio_action, rep):
    cmd = ["ffmpeg", "-y", "-i", info["path"]] + stream_maps(info) + ["-c:v", "copy"] + vtag_args(info) + \
          audio_args(info, audio_action) + ["-movflags", "+faststart", "-f", "mp4", dst]
    run_ffmpeg(cmd, info["duration"], rep)


def temp_parts(outdir):
    rx = re.compile(r"^\.splitting_(\d{3})\.mp4$")
    names = sorted((f for f in os.listdir(outdir) if rx.match(f)), key=lambda f: int(rx.match(f).group(1)))
    return [os.path.join(outdir, f) for f in names]


def split_exact(info, outdir, scan, plan, audio_action, rep):
    """No overlap: one pass with the segment muxer, cutting by frame number
    (exact, and immune to the start-time offsets some files have)."""
    pattern = os.path.join(outdir.replace("%", "%%"), ".splitting_%03d.mp4")
    cuts = [end for _, end in plan[:-1]]
    total = len(plan)
    frames = ",".join(str(scan.kf_frames[j]) for j in cuts)
    cut_times = [scan.keyframes[j] - info["start"] for j in cuts]
    cmd = ["ffmpeg", "-y", "-i", info["path"]] + stream_maps(info) + ["-c:v", "copy"] + vtag_args(info) + \
          audio_args(info, audio_action) + [
        "-f", "segment", "-segment_format", "mp4",
        "-segment_format_options", "movflags=+faststart",
        "-segment_frames", frames,
        "-segment_start_number", "1", "-reset_timestamps", "1", pattern]
    run_ffmpeg(cmd, info["duration"], rep,
               lambda t: f"part {min(total, bisect.bisect_right(cut_times, t) + 1)} of {total}")
    return temp_parts(outdir)


def split_overlap(info, outdir, scan, plan, audio_action, rep):
    """Overlap: cut the video into exact pieces at every boundary any part
    needs (MPEG-TS, original timestamps kept), then join consecutive pieces
    into each part. Joining TS pieces is lossless and seamless."""
    bounds = sorted({s for s, _ in plan if s > 0} | {e for _, e in plan if e is not None})
    seg_pattern = os.path.join(outdir.replace("%", "%%"), ".ovl_%03d.ts")
    frames = ",".join(str(scan.kf_frames[j]) for j in bounds)
    total = len(plan)
    lo, hi = rep.lo, rep.hi
    mid = lo + (hi - lo) * 0.5
    rep.lo, rep.hi = lo, mid
    cmd = ["ffmpeg", "-y", "-i", info["path"]] + stream_maps(info) + ["-c:v", "copy"] + vtag_args(info) + \
          audio_args(info, audio_action) + [
        "-f", "segment", "-segment_format", "mpegts", "-segment_frames", frames,
        "-segment_start_number", "0", seg_pattern]
    run_ffmpeg(cmd, info["duration"], rep, lambda t: "cutting")
    pieces = sorted(f for f in os.listdir(outdir) if re.match(r"^\.ovl_\d{3}\.ts$", f))
    pieces = [os.path.join(outdir, f) for f in pieces]
    if len(pieces) != len(bounds) + 1:
        raise Failure(f"cutting went wrong (expected {len(bounds) + 1} pieces, got {len(pieces)}).")
    # piece k covers keyframe positions [edges[k], edges[k+1])
    edges = [0] + bounds
    rep.lo, rep.hi = mid, hi
    out = []
    for i, (s, e) in enumerate(plan, 1):
        first = edges.index(s)
        last = len(pieces) - 1 if e is None else edges.index(e) - 1
        dst = os.path.join(outdir, f".splitting_{i:03d}.mp4")
        span_start = scan.keyframes[s] - info["start"]
        span_end = (scan.keyframes[e] - info["start"]) if e is not None else info["duration"]
        cmd = ["ffmpeg", "-y", "-i", "concat:" + "|".join(os.path.basename(x) for x in pieces[first:last + 1]),
               "-map", "0", "-c", "copy"] + vtag_args(info) + ["-avoid_negative_ts", "make_zero",
               "-movflags", "+faststart", "-f", "mp4", dst]
        rep.label = f"Splitting into {total} parts with overlap - part {i} of {total}"
        run_ffmpeg(cmd, max(1e-3, span_end - span_start), _Sub(rep, (i - 1) / total, i / total), cwd=outdir)
        out.append(dst)
        # pieces before the next part's start are no longer needed: free the space now
        if i < total:
            keep_from = edges.index(plan[i][0])
            for p in pieces[:keep_from]:
                if os.path.exists(p):
                    os.remove(p)
    for p in pieces:
        if os.path.exists(p):
            os.remove(p)
    return out


class _Sub(Reporter):
    """Maps a sub-task's 0..1 progress into a slice of a parent reporter."""

    def __init__(self, parent, a, b):
        super().__init__()
        self.parent, self.a, self.b = parent, a, b

    def progress(self, frac, detail="", force=False):
        self.parent.progress(self.a + (self.b - self.a) * max(0.0, min(1.0, frac)), "", force)

    def poll(self):
        self.parent.poll()


def remove_old_outputs(outdir, stem):
    rx = re.compile(re.escape(stem) + r"(_part\d+of\d+|_discord)\.mp4$")
    for f in os.listdir(outdir):
        full = os.path.join(outdir, f)
        if rx.match(f):
            os.remove(full)
        elif BATCH_DIR_RX.match(f) and os.path.isdir(full):
            for g in os.listdir(full):
                if rx.match(g) or g == ".DS_Store":
                    os.remove(os.path.join(full, g))
            try:
                os.rmdir(full)
            except OSError:
                pass


def make_batches(outdir, finals, batch):
    if batch <= 0 or len(finals) <= batch:
        return finals
    width = max(2, len(str(len(finals))))
    moved = []
    for b in range(0, len(finals), batch):
        group = finals[b:b + batch]
        name = f"Message {b // batch + 1} (parts {b + 1:0{width}d}-{b + len(group):0{width}d})"
        folder = os.path.join(outdir, name)
        os.makedirs(folder, exist_ok=True)
        for p in group:
            dst = os.path.join(folder, os.path.basename(p))
            os.replace(p, dst)
            moved.append(dst)
    return moved


# ------------------------------------------------------------------ the pipeline

def process(src, st, rep, outdir=None, height=None):
    """Split one video according to settings `st`. Returns a result dict."""
    global REP
    REP = rep
    src = os.path.abspath(src)
    if not os.path.isfile(src):
        raise Failure(f"'{os.path.basename(src)}' isn't there anymore. Was it moved or deleted?")
    info = probe(src)
    if not info["video"]:
        raise Failure("this file doesn't have a video track.")
    if info["duration"] <= 0:
        raise Failure("couldn't read the video's length.")
    video_ok, audio_action, is_mp4, reason = assess(info, st["modern"])
    limit = parse_size(st["max_size"])
    smaller, fast = st["quality"] == "smaller", st["fast"]
    overlap, batch = st["overlap"], st["batch"]
    stem = os.path.splitext(os.path.basename(src))[0]
    outdir = os.path.abspath(outdir or os.path.join(os.path.dirname(src), f"{stem}_parts"))

    rep.say(f"{os.path.basename(src)}: {human(info['size'])}, {hms(info['duration'])}, "
            f"{codec_name(info['video']['codec_name'])}. Limit {human(limit)} per part.")
    if video_ok and not smaller and audio_action != "aac" and is_mp4 and info["size"] <= limit:
        return {"nothing": True, "message": f"Already under {human(limit)} and plays in Discord. "
                                            "Upload it as it is."}

    reencode = (not video_ok) or smaller
    JOB.outdir = outdir
    if not os.path.isdir(outdir):
        os.makedirs(outdir)
        JOB.created_outdir = True
    need = info["size"] * (1.1 + (1.0 if reencode else 0.0))
    free = shutil.disk_usage(outdir).free
    if free < need:
        raise Failure(f"not enough free disk space. This needs about {human(need)} and the drive "
                      f"has {human(free)} free.")

    work, notes, quality = info, [], None
    if reencode:
        # With "my server plays H.265 & AV1" on, shrink to AV1: about a third smaller.
        enc = Encoder(fast, info, rep, av1=st["modern"])
        if enc.note:
            notes.append(enc.note)
        verb = "Converting for Discord" if not video_ok else "Shrinking"
        if not video_ok:
            rep.say(f"Converting first, because {reason}.")
        tmps = [os.path.join(outdir, ".encoding.mp4"), os.path.join(outdir, ".encoding_retry.mp4")]
        JOB.temp_files.extend(tmps)
        kept = estimate_bytes(info, audio_action) if info["audio"] is not None else info["size"]
        if smaller:
            audio_action = shrink_audio_action(info, audio_action)
        rep.stage("Taking samples of the video", 0, 2)
        samples = Samples(info, outdir, rep, strict=not smaller)
        enc_lo = 2
        if samples.windows:
            rep.stage("Finding the smallest setting that still looks right", 2, 12)
            enc.tune(info, samples, height, rep, keep_ratio=KEEP_RATIO if video_ok else None)
            rep.say(f"Using {enc.describe()}.")
            enc_lo = 12
        ratio = enc.predicted_ratio(samples) if samples.windows else None
        skip_encode = video_ok and ratio is not None and ratio >= KEEP_RATIO
        best = None          # (path, quality score) of the encode we'll use
        for attempt in ((1, 2) if not skip_encode else ()):
            out = tmps[attempt - 1]
            rep.stage(verb + (" (again, at higher quality)" if attempt == 2 else ""), enc_lo, 70)
            enc.encode(info, out, audio_action, height, rep)
            if video_ok and os.path.getsize(out) >= kept * 0.95:
                break        # not smaller than the original: no point keeping this one
            rep.stage("Checking quality", 70, 76)
            score, ok = samples.check(out, rep)
            best = (out, score)
            if ok:
                break
            if attempt == 2 or not enc.raise_quality(info):
                notes.append("The quality check came in slightly under target.")
                break
            rep.say(f"Quality check came in at {score * 100:.1f}%, re-encoding at higher quality.")
        if best is None:
            notes.append("Re-encoding didn't make it smaller, so the original quality was kept.")
        else:
            if best[0] == tmps[0] and attempt == 2:
                notes.append("The quality check came in slightly under target (a higher-quality "
                             "encode wasn't smaller than the original).")
            work, quality = probe(best[0]), best[1]
            audio_action = "copy" if work["audio"] is not None else None
        for t in tmps:
            if (best is None or t != best[0]) and os.path.exists(t):
                os.remove(t)
        scan_range, split_lo = (76, 80), 80
    else:
        scan_range, split_lo = (0, 12), 12

    if work is info and overlap <= 0 and hevc_open_gop(info):
        notes.append("This H.265 file is encoded in a way that makes each part skip a split second "
                     "at its start. Turning on overlap covers it.")

    rep.stage("Finding cut points", *scan_range)
    scan = scan_packets(work, rep, audio_action)
    budget = limit * HEADROOM

    if scan.total <= budget:
        rep.stage("Writing the file", split_lo, 100)
        tmp_single = os.path.join(outdir, ".single.mp4")
        JOB.temp_files.append(tmp_single)
        write_single(work, tmp_single, audio_action, rep)
        if os.path.getsize(tmp_single) > limit:
            raise Failure("the converted file came out over the limit.")
        remove_old_outputs(outdir, stem)
        final = os.path.join(outdir, f"{stem}_discord.mp4")
        os.replace(tmp_single, final)
        JOB.cleanup()
        return {"outdir": outdir, "parts": [final], "quality": quality, "notes": notes}

    if scan.largest_gap() > budget:
        hint = ("Try a bigger part size." if work is not info or smaller
                else "Try the 'Smaller files' quality setting.")
        raise Failure(f"this video's keyframes are too far apart to cut it under {human(limit)}. {hint}")

    for attempt in range(1, MAX_ATTEMPTS + 1):
        plan = plan_parts(scan, budget, overlap)
        label = f"Splitting into {len(plan)} parts" + (" with overlap" if overlap > 0 else "")
        if attempt > 1:
            label += f" (try {attempt})"
        rep.stage(label, split_lo, 100)
        remove_temps(outdir, only_split=True)   # leftovers from a previous try (not the encoded source!)
        if overlap > 0:
            parts = split_overlap(work, outdir, scan, plan, audio_action, rep)
        else:
            parts = split_exact(work, outdir, scan, plan, audio_action, rep)
        if len(parts) != len(plan):
            rep.say(f"Note: planned {len(plan)} parts but got {len(parts)}.")
        too_big = [p for p in parts if os.path.getsize(p) > limit]
        if not too_big:
            break
        biggest = max(os.path.getsize(p) for p in too_big)
        rep.say(f"{len(too_big)} part(s) came out over the limit; re-planning with more headroom.")
        budget *= min(0.92, limit / biggest * 0.97)
    else:
        raise Failure("couldn't get every part under the limit. Try the 'Smaller files' setting.")

    remove_old_outputs(outdir, stem)
    width = max(2, len(str(len(parts))))
    finals = []
    for i, p in enumerate(parts, 1):
        final = os.path.join(outdir, f"{stem}_part{i:0{width}d}of{len(parts)}.mp4")
        os.replace(p, final)
        finals.append(final)
    finals = make_batches(outdir, finals, batch)
    JOB.cleanup()
    return {"outdir": outdir, "parts": finals, "quality": quality, "notes": notes}


# ------------------------------------------------------------------ check (used before queueing)

def analyze(path, st):
    """What would happen to this file with these settings."""
    src = os.path.abspath(path)
    item = {"path": src, "name": os.path.basename(src)}
    try:
        if not os.path.isfile(src):
            raise Failure("this file doesn't exist.")
        info = probe(src)
        if not info["video"]:
            raise Failure("this file doesn't have a video track.")
    except Failure as e:
        item["error"] = cap(e)
        return item
    video_ok, audio_action, is_mp4, reason = assess(info, st["modern"])
    v = info["video"]
    limit = parse_size(st["max_size"])
    if not video_ok:
        plays = "convert"
    elif audio_action == "aac" or not is_mp4:
        plays = "remux"
    else:
        plays = "yes"
    smaller = st["quality"] == "smaller"
    item.update({
        "size": info["size"], "size_text": human(info["size"]),
        "duration": info["duration"], "length_text": hms(info["duration"]),
        "video_text": f"{codec_name(v['codec_name'])} {v.get('width')}x{v.get('height')}",
        "plays": plays, "reason": reason,
        "parts": max(1, math.ceil(estimate_bytes(info, audio_action) / (limit * HEADROOM))),
        "limit_text": human(limit),
        "skip": plays == "yes" and not smaller and info["size"] <= limit,
        "slow": plays == "convert" or smaller,
    })
    return item


# ------------------------------------------------------------------ the queue

def job_dir(jid):
    if not re.fullmatch(r"[\w.-]+", jid or ""):
        raise Failure(f"bad job id '{jid}'")
    return os.path.join(QUEUE_DIR, jid)


def load_jobs():
    jobs = []
    if not os.path.isdir(QUEUE_DIR):
        return jobs
    for jid in os.listdir(QUEUE_DIR):
        d = os.path.join(QUEUE_DIR, jid)
        req = read_json(os.path.join(d, "request.json"))
        if not os.path.isdir(d) or not req:
            continue
        state = read_json(os.path.join(d, "state.json"), {}) or {}
        jobs.append({"id": jid, "dir": d, "req": req, "state": state,
                     "status": state.get("status", "queued")})
    return jobs


def queued_sorted(jobs):
    q = [j for j in jobs if j["status"] == "queued"]
    q.sort(key=lambda j: (j["req"].get("order", 0), j["req"].get("added_at", 0)))
    return q


class WorkerLock:
    def __init__(self):
        os.makedirs(QUEUE_DIR, exist_ok=True)
        self.fd = open(os.path.join(QUEUE_DIR, "worker.lock"), "w")

    def try_acquire(self):
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except OSError:
            return False

    def release(self):
        try:
            fcntl.flock(self.fd, fcntl.LOCK_UN)
        except OSError:
            pass
        self.fd.close()


def worker_running():
    lock = WorkerLock()
    free = lock.try_acquire()
    lock.release()
    return not free


def spawn_worker():
    os.makedirs(SUPPORT_DIR, exist_ok=True)
    log_path = os.path.join(SUPPORT_DIR, "worker.log")
    try:
        if os.path.getsize(log_path) > 2_000_000:
            os.remove(log_path)
    except OSError:
        pass
    log = open(log_path, "a")
    subprocess.Popen([sys.executable, os.path.abspath(__file__), "worker"],
                     stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                     start_new_session=True, close_fds=True, cwd=SUPPORT_DIR)


def notify(message, title="Discord Splitter"):
    if sys.platform != "darwin":
        return
    esc = lambda s: str(s).replace("\\", "\\\\").replace('"', '\\"')
    try:
        subprocess.run(["osascript", "-e", f'display notification "{esc(message)}" with title "{esc(title)}"'],
                       capture_output=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        pass


def summary_text(res):
    if res.get("nothing"):
        return res["message"]
    n = len(res["parts"])
    text = "Ready to upload as one file" if n == 1 else f"{n} parts ready"
    if res.get("quality") is not None:
        text += f" - quality check {res['quality'] * 100:.1f}% match"
    return text


def run_job(job, worker_state):
    global JOB
    JOB = Job()
    d, req = job["dir"], job["req"]
    name = req.get("name") or os.path.basename(req["input"])
    state = {"status": "running", "progress": 0.0, "message": "Starting", "started_at": time.time(),
             "notes": []}
    write_json(os.path.join(d, "state.json"), state)
    rep = JobReporter(d, state)
    try:
        st = job_settings(req.get("settings"))
        res = process(req["input"], st, rep)
        state.update({"status": "done", "progress": 100.0, "eta": None,
                      "message": summary_text(res), "nothing": bool(res.get("nothing")),
                      "outdir": res.get("outdir"), "parts": res.get("parts", []),
                      "part_count": len(res.get("parts", [])), "quality": res.get("quality")})
        state["notes"] = [n for n in res.get("notes", [])]
        notify(f"{name}: {summary_text(res)}")
    except Cancelled:
        JOB.cleanup()
        if worker_state["stop"]:
            state.update({"status": "queued", "message": "Interrupted - will restart", "progress": 0.0,
                          "eta": None})
        else:
            state.update({"status": "cancelled", "message": "Cancelled", "eta": None})
    except Failure as e:
        JOB.cleanup()
        state.update({"status": "failed", "error": cap(e), "message": "Failed", "eta": None})
        notify(f"{name} failed: {cap(e)}")
    except Exception as e:   # keep the queue going no matter what
        JOB.cleanup()
        traceback.print_exc()
        state.update({"status": "failed", "error": f"Unexpected problem: {e}", "message": "Failed",
                      "eta": None})
    finally:
        try:
            os.remove(os.path.join(d, "cancel"))
        except OSError:
            pass
        if state["status"] != "queued":
            state["finished_at"] = time.time()
        write_json(os.path.join(d, "state.json"), state)
    return state["status"]


def cmd_worker():
    lock = WorkerLock()
    if not lock.try_acquire():
        return 0          # another worker is already running
    find_tools()
    worker_state = {"stop": False}

    def stop(signum, frame):
        worker_state["stop"] = True
        JOB.cancel()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    if sys.platform == "darwin" and shutil.which("caffeinate"):
        # keep the Mac from idle-sleeping while the queue runs; ends with this process
        subprocess.Popen(["caffeinate", "-i", "-w", str(os.getpid())],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # anything still marked running was interrupted (crash, restart): run it again
    for j in load_jobs():
        if j["status"] == "running":
            j["state"].update({"status": "queued", "message": "Interrupted - will restart", "progress": 0.0})
            write_json(os.path.join(j["dir"], "state.json"), j["state"])
            out = j["state"].get("outdir")
            if out and os.path.isdir(out):
                remove_temps(out)
    finished = 0
    while not worker_state["stop"]:
        jobs = load_jobs()
        q = queued_sorted(jobs)
        if not q:
            break
        job = q[0]
        if os.path.exists(os.path.join(job["dir"], "cancel")):
            job["state"].update({"status": "cancelled", "message": "Cancelled", "finished_at": time.time()})
            write_json(os.path.join(job["dir"], "state.json"), job["state"])
            os.remove(os.path.join(job["dir"], "cancel"))
            continue
        if run_job(job, worker_state) in ("done", "failed"):
            finished += 1
    if finished > 1 and not worker_state["stop"]:
        notify(f"Queue finished: {finished} videos processed.")
    lock.release()
    return 0


def cmd_kick():
    if any(j["status"] in ("queued", "running") for j in load_jobs()) and not worker_running():
        spawn_worker()
        return "started"
    return "idle"


def cmd_enqueue(files, raw_settings):
    st = job_settings(raw_settings)
    gs = global_settings()
    os.makedirs(QUEUE_DIR, exist_ok=True)
    jobs = load_jobs()
    active_inputs = {j["req"].get("input") for j in jobs if j["status"] in ("queued", "running")}
    queue = queued_sorted(jobs)
    orders = [(j["req"].get("order", 0), bool(j["req"].get("slow"))) for j in queue]
    added, skipped = [], []
    for f in files:
        item = analyze(f, st)
        if item.get("error") or item.get("skip"):
            skipped.append({"name": item["name"], "why": item.get("error") or "already fine"})
            continue
        if item["path"] in active_inputs:
            skipped.append({"name": item["name"], "why": "already in the queue"})
            continue
        slow = item["slow"]
        if not orders:
            order = 1.0
        elif gs.get("quick_first", True) and not slow and any(s for _, s in orders):
            first_slow = min(o for o, s in orders if s)
            before = [o for o, _ in orders if o < first_slow]
            order = ((max(before) if before else first_slow - 1.0) + first_slow) / 2.0
        else:
            order = max(o for o, _ in orders) + 1.0
        orders.append((order, slow))
        jid = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6]
        d = os.path.join(QUEUE_DIR, jid)
        os.makedirs(d)
        write_json(os.path.join(d, "request.json"), {
            "id": jid, "input": item["path"], "name": item["name"], "added_at": time.time(),
            "order": order, "slow": slow, "settings": st, "check": item})
        write_json(os.path.join(d, "state.json"), {"status": "queued", "message": "Waiting"})
        active_inputs.add(item["path"])
        added.append(jid)
    if added and not worker_running():
        spawn_worker()
    return {"added": added, "skipped": skipped}


def update_request(jid, fn):
    d = job_dir(jid)
    req = read_json(os.path.join(d, "request.json"))
    if req is None:
        raise Failure("that job doesn't exist anymore.")
    fn(req)
    write_json(os.path.join(d, "request.json"), req)


def cmd_control(action, jid, arg=None):
    d = job_dir(jid)
    if not os.path.isdir(d):
        raise Failure("that job doesn't exist anymore.")
    state = read_json(os.path.join(d, "state.json"), {}) or {}
    status = state.get("status", "queued")
    if action == "cancel":
        if status not in ("queued", "running"):
            return "nothing to cancel"
        # the cancel file stops it even if the worker picks it up at this very moment
        open(os.path.join(d, "cancel"), "w").close()
        lock = WorkerLock()
        idle = lock.try_acquire()
        if idle:
            lock.release()
        if status == "queued" or idle:
            state.update({"status": "cancelled", "message": "Cancelled", "finished_at": time.time()})
            write_json(os.path.join(d, "state.json"), state)
            return "cancelled"
        return "cancelling"
    if action == "remove":
        if status == "running":
            raise Failure("it's running. Cancel it first.")
        shutil.rmtree(d, ignore_errors=True)
        return "removed"
    if action == "retry":
        if status not in ("failed", "cancelled"):
            return "nothing to retry"
        jobs = load_jobs()
        top = max([j["req"].get("order", 0) for j in queued_sorted(jobs)] + [0])
        update_request(jid, lambda r: r.update({"order": top + 1.0}))
        try:
            os.remove(os.path.join(d, "cancel"))
        except OSError:
            pass
        write_json(os.path.join(d, "state.json"), {"status": "queued", "message": "Waiting"})
        if not worker_running():
            spawn_worker()
        return "queued"
    if action == "move":
        q = queued_sorted(load_jobs())
        ids = [j["id"] for j in q]
        if jid not in ids:
            return "not waiting"
        i = ids.index(jid)
        k = i - 1 if arg == "up" else i + 1
        if k < 0 or k >= len(q):
            return "already there"
        a, b = q[i]["req"].get("order", 0), q[k]["req"].get("order", 0)
        if a == b:
            b = a - 0.5 if arg == "up" else a + 0.5
        update_request(q[i]["id"], lambda r: r.update({"order": b}))
        update_request(q[k]["id"], lambda r: r.update({"order": a}))
        return "moved"
    if action == "posted":
        update_request(jid, lambda r: r.update({"posted_at": time.time()}))
        return "posted"
    if action == "unposted":
        update_request(jid, lambda r: r.pop("posted_at", None))
        return "unposted"
    if action == "mark-cleaned":
        state["cleaned_at"] = time.time()
        write_json(os.path.join(d, "state.json"), state)
        return "cleaned"
    raise Failure(f"unknown action {action}")


def cmd_cleanup_due():
    """Jobs posted at least CLEANUP_AFTER ago whose parts should go to the Trash.
    The app does the trashing (macOS's proper Trash API)."""
    if not global_settings().get("cleanup", True):
        return []
    now, due = time.time(), []
    for j in load_jobs():
        posted, st = j["req"].get("posted_at"), j["state"]
        if j["status"] != "done" or not posted or st.get("cleaned_at") or now - posted < CLEANUP_AFTER:
            continue
        outdir, parts = st.get("outdir"), [p for p in st.get("parts", []) if os.path.exists(p)]
        items = []
        if outdir and os.path.isdir(outdir):
            ours = set(parts)
            entries = [os.path.join(outdir, e) for e in os.listdir(outdir)]
            batch_dirs = [e for e in entries if os.path.isdir(e) and BATCH_DIR_RX.match(os.path.basename(e))]
            only_ours = all(e in ours or e in batch_dirs or os.path.basename(e) == ".DS_Store" for e in entries)
            loose = [p for p in parts if os.path.dirname(p) == outdir]
            whole_batches = [b for b in batch_dirs
                             if all(os.path.join(b, x) in ours or x == ".DS_Store" for x in os.listdir(b))]
            items = [outdir] if only_ours else loose + whole_batches
        due.append({"id": j["id"], "name": j["req"].get("name"), "items": items})
    return due


def cmd_status():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)   # quiet when piped into head/grep
    for j in sorted(load_jobs(), key=lambda j: j["req"].get("added_at", 0)):
        st = j["state"]
        print(f"{j['id']}  {j['status']:<9}  {st.get('progress', 0):5.1f}%  "
              f"order={j['req'].get('order')}  {j['req'].get('name')}  | {st.get('message', '')} {st.get('error', '')}")


# ------------------------------------------------------------------ command line

SUBCOMMANDS = {"check", "enqueue", "worker", "kick", "status", "cancel", "remove", "retry",
               "posted", "unposted", "mark-cleaned", "move", "cleanup-due", "version"}


def main_subcommand(argv):
    ap = argparse.ArgumentParser(prog="split_video.py")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("check", "enqueue"):
        p = sub.add_parser(name)
        p.add_argument("--settings", default="{}", help="JSON job settings")
        p.add_argument("files", nargs="+")
    for name in ("worker", "kick", "status", "cleanup-due", "version"):
        sub.add_parser(name)
    for name in ("cancel", "remove", "retry", "posted", "unposted", "mark-cleaned"):
        sub.add_parser(name).add_argument("id")
    p = sub.add_parser("move")
    p.add_argument("id")
    p.add_argument("direction", choices=["up", "down"])
    args = ap.parse_args(argv)

    def out(obj):
        print(json.dumps(obj))

    try:
        if args.cmd == "version":
            print(VERSION)
        elif args.cmd == "check":
            find_tools()
            st = job_settings(json.loads(args.settings))
            out([analyze(f, st) for f in args.files])
        elif args.cmd == "enqueue":
            find_tools()
            out(cmd_enqueue(args.files, json.loads(args.settings)))
        elif args.cmd == "worker":
            return cmd_worker()
        elif args.cmd == "kick":
            out({"worker": cmd_kick()})
        elif args.cmd == "status":
            cmd_status()
        elif args.cmd == "cleanup-due":
            out(cmd_cleanup_due())
        elif args.cmd == "move":
            out({"result": cmd_control("move", args.id, args.direction)})
        else:
            out({"result": cmd_control(args.cmd, args.id)})
    except (Failure, argparse.ArgumentTypeError, ValueError) as e:
        out({"error": cap(e)})
        return 1
    return 0


def main_direct():
    ap = argparse.ArgumentParser(
        description="Split a video into Discord-playable parts that each fit under a size limit.")
    ap.add_argument("input", help="video file")
    ap.add_argument("--max-size", default="1G", help="largest allowed part, e.g. 1G, 500M (default: 1G)")
    ap.add_argument("--outdir", help="where to put the parts (default: <name>_parts next to the video)")
    ap.add_argument("--smaller", action="store_true", help="re-encode at a quality you shouldn't notice (slow)")
    ap.add_argument("--fast", action="store_true", help="when re-encoding, use quicker encoder settings (~2x faster, ~12%% bigger)")
    ap.add_argument("--allow-hevc", action="store_true",
                    help="treat H.265/AV1 as playable (no converting) and shrink to AV1")
    ap.add_argument("--overlap", type=float, default=0, help="seconds each part repeats from the previous one")
    ap.add_argument("--batch", type=int, default=0, help="put parts in folders of this many (Discord: 10)")
    ap.add_argument("--height", type=int, help="when re-encoding, shrink to this height if taller")
    ap.add_argument("--check", action="store_true", help="only report what would happen")
    ap.add_argument("--progress-file", help=argparse.SUPPRESS)   # used by the AppleScript app
    args = ap.parse_args()
    try:
        parse_size(args.max_size)
    except argparse.ArgumentTypeError as e:
        ap.error(str(e))
    st = job_settings({"max_size": args.max_size, "quality": "smaller" if args.smaller else "original",
                       "fast": args.fast, "modern": args.allow_hevc, "overlap": args.overlap,
                       "batch": args.batch})

    if args.check:
        try:
            find_tools()
        except Failure as e:
            print(f"error={cap(e)}")
            return 1
        item = analyze(args.input, st)
        if item.get("error"):
            print(f"error={item['error']}")
            return 1
        for k in ("name", "size_text", "length_text", "video_text", "plays", "reason", "parts", "limit_text"):
            print(f"{k.replace('_text', '')}={clean(item.get(k, ''))}")
        print(f"fits={'yes' if item['skip'] else 'no'}")
        return 0

    rep = FileReporter(args.progress_file) if args.progress_file else ConsoleReporter()
    signal.signal(signal.SIGTERM, JOB.on_signal)
    signal.signal(signal.SIGINT, JOB.on_signal)
    try:
        find_tools()
        res = process(args.input, st, rep, args.outdir, args.height)
        if res.get("nothing"):
            rep.line(f"NOTHING\t{res['message']}") if args.progress_file else rep.say(res["message"])
            return 0
        for n in res.get("notes", []):
            rep.say(n)
        if args.progress_file:
            rep.line(f"DONE\t{res['outdir']}\t{len(res['parts'])}\t{res['parts'][0]}")
        else:
            rep.say(f"\nDone. {summary_text(res)} in {res['outdir']}")
            for p in res["parts"]:
                print(f"  {os.path.relpath(p, res['outdir'])}   {human(os.path.getsize(p)):>10}")
        return 0
    except Cancelled:
        JOB.cleanup()
        rep.line("CANCELLED") if args.progress_file else rep.say("\nStopped.")
        return 130
    except Failure as e:
        JOB.cleanup()
        rep.line(f"ERROR\t{clean(cap(e))}") if args.progress_file else rep.say(f"\nError: {cap(e)}")
        return 1


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in SUBCOMMANDS:
        sys.exit(main_subcommand(sys.argv[1:]))
    sys.exit(main_direct())
