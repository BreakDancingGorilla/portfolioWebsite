// Discord Splitter - native Mac front end for split_video.py.
// Built on each Mac by Install.command (swiftc, no Xcode project needed).

import SwiftUI
import AppKit
import UniformTypeIdentifiers

// MARK: - Locations

enum Paths {
    static let appName: String = (Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String) ?? "Discord Splitter"
    static let supportName: String = (Bundle.main.object(forInfoDictionaryKey: "DSSupportDirName") as? String) ?? "Discord Splitter"
    static var supportDir: URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Application Support", isDirectory: true)
            .appendingPathComponent(supportName, isDirectory: true)
    }
    static var queueDir: URL { supportDir.appendingPathComponent("queue", isDirectory: true) }
    static var engine: URL { supportDir.appendingPathComponent("split_video.py") }
    static var settingsFile: URL { supportDir.appendingPathComponent("settings.json") }
    static var configFile: URL { supportDir.appendingPathComponent("config.json") }
    static var appLog: URL { supportDir.appendingPathComponent("app.log") }
}

// MARK: - Calling the engine

struct EngineResult {
    let status: Int32
    let output: String

    var json: Any? { try? JSONSerialization.jsonObject(with: Data(output.utf8)) }

    var errorMessage: String? {
        if let obj = json as? [String: Any], let err = obj["error"] as? String { return err }
        return nil
    }
}

enum Engine {
    static func python() -> String {
        if let data = try? Data(contentsOf: Paths.configFile),
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let py = obj["python"] as? String, !py.isEmpty {
            return py
        }
        return "/usr/bin/python3"
    }

    static func logHandle() -> FileHandle {
        let fm = FileManager.default
        try? fm.createDirectory(at: Paths.supportDir, withIntermediateDirectories: true)
        if !fm.fileExists(atPath: Paths.appLog.path) {
            fm.createFile(atPath: Paths.appLog.path, contents: nil)
        }
        guard let handle = try? FileHandle(forWritingTo: Paths.appLog) else { return FileHandle.nullDevice }
        _ = handle.seekToEndOfFile()
        return handle
    }

    /// Runs the engine off the main thread and calls back on the main thread.
    static func run(_ args: [String], completion: @escaping (EngineResult) -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            let result = runSync(args)
            DispatchQueue.main.async {
                completion(result)
            }
        }
    }

    static func runSync(_ args: [String]) -> EngineResult {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: python())
        process.arguments = [Paths.engine.path] + args
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "/opt/homebrew/bin:/usr/local/bin:" + (env["PATH"] ?? "/usr/bin:/bin")
        env["LC_ALL"] = "en_US.UTF-8"
        process.environment = env
        let outPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = logHandle()      // tracebacks go to app.log, not into our pipe
        process.standardInput = FileHandle.nullDevice
        do {
            try process.run()
        } catch {
            return EngineResult(status: -1, output: "{\"error\": \"Couldn't start Python (\(python())). Run Install.command again.\"}")
        }
        let data = outPipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        return EngineResult(status: process.terminationStatus, output: String(decoding: data, as: UTF8.self))
    }
}

// MARK: - Data from the queue folder

struct JobSettings: Codable {
    var max_size: String?
    var quality: String?
    var fast: Bool?
    var modern: Bool?
    var overlap: Double?
    var batch: Int?
}

struct JobRequest: Codable {
    var id: String
    var input: String
    var name: String?
    var added_at: Double?
    var order: Double?
    var slow: Bool?
    var posted_at: Double?
    var settings: JobSettings?
}

struct JobState: Codable {
    var status: String?
    var progress: Double?
    var message: String?
    var eta: Double?
    var outdir: String?
    var parts: [String]?
    var part_count: Int?
    var quality: Double?
    var notes: [String]?
    var error: String?
    var nothing: Bool?
    var started_at: Double?
    var finished_at: Double?
    var cleaned_at: Double?
}

struct QueueJob: Identifiable {
    let id: String
    let request: JobRequest
    let state: JobState
    let cancelRequested: Bool

    var status: String { state.status ?? "queued" }
    var name: String { request.name ?? (request.input as NSString).lastPathComponent }
    var isPosted: Bool { request.posted_at != nil }
    var isCleaned: Bool { state.cleaned_at != nil }
    var hasParts: Bool { (state.part_count ?? 0) > 0 && state.nothing != true }
}

struct AppSettings: Codable, Equatable {
    var max_size = "1G"
    var quality = "original"
    var fast = false
    var modern = false
    var overlap: Double = 3
    var batch = 10
    var quick_first = true
    var cleanup = true
    var channel = ""

    init() {}

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        let d = AppSettings()
        max_size = try c.decodeIfPresent(String.self, forKey: .max_size) ?? d.max_size
        quality = try c.decodeIfPresent(String.self, forKey: .quality) ?? d.quality
        fast = try c.decodeIfPresent(Bool.self, forKey: .fast) ?? d.fast
        modern = try c.decodeIfPresent(Bool.self, forKey: .modern) ?? d.modern
        overlap = try c.decodeIfPresent(Double.self, forKey: .overlap) ?? d.overlap
        batch = try c.decodeIfPresent(Int.self, forKey: .batch) ?? d.batch
        quick_first = try c.decodeIfPresent(Bool.self, forKey: .quick_first) ?? d.quick_first
        cleanup = try c.decodeIfPresent(Bool.self, forKey: .cleanup) ?? d.cleanup
        channel = try c.decodeIfPresent(String.self, forKey: .channel) ?? d.channel
    }

    static func label(for size: String) -> String {
        switch size.uppercased() {
        case "1G": return "1 GB"
        case "500M": return "500 MB"
        case "50M": return "50 MB"
        case "20M": return "20 MB"
        default: return size
        }
    }

    var limitLabel: String { AppSettings.label(for: max_size) }
}

struct CheckItem: Identifiable {
    let id = UUID()
    let path: String
    let name: String
    let error: String?
    let plays: String
    let reason: String
    let parts: Int
    let skip: Bool
    let slow: Bool
    let sizeText: String
    let lengthText: String
    let limitText: String

    init(dict: [String: Any]) {
        path = dict["path"] as? String ?? ""
        name = dict["name"] as? String ?? (path as NSString).lastPathComponent
        error = dict["error"] as? String
        plays = dict["plays"] as? String ?? ""
        reason = dict["reason"] as? String ?? ""
        parts = (dict["parts"] as? NSNumber)?.intValue ?? 0
        skip = dict["skip"] as? Bool ?? false
        slow = dict["slow"] as? Bool ?? false
        sizeText = dict["size_text"] as? String ?? ""
        lengthText = dict["length_text"] as? String ?? ""
        limitText = dict["limit_text"] as? String ?? ""
    }

    var addable: Bool { error == nil && !skip }
}

struct PendingAdd: Identifiable {
    let id = UUID()
    let items: [CheckItem]
}

struct AlertInfo: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

enum ActiveSheet: Identifiable {
    case settings
    case confirm(PendingAdd)

    var id: String {
        switch self {
        case .settings: return "settings"
        case .confirm(let pending): return pending.id.uuidString
        }
    }
}

final class URLCollector: @unchecked Sendable {
    private let lock = NSLock()
    private var collected: [URL] = []

    func add(_ url: URL) {
        lock.lock()
        collected.append(url)
        lock.unlock()
    }

    var urls: [URL] {
        lock.lock()
        defer { lock.unlock() }
        return collected
    }
}

func formatDuration(_ seconds: Double) -> String {
    let s = Int(seconds.rounded())
    if s < 60 { return "under a minute" }
    if s < 3600 { return "\(s / 60) min" }
    return "\(s / 3600) h \((s % 3600) / 60) min"
}

// MARK: - The model

final class QueueModel: ObservableObject {
    static let shared = QueueModel()

    @Published var jobs: [QueueJob] = []
    @Published var settings = AppSettings()
    @Published var sheet: ActiveSheet?
    @Published var checking = false
    @Published var alert: AlertInfo?
    @Published var engineInstalled = true

    private var timer: Timer?
    private var lastCleanup = Date.distantPast

    init() {
        loadSettings()
        refresh()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
        // after a restart or crash, pick the queue back up
        Engine.run(["kick"]) { _ in }
    }

    func tick() {
        refresh()
        if Date().timeIntervalSince(lastCleanup) > 3600 {
            runCleanup()
        }
    }

    // MARK: settings

    func loadSettings() {
        if let data = try? Data(contentsOf: Paths.settingsFile),
           let decoded = try? JSONDecoder().decode(AppSettings.self, from: data) {
            settings = decoded
        }
    }

    func saveSettings(_ new: AppSettings) {
        settings = new
        do {
            try FileManager.default.createDirectory(at: Paths.supportDir, withIntermediateDirectories: true)
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            try encoder.encode(new).write(to: Paths.settingsFile, options: .atomic)
        } catch {
            alert = AlertInfo(title: "Couldn't save settings", message: error.localizedDescription)
        }
    }

    func jobSettingsJSON() -> String {
        let dict: [String: Any] = [
            "max_size": settings.max_size,
            "quality": settings.quality,
            "fast": settings.fast,
            "modern": settings.modern,
            "overlap": settings.overlap,
            "batch": settings.batch,
        ]
        let data = (try? JSONSerialization.data(withJSONObject: dict)) ?? Data("{}".utf8)
        return String(decoding: data, as: UTF8.self)
    }

    var settingsSummary: String {
        var bits = ["parts under \(settings.limitLabel)"]
        if settings.quality == "smaller" {
            bits.append((settings.fast ? "fast shrink" : "shrink (best quality)") + (settings.modern ? " to AV1" : ""))
        } else {
            bits.append("original quality")
        }
        if settings.modern { bits.append("H.265 & AV1 allowed") }
        if settings.overlap > 0 { bits.append("\(Int(settings.overlap))s overlap") }
        if settings.batch > 0 { bits.append("folders of \(settings.batch)") }
        return bits.joined(separator: " • ")
    }

    // MARK: reading the queue

    func refresh() {
        let fm = FileManager.default
        engineInstalled = fm.fileExists(atPath: Paths.engine.path)
        guard let ids = try? fm.contentsOfDirectory(atPath: Paths.queueDir.path) else {
            if !jobs.isEmpty { jobs = [] }
            return
        }
        let decoder = JSONDecoder()
        var list: [QueueJob] = []
        for id in ids {
            let dir = Paths.queueDir.appendingPathComponent(id, isDirectory: true)
            guard let reqData = try? Data(contentsOf: dir.appendingPathComponent("request.json")),
                  let request = try? decoder.decode(JobRequest.self, from: reqData) else { continue }
            var state = JobState()
            if let stateData = try? Data(contentsOf: dir.appendingPathComponent("state.json")),
               let decoded = try? decoder.decode(JobState.self, from: stateData) {
                state = decoded
            }
            let cancel = fm.fileExists(atPath: dir.appendingPathComponent("cancel").path)
            list.append(QueueJob(id: request.id, request: request, state: state, cancelRequested: cancel))
        }
        list.sort(by: QueueModel.displayOrder)
        jobs = list
    }

    static func rank(_ job: QueueJob) -> Int {
        switch job.status {
        case "running": return 0
        case "queued": return 1
        case "failed": return 2
        case "cancelled": return 3
        default: return 4
        }
    }

    static func displayOrder(_ a: QueueJob, _ b: QueueJob) -> Bool {
        let ra = rank(a), rb = rank(b)
        if ra != rb { return ra < rb }
        if a.status == "queued" {
            let oa = a.request.order ?? 0, ob = b.request.order ?? 0
            if oa != ob { return oa < ob }
            return (a.request.added_at ?? 0) < (b.request.added_at ?? 0)
        }
        let ta = a.state.finished_at ?? a.request.added_at ?? 0
        let tb = b.state.finished_at ?? b.request.added_at ?? 0
        return ta > tb
    }

    var queuedJobs: [QueueJob] { jobs.filter { $0.status == "queued" } }

    var footerText: String {
        let running = jobs.filter { $0.status == "running" }.count
        let waiting = queuedJobs.count
        if running == 0 && waiting == 0 {
            return jobs.isEmpty ? "Queue is empty" : "All done"
        }
        var text = running > 0 ? "Working on 1" : "Starting"
        if waiting > 0 { text += " • \(waiting) waiting" }
        return text + " • your Mac stays awake until the queue is done"
    }

    var hasFinished: Bool {
        jobs.contains { canClear($0) }
    }

    func canClear(_ job: QueueJob) -> Bool {
        if job.status == "cancelled" { return true }
        if job.status == "done" { return !(job.isPosted && !job.isCleaned && settings.cleanup) }
        return false
    }

    // MARK: adding videos

    @discardableResult
    func ensureEngine() -> Bool {
        if FileManager.default.fileExists(atPath: Paths.engine.path) { return true }
        alert = AlertInfo(title: "Not fully installed",
                          message: "The splitter engine is missing. Double-click Install.command to finish setting up.")
        return false
    }

    func chooseFiles() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.prompt = "Add"
        panel.message = "Choose videos to split for Discord"
        if panel.runModal() == .OK {
            addFiles(panel.urls)
        }
    }

    func handleDrop(_ providers: [NSItemProvider]) {
        let group = DispatchGroup()
        let collector = URLCollector()
        for provider in providers where provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            group.enter()
            provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                if let data = item as? Data, let url = URL(dataRepresentation: data, relativeTo: nil) {
                    collector.add(url)
                } else if let url = item as? URL {
                    collector.add(url)
                }
                group.leave()
            }
        }
        group.notify(queue: .main) { [weak self] in
            self?.addFiles(collector.urls)
        }
    }

    func addFiles(_ urls: [URL]) {
        let fm = FileManager.default
        let paths = urls.compactMap { url -> String? in
            var isDir: ObjCBool = false
            guard fm.fileExists(atPath: url.path, isDirectory: &isDir), !isDir.boolValue else { return nil }
            return url.path
        }
        guard !paths.isEmpty, ensureEngine() else { return }
        checking = true
        Engine.run(["check", "--settings", jobSettingsJSON()] + paths) { [weak self] result in
            guard let self = self else { return }
            self.checking = false
            guard let array = result.json as? [[String: Any]] else {
                self.alert = AlertInfo(title: "Couldn't check those files",
                                       message: result.errorMessage ?? "The splitter didn't respond. Details are in app.log.")
                return
            }
            self.sheet = .confirm(PendingAdd(items: array.map { CheckItem(dict: $0) }))
        }
    }

    func confirmAdd(_ pending: PendingAdd) {
        sheet = nil
        let paths = pending.items.filter { $0.addable }.map { $0.path }
        guard !paths.isEmpty else { return }
        Engine.run(["enqueue", "--settings", jobSettingsJSON()] + paths) { [weak self] result in
            guard let self = self else { return }
            if let message = result.errorMessage {
                self.alert = AlertInfo(title: "Couldn't add to the queue", message: message)
            } else if let obj = result.json as? [String: Any],
                      let skipped = obj["skipped"] as? [[String: Any]], !skipped.isEmpty {
                let lines = skipped.map { "\($0["name"] as? String ?? "?"): \($0["why"] as? String ?? "")" }
                self.alert = AlertInfo(title: "Some videos weren't added", message: lines.joined(separator: "\n"))
            }
            self.refresh()
        }
    }

    // MARK: job actions

    func control(_ action: String, _ job: QueueJob, _ extra: [String] = []) {
        Engine.run([action, job.id] + extra) { [weak self] result in
            if let message = result.errorMessage {
                self?.alert = AlertInfo(title: "Couldn't do that", message: message)
            }
            self?.refresh()
        }
    }

    func clearFinished() {
        for job in jobs where canClear(job) {
            control("remove", job)
        }
    }

    func showInFinder(_ job: QueueJob) {
        if let dir = job.state.outdir, FileManager.default.fileExists(atPath: dir) {
            NSWorkspace.shared.open(URL(fileURLWithPath: dir))
        } else {
            alert = AlertInfo(title: "Folder not found", message: "The parts folder isn't there anymore.")
        }
    }

    func openDiscord() {
        let link = settings.channel.trimmingCharacters(in: .whitespacesAndNewlines)
        if let range = link.range(of: "/channels/") {
            let rest = String(link[range.upperBound...])
            if let appURL = URL(string: "discord://-/channels/" + rest), NSWorkspace.shared.open(appURL) { return }
            if let webURL = URL(string: link), NSWorkspace.shared.open(webURL) { return }
        }
        if let appURL = NSWorkspace.shared.urlForApplication(withBundleIdentifier: "com.hnc.Discord") {
            NSWorkspace.shared.openApplication(at: appURL, configuration: NSWorkspace.OpenConfiguration(), completionHandler: nil)
        } else if let webURL = URL(string: "https://discord.com/app") {
            NSWorkspace.shared.open(webURL)
        }
    }

    // MARK: cleanup (posted parts -> Trash after a day)

    func runCleanup() {
        lastCleanup = Date()
        guard settings.cleanup, engineInstalled else { return }
        Engine.run(["cleanup-due"]) { [weak self] result in
            guard let self = self, let due = result.json as? [[String: Any]] else { return }
            for entry in due {
                guard let id = entry["id"] as? String else { continue }
                var allGone = true
                for path in entry["items"] as? [String] ?? [] {
                    do {
                        try FileManager.default.trashItem(at: URL(fileURLWithPath: path), resultingItemURL: nil)
                    } catch {
                        if FileManager.default.fileExists(atPath: path) { allGone = false }
                    }
                }
                if allGone {
                    Engine.run(["mark-cleaned", id]) { _ in self.refresh() }
                }
            }
        }
    }
}

// MARK: - App

final class AppDelegate: NSObject, NSApplicationDelegate {
    func application(_ application: NSApplication, open urls: [URL]) {
        QueueModel.shared.addFiles(urls)
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        true
    }
}

@main
struct DiscordSplitterApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var model = QueueModel.shared

    var body: some Scene {
        Window(Paths.appName, id: "main") {
            ContentView()
                .environmentObject(model)
        }
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Add Videos...") { model.chooseFiles() }
                    .keyboardShortcut("o", modifiers: .command)
            }
            CommandGroup(replacing: .appSettings) {
                Button("Settings...") { model.sheet = .settings }
                    .keyboardShortcut(",", modifiers: .command)
            }
        }
    }
}

// MARK: - Views

struct ContentView: View {
    @EnvironmentObject var model: QueueModel
    @State private var dropTargeted = false

    var body: some View {
        VStack(spacing: 0) {
            if !model.engineInstalled {
                Text("The splitter engine isn't installed. Double-click Install.command to finish setting up.")
                    .foregroundColor(.red)
                    .padding(10)
            }
            if model.jobs.isEmpty {
                EmptyQueueView()
            } else {
                List {
                    ForEach(model.jobs) { job in
                        JobRow(job: job)
                    }
                }
                .listStyle(.inset)
            }
            Divider()
            FooterView()
        }
        .frame(minWidth: 640, minHeight: 420)
        .toolbar {
            ToolbarItemGroup(placement: .primaryAction) {
                Button {
                    model.chooseFiles()
                } label: {
                    Label("Add Videos", systemImage: "plus")
                }
                .help("Add videos to the queue")
                Button {
                    model.openDiscord()
                } label: {
                    Label("Open Discord", systemImage: "bubble.left.and.bubble.right")
                }
                .help("Open your Discord channel")
                Button {
                    model.sheet = .settings
                } label: {
                    Label("Settings", systemImage: "gearshape")
                }
                .help("Settings")
            }
        }
        .onDrop(of: [UTType.fileURL], isTargeted: $dropTargeted) { providers in
            model.handleDrop(providers)
            return true
        }
        .overlay(dropOverlay)
        .overlay(checkingOverlay)
        .sheet(item: $model.sheet) { sheet in
            switch sheet {
            case .settings:
                SettingsView().environmentObject(model)
            case .confirm(let pending):
                ConfirmView(pending: pending).environmentObject(model)
            }
        }
        .alert(item: $model.alert) { info in
            Alert(title: Text(info.title), message: Text(info.message))
        }
    }

    @ViewBuilder private var dropOverlay: some View {
        if dropTargeted {
            RoundedRectangle(cornerRadius: 14)
                .stroke(Color.accentColor, lineWidth: 3)
                .padding(6)
                .allowsHitTesting(false)
        }
    }

    @ViewBuilder private var checkingOverlay: some View {
        if model.checking {
            ProgressView("Checking videos...")
                .padding(24)
                .background(RoundedRectangle(cornerRadius: 12).fill(Color(nsColor: .windowBackgroundColor)))
                .shadow(radius: 8)
        }
    }
}

struct EmptyQueueView: View {
    @EnvironmentObject var model: QueueModel

    var body: some View {
        VStack(spacing: 14) {
            Spacer()
            Image(systemName: "film")
                .font(.system(size: 54))
                .foregroundColor(.secondary)
            Text("Drop videos here")
                .font(.title2.weight(.semibold))
            Text("They'll be split into parts under \(model.settings.limitLabel) that play right inside Discord.")
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            Button("Choose Videos...") { model.chooseFiles() }
                .controlSize(.large)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding()
    }
}

struct FooterView: View {
    @EnvironmentObject var model: QueueModel

    var body: some View {
        HStack {
            Text(model.footerText)
                .font(.caption)
                .foregroundColor(.secondary)
            Spacer()
            if model.hasFinished {
                Button("Clear Finished") { model.clearFinished() }
                    .controlSize(.small)
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
    }
}

struct JobRow: View {
    @EnvironmentObject var model: QueueModel
    let job: QueueJob

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 22))
                .foregroundColor(tint)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 4) {
                Text(job.name)
                    .font(.headline)
                    .lineLimit(1)
                    .truncationMode(.middle)
                if job.status == "running" {
                    ProgressView(value: min(max((job.state.progress ?? 0) / 100, 0), 1))
                    Text(runningText)
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .lineLimit(1)
                } else {
                    Text(detailText)
                        .font(.caption)
                        .foregroundColor(job.status == "failed" ? .red : .secondary)
                        .lineLimit(3)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer(minLength: 8)
            actions
        }
        .padding(.vertical, 6)
        .contextMenu { menuItems }
    }

    // MARK: text

    var icon: String {
        switch job.status {
        case "running": return "gearshape.2"
        case "queued": return job.cancelRequested ? "xmark.circle" : "clock"
        case "failed": return "exclamationmark.triangle.fill"
        case "cancelled": return "xmark.circle"
        default:
            if job.isCleaned { return "trash" }
            if job.isPosted { return "paperplane.fill" }
            return "checkmark.circle.fill"
        }
    }

    var tint: Color {
        switch job.status {
        case "running": return .accentColor
        case "failed": return .red
        case "done": return job.isPosted ? .blue : .green
        default: return .secondary
        }
    }

    var settingsSummary: String {
        let s = job.request.settings
        var bits: [String] = []
        if let size = s?.max_size { bits.append("under \(AppSettings.label(for: size))") }
        if s?.quality == "smaller" { bits.append(s?.fast == true ? "fast shrink" : "shrink") }
        if let overlap = s?.overlap, overlap > 0 { bits.append("\(Int(overlap))s overlap") }
        return bits.joined(separator: " • ")
    }

    var runningText: String {
        if job.cancelRequested { return "Cancelling..." }
        var text = job.state.message ?? "Working"
        text += " • \(Int(job.state.progress ?? 0))%"
        if let eta = job.state.eta, eta > 0 { text += " • about \(formatDuration(eta)) left" }
        return text
    }

    var detailText: String {
        switch job.status {
        case "queued":
            return job.cancelRequested ? "Cancelling..." : "\(job.state.message ?? "Waiting") • \(settingsSummary)"
        case "failed":
            return job.state.error ?? "Failed"
        case "cancelled":
            return "Cancelled"
        default:
            var text = job.state.message ?? "Done"
            if job.isCleaned {
                text += " • parts moved to the Trash"
            } else if let posted = job.request.posted_at {
                if model.settings.cleanup {
                    let left = posted + 86400 - Date().timeIntervalSince1970
                    text += left > 0 ? " • posted, moves to the Trash in \(formatDuration(left))"
                                     : " • posted, moving to the Trash"
                } else {
                    text += " • posted"
                }
            }
            if let note = job.state.notes?.first { text += "\n" + note }
            return text
        }
    }

    // MARK: buttons

    @ViewBuilder var actions: some View {
        HStack(spacing: 6) {
            switch job.status {
            case "queued":
                iconButton("arrow.up", "Move up") { model.control("move", job, ["up"]) }
                iconButton("arrow.down", "Move down") { model.control("move", job, ["down"]) }
                iconButton("xmark", "Cancel") { model.control("cancel", job) }
            case "running":
                Button(job.cancelRequested ? "Cancelling..." : "Cancel") { model.control("cancel", job) }
                    .disabled(job.cancelRequested)
            case "failed", "cancelled":
                iconButton("arrow.clockwise", "Try again") { model.control("retry", job) }
                iconButton("trash", "Remove from the list") { model.control("remove", job) }
            default:
                if job.hasParts && !job.isCleaned {
                    iconButton("folder", "Show the parts in Finder") { model.showInFinder(job) }
                    iconButton("bubble.left.and.bubble.right", "Open Discord") { model.openDiscord() }
                    if job.isPosted {
                        Button {
                            model.control("unposted", job)
                        } label: {
                            Label("Posted", systemImage: "checkmark")
                        }
                        .help("Marked as posted. Click to undo.")
                    } else {
                        Button("Mark Posted") { model.control("posted", job) }
                            .help(model.settings.cleanup ? "Parts move to the Trash a day after you mark them posted." : "Mark as posted")
                    }
                } else {
                    iconButton("trash", "Remove from the list") { model.control("remove", job) }
                }
            }
        }
        .buttonStyle(.borderless)
    }

    @ViewBuilder var menuItems: some View {
        if job.hasParts && !job.isCleaned {
            Button("Show in Finder") { model.showInFinder(job) }
        }
        if job.status == "queued" || job.status == "running" {
            Button("Cancel") { model.control("cancel", job) }
        }
        if job.status == "failed" || job.status == "cancelled" {
            Button("Try Again") { model.control("retry", job) }
        }
        if job.status != "running" {
            Button("Remove from List") { model.control("remove", job) }
        }
    }

    func iconButton(_ symbol: String, _ help: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
        }
        .help(help)
    }
}

struct ConfirmView: View {
    @EnvironmentObject var model: QueueModel
    let pending: PendingAdd

    var addableCount: Int { pending.items.filter { $0.addable }.count }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(addableCount == 1 ? "Add 1 video to the queue?" : "Add \(addableCount) videos to the queue?")
                .font(.title3.weight(.semibold))
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(pending.items) { item in
                        HStack(alignment: .top, spacing: 10) {
                            Image(systemName: icon(item))
                                .foregroundColor(color(item))
                                .frame(width: 20)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.name)
                                    .font(.headline)
                                    .lineLimit(1)
                                    .truncationMode(.middle)
                                Text(describe(item))
                                    .font(.callout)
                                    .foregroundColor(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxHeight: 320)
            Text("Settings: \(model.settingsSummary). Change them in Settings before adding.")
                .font(.caption)
                .foregroundColor(.secondary)
            HStack {
                Spacer()
                Button("Cancel") { model.sheet = nil }
                    .keyboardShortcut(.cancelAction)
                Button(addableCount > 1 ? "Add \(addableCount) to Queue" : "Add to Queue") {
                    model.confirmAdd(pending)
                }
                .keyboardShortcut(.defaultAction)
                .disabled(addableCount == 0)
            }
        }
        .padding(20)
        .frame(width: 540)
    }

    func icon(_ item: CheckItem) -> String {
        if item.error != nil { return "exclamationmark.triangle.fill" }
        if item.skip { return "checkmark.circle" }
        if item.slow { return "tortoise.fill" }
        return "hare.fill"
    }

    func color(_ item: CheckItem) -> Color {
        if item.error != nil { return .red }
        if item.skip { return .green }
        return item.slow ? .orange : .accentColor
    }

    func describe(_ item: CheckItem) -> String {
        if let error = item.error { return error }
        let head = "\(item.sizeText), \(item.lengthText). "
        if item.skip {
            return head + "Already under \(item.limitText) and plays in Discord, so there's nothing to do. Upload it as it is."
        }
        if item.plays == "convert" {
            return head + "Needs converting first, because \(item.reason). That's slow. Then it's split into parts under \(item.limitText)."
        }
        if model.settings.quality == "smaller" {
            let how = (model.settings.modern ? "to AV1 " : "")
                + (model.settings.fast ? "with fast shrink" : "at a quality you shouldn't notice")
            return head + "Will be shrunk \(how) (slow), then split into parts under \(item.limitText)."
        }
        var text = head + (item.parts <= 1 ? "Fits in one file." : "About \(item.parts) parts, original quality.")
        if item.plays == "remux" { text += " Converted to MP4 with no quality loss." }
        return text
    }
}

struct SettingsView: View {
    @EnvironmentObject var model: QueueModel
    @Environment(\.dismiss) private var dismiss
    @State private var draft = AppSettings()
    @State private var sizeChoice = "1G"
    @State private var customSize = ""
    @State private var loaded = false

    var sizeValid: Bool {
        if sizeChoice != "custom" { return true }
        return customSize.range(of: #"^\s*\d+(\.\d+)?\s*[KkMmGg]?([iI]?[bB])?\s*$"#, options: .regularExpression) != nil
    }

    var batchBinding: Binding<Bool> {
        Binding(get: { draft.batch > 0 }, set: { draft.batch = $0 ? 10 : 0 })
    }

    var body: some View {
        VStack(spacing: 0) {
            Form {
                Section("Parts") {
                    Picker("Part size", selection: $sizeChoice) {
                        Text("1 GB (Nitro)").tag("1G")
                        Text("50 MB (Nitro Basic)").tag("50M")
                        Text("20 MB (free)").tag("20M")
                        Text("Custom").tag("custom")
                    }
                    if sizeChoice == "custom" {
                        TextField("Custom size", text: $customSize, prompt: Text("e.g. 750M"))
                    }
                    Picker("Overlap between parts", selection: $draft.overlap) {
                        Text("Off").tag(0.0)
                        Text("3 seconds").tag(3.0)
                        Text("5 seconds").tag(5.0)
                        Text("10 seconds").tag(10.0)
                    }
                    Toggle("Group parts into folders of 10 (one Discord message each)", isOn: batchBinding)
                }
                Section("Quality") {
                    Picker("Quality", selection: $draft.quality) {
                        Text("Original (no re-encoding, fast)").tag("original")
                        Text("Smaller files (re-encodes, slower)").tag("smaller")
                    }
                    .pickerStyle(.radioGroup)
                    Toggle("Fast shrink (quicker encoder settings)", isOn: $draft.fast)
                    Text("Smaller files tests each video on samples and picks the smallest size that stays within about 4% of the original's quality. Surround sound becomes stereo. Fast shrink uses quicker encoder settings: about 1.7x as quick, files about 10% bigger. It's also used when a video has to be converted.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Section("Video formats") {
                    Toggle("My server plays H.265 & AV1", isOn: $draft.modern)
                    Text("Turn this on only after a test upload of an H.265 video (any iPhone video works) plays for your friends. Then H.265 and AV1 videos are split as they are, in minutes and with no quality loss, instead of being converted. Shrinking also makes AV1 instead of H.264, about 25% smaller again; post one shrunk video as a test first. Older PCs, older iPhones and some browsers can't play H.265 or AV1.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                Section("Queue") {
                    Toggle("Quick jobs go ahead of slow ones", isOn: $draft.quick_first)
                    Toggle("Move parts to the Trash 1 day after marking them posted", isOn: $draft.cleanup)
                }
                Section("Discord") {
                    TextField("Channel link", text: $draft.channel, prompt: Text("Right-click a channel, then Copy Link"))
                }
            }
            .formStyle(.grouped)
            Divider()
            HStack {
                if !sizeValid {
                    Text("Use a size like 750M or 1G.")
                        .font(.caption)
                        .foregroundColor(.red)
                }
                Spacer()
                Button("Cancel") { dismiss() }
                    .keyboardShortcut(.cancelAction)
                Button("Save") {
                    save()
                    dismiss()
                }
                .keyboardShortcut(.defaultAction)
                .disabled(!sizeValid)
            }
            .padding(14)
        }
        .frame(width: 540, height: 700)
        .onAppear {
            if !loaded {
                load()
                loaded = true
            }
        }
    }

    func load() {
        draft = model.settings
        if ["1G", "50M", "20M"].contains(draft.max_size) {
            sizeChoice = draft.max_size
            customSize = ""
        } else {
            sizeChoice = "custom"
            customSize = draft.max_size
        }
        if ![0.0, 3.0, 5.0, 10.0].contains(draft.overlap) { draft.overlap = 3 }
    }

    func save() {
        var updated = draft
        updated.max_size = sizeChoice == "custom"
            ? customSize.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
            : sizeChoice
        updated.channel = updated.channel.trimmingCharacters(in: .whitespacesAndNewlines)
        model.saveSettings(updated)
    }
}
