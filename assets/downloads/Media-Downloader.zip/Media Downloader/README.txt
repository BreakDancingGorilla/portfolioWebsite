Media Downloader
================

A Mac app with a built-in browser for saving the images and videos on a web
page. Open a page, pick what you want from the list of media it finds, and
download it in one click. Video sites and streams are handled by yt-dlp.

Needs
  - A Mac with macOS 14 (Sonoma) or newer (Apple Silicon or Intel)
  - Optional, for video sites and streams: yt-dlp and ffmpeg
      brew install yt-dlp ffmpeg        (needs Homebrew: https://brew.sh)

Install
  1. Drag "Media Downloader.app" into your Applications folder.
  2. Open it. If macOS says it can't be opened, open System Settings >
     Privacy & Security, scroll down, and click "Open Anyway".

Only download media you have the right to save.
